_base_ = ["./cau_flood_dual_swin_huge_upernet_tune01_mfscore_earlystop_50e_256x256.py"]

work_dir = "/mnt/htzzb2/EO_test/wj1/swin_work_dirs/cau_flood_finetune/cau_flood_dual_swin_huge_upernet_tune04_input_norm_difflr_50e_256x256"

#mean = [54.730560606596306, 87.64151816023418, 75.88863827067563, 158.02073291645573]
#std = [45.622372646527445, 40.93144444024192, 41.774725322913284, 68.08039319156036]
base_lr = 1.5e-4
backbone_lr_mult = 0.05
warmup_iters = 2000

#data_preprocessor = dict(
#    mean=mean,
#    std=std,
#)

optim_wrapper = dict(
    optimizer=dict(lr=base_lr),
    paramwise_cfg=dict(
        custom_keys={
            "backbone": dict(lr_mult=backbone_lr_mult),
            "sar_backbone": dict(lr_mult=backbone_lr_mult),
        },
    ),
)

param_scheduler = [
    dict(
        type="LinearLR",
        start_factor=1e-6,
        by_epoch=False,
        begin=0,
        end=warmup_iters,
    ),
    dict(
        type="PolyLR",
        eta_min=1e-6,
        power=0.9,
        begin=0,
        end=50,
        by_epoch=True,
    ),
]

custom_hooks = [
    dict(
        type="SaveRawPredHook",
        output_dir=work_dir + "_infer",
        scale255=False,
    ),
]
