_base_ = ["./cau_flood_dual_swin_huge_upernet_tune01_mfscore_earlystop_50e_256x256.py"]

work_dir = "/mnt/htzzb2/EO_test/wj1/swin_work_dirs/cau_flood_finetune/cau_flood_dual_swin_huge_upernet_tune05_input_norm_auxhead_50e_256x256"

#mean = [54.730560606596306, 87.64151816023418, 75.88863827067563, 158.02073291645573]
#std = [45.622372646527445, 40.93144444024192, 41.774725322913284, 68.08039319156036]

#data_preprocessor = dict(
#    mean=mean,
#    std=std,
#)

model = dict(
    auxiliary_head=dict(
        type="mmseg.FCNHead",
        in_channels=1408,
        in_index=2,
        channels=512,
        num_convs=1,
        concat_input=False,
        dropout_ratio=0.1,
        num_classes=2,
        norm_cfg=dict(type="SyncBN", requires_grad=True),
        align_corners=False,
        ignore_index=255,
        loss_decode=dict(
            type="mmseg.CrossEntropyLoss",
            use_sigmoid=False,
            loss_weight=0.4,
        ),
    ),
)

custom_hooks = [
    dict(
        type="SaveRawPredHook",
        output_dir=work_dir + "_infer",
        scale255=False,
    ),
]
