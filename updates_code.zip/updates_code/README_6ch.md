# EV-UAV six-channel input experiment

Copy this folder into the root of the EV-UAV repository while preserving the
directory layout:

- `dataset/basedataset.py` replaces the repository file of the same path.
- `configs/evisseg_evuav_6ch.yaml` is a new training/inference configuration.

The code is backward compatible.  Existing configurations that omit
`add_voxel_stats` continue to create the original four input channels.  The
six-channel configuration enables two extra per-voxel statistics:

1. `log(1 + event_count)`
2. normalized timestamp standard deviation, scaled by `time_std_scale`

Before use, edit the dataset root, output directory, and model checkpoint paths
in `configs/evisseg_evuav_6ch.yaml`.

The 6-channel model must be trained from scratch.  A 4-channel checkpoint cannot
be loaded because the first sparse convolution has a different input shape.

Example:

```bash
CUDA_VISIBLE_DEVICES=0 python -u train.py --config configs/evisseg_evuav_6ch.yaml
```

Use the same 6-channel configuration for inference.
