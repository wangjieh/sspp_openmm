"""MMSeg segmentor for PASTIS time-series inputs with a DINOv3 encoder."""

from __future__ import annotations

from contextlib import nullcontext
from typing import List, Optional, Sequence

import torch
import torch.nn as nn
from mmengine.model import BaseModel
from mmengine.structures import PixelData
from mmseg.registry import MODELS
from mmseg.structures import SegDataSample


@MODELS.register_module()
class PASTISDINOv3Segmentor(BaseModel):
    """DINOv3 ViT-L/16 SAT encoder + patch-wise linear segmentation head.

    Expected input shape is ``B x T x 3 x H x W``.  The dataset is responsible
    for band-wise min/max normalization, RGB selection and resizing.  This model
    applies the DINOv3 satellite normalization, runs each timestep through the
    DINOv3 backbone, mean-pools over time and decodes dense logits.
    """

    def __init__(
        self,
        backbone: dict,
        decode_head: dict,
        data_preprocessor: Optional[dict] = None,
        ignore_index: int = -1,
        satellite_mean: Sequence[float] = (0.430, 0.411, 0.296),
        satellite_std: Sequence[float] = (0.213, 0.156, 0.143),
        frozen_backbone: bool = True,
        backbone_frame_batch_size: int = 4,
        init_cfg: Optional[dict] = None,
    ) -> None:
        super().__init__(
            data_preprocessor=data_preprocessor,
            init_cfg=init_cfg)
        self.backbone = MODELS.build(backbone)
        self.decode_head = MODELS.build(decode_head)
        self.ignore_index = ignore_index
        self.backbone_frame_batch_size = backbone_frame_batch_size
        self.loss_decode = nn.CrossEntropyLoss(ignore_index=ignore_index)
        self.backbone_frozen = False
        self.register_buffer(
            'satellite_mean',
            torch.tensor(satellite_mean, dtype=torch.float32).view(1, 3, 1, 1),
            persistent=False)
        self.register_buffer(
            'satellite_std',
            torch.tensor(satellite_std, dtype=torch.float32).view(1, 3, 1, 1),
            persistent=False)
        self.set_backbone_frozen(frozen_backbone)

    def set_backbone_frozen(self, frozen: bool = True) -> None:
        self.backbone_frozen = frozen
        for param in self.backbone.parameters():
            param.requires_grad = not frozen
        if frozen:
            self.backbone.eval()
        else:
            self.backbone.train(self.training)

    def train(self, mode: bool = True):
        super().train(mode)
        if self.backbone_frozen:
            self.backbone.eval()
        return self

    def forward(
        self,
        inputs: torch.Tensor,
        data_samples: Optional[List[SegDataSample]] = None,
        mode: str = 'tensor',
    ):
        if mode == 'loss':
            return self.loss(inputs, data_samples)
        if mode == 'predict':
            return self.predict(inputs, data_samples)
        if mode == 'tensor':
            return self._forward(inputs)
        raise RuntimeError(f'Invalid mode "{mode}".')

    def _forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.encode_decode(inputs)

    def loss(
        self,
        inputs: torch.Tensor,
        data_samples: Optional[List[SegDataSample]],
    ) -> dict:
        if data_samples is None:
            raise ValueError('data_samples are required for loss mode.')
        logits = self.encode_decode(inputs)
        labels = self._stack_gt(data_samples, logits.device)
        loss = self.loss_decode(logits, labels)
        return {'decode.loss_ce': loss}

    def predict(
        self,
        inputs: torch.Tensor,
        data_samples: Optional[List[SegDataSample]] = None,
    ) -> List[SegDataSample]:
        logits = self.encode_decode(inputs)
        preds = logits.argmax(dim=1, keepdim=True)
        if data_samples is None:
            data_samples = [SegDataSample() for _ in range(logits.shape[0])]
        results = []
        for idx, data_sample in enumerate(data_samples):
            data_sample.seg_logits = PixelData(data=logits[idx])
            data_sample.pred_sem_seg = PixelData(data=preds[idx])
            results.append(data_sample)
        return results

    def encode_decode(self, inputs: torch.Tensor) -> torch.Tensor:
        features = self.extract_feat(inputs)
        return self.decode_head(features)

    def extract_feat(self, inputs: torch.Tensor) -> torch.Tensor:
        if inputs.ndim != 5:
            raise ValueError(
                'PASTISDINOv3Segmentor expects B x T x 3 x H x W inputs, '
                f'got {tuple(inputs.shape)}.')
        batch_size, num_steps, channels, height, width = inputs.shape
        if channels != 3:
            raise ValueError(f'Expected RGB inputs with 3 channels, got {channels}.')

        frames = inputs.reshape(batch_size * num_steps, channels, height, width)
        frames = (frames - self.satellite_mean) / self.satellite_std

        outputs = []
        frame_chunks = frames.split(self.backbone_frame_batch_size, dim=0)
        context = torch.no_grad() if self.backbone_frozen else nullcontext()
        with context:
            for frame_chunk in frame_chunks:
                chunk_out = self.backbone(frame_chunk)
                if isinstance(chunk_out, (list, tuple)):
                    chunk_out = chunk_out[-1]
                outputs.append(chunk_out)

        features = torch.cat(outputs, dim=0)
        _, embed_dim, feat_h, feat_w = features.shape
        features = features.view(
            batch_size,
            num_steps,
            embed_dim,
            feat_h,
            feat_w)
        return features.mean(dim=1)

    @staticmethod
    def _stack_gt(data_samples: List[SegDataSample], device: torch.device) -> torch.Tensor:
        labels = []
        for data_sample in data_samples:
            labels.append(data_sample.gt_sem_seg.data.squeeze(0).long())
        return torch.stack(labels, dim=0).to(device)
