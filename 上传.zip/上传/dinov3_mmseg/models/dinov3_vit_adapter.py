"""DINOv3 ViT adapter backbone registered for MMSegmentation."""

from __future__ import annotations

import math
from contextlib import nullcontext
from functools import partial
from typing import Optional, Sequence, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.checkpoint as cp
from mmengine.model import BaseModule
from mmseg.registry import MODELS

from .dinov3_vit import DINOv3ViT

try:
    from mmcv.ops import MultiScaleDeformableAttention
except ImportError:  # pragma: no cover - depends on the server mmcv build.
    from mmcv.cnn.bricks.transformer import MultiScaleDeformableAttention


def drop_path(
    x: torch.Tensor,
    drop_prob: float = 0.0,
    training: bool = False,
) -> torch.Tensor:
    if drop_prob == 0.0 or not training:
        return x
    keep_prob = 1 - drop_prob
    shape = (x.shape[0], ) + (1, ) * (x.ndim - 1)
    random_tensor = x.new_empty(shape).bernoulli_(keep_prob)
    if keep_prob > 0.0:
        random_tensor.div_(keep_prob)
    return x * random_tensor


class DropPath(nn.Module):
    """Drop paths per sample."""

    def __init__(self, drop_prob: float = 0.0) -> None:
        super().__init__()
        self.drop_prob = drop_prob

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return drop_path(x, self.drop_prob, self.training)


def get_reference_points(
    spatial_shapes: Sequence[Tuple[int, int]],
    device: torch.device,
) -> torch.Tensor:
    reference_points_list = []
    for height, width in spatial_shapes:
        ref_y, ref_x = torch.meshgrid(
            torch.linspace(
                0.5, height - 0.5, height, dtype=torch.float32, device=device),
            torch.linspace(
                0.5, width - 0.5, width, dtype=torch.float32, device=device),
            indexing='ij')
        ref_y = ref_y.reshape(-1)[None] / height
        ref_x = ref_x.reshape(-1)[None] / width
        reference_points_list.append(torch.stack((ref_x, ref_y), -1))
    reference_points = torch.cat(reference_points_list, 1)
    return reference_points[:, :, None]


def deform_inputs(x: torch.Tensor, patch_size: int):
    _, _, height, width = x.shape
    spatial_shapes = torch.as_tensor(
        [(height // 8, width // 8), (height // 16, width // 16),
         (height // 32, width // 32)],
        dtype=torch.long,
        device=x.device)
    level_start_index = torch.cat(
        (spatial_shapes.new_zeros((1, )), spatial_shapes.prod(1).cumsum(0)[:-1]))
    reference_points = get_reference_points(
        [(height // patch_size, width // patch_size)], x.device)
    deform_inputs1 = [reference_points, spatial_shapes, level_start_index]

    spatial_shapes = torch.as_tensor(
        [(height // patch_size, width // patch_size)],
        dtype=torch.long,
        device=x.device)
    level_start_index = torch.cat(
        (spatial_shapes.new_zeros((1, )), spatial_shapes.prod(1).cumsum(0)[:-1]))
    reference_points = get_reference_points(
        [(height // 8, width // 8), (height // 16, width // 16),
         (height // 32, width // 32)],
        x.device)
    deform_inputs2 = [reference_points, spatial_shapes, level_start_index]

    return deform_inputs1, deform_inputs2


class DWConv(nn.Module):
    """Depth-wise conv over concatenated 1/8, 1/16 and 1/32 tokens."""

    def __init__(self, dim: int = 768) -> None:
        super().__init__()
        self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)

    def forward(self, x: torch.Tensor, height: int, width: int) -> torch.Tensor:
        batch_size, num_tokens, channels = x.shape
        unit = num_tokens // 21
        x1 = x[:, 0:16 * unit, :].transpose(1, 2).view(
            batch_size, channels, height * 2, width * 2).contiguous()
        x2 = x[:, 16 * unit:20 * unit, :].transpose(1, 2).view(
            batch_size, channels, height, width).contiguous()
        x3 = x[:, 20 * unit:, :].transpose(1, 2).view(
            batch_size, channels, height // 2, width // 2).contiguous()
        x1 = self.dwconv(x1).flatten(2).transpose(1, 2)
        x2 = self.dwconv(x2).flatten(2).transpose(1, 2)
        x3 = self.dwconv(x3).flatten(2).transpose(1, 2)
        return torch.cat([x1, x2, x3], dim=1)


class ConvFFN(nn.Module):
    """Feed-forward layer with depth-wise convolutional spatial mixing."""

    def __init__(
        self,
        in_features: int,
        hidden_features: Optional[int] = None,
        out_features: Optional[int] = None,
        act_layer=nn.GELU,
        drop: float = 0.0,
    ) -> None:
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.dwconv = DWConv(hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x: torch.Tensor, height: int, width: int) -> torch.Tensor:
        x = self.fc1(x)
        x = self.dwconv(x, height, width)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        return self.drop(x)


class MMCVMSDeformAttn(nn.Module):
    """Expose MMCV MultiScaleDeformableAttention with DINOv3 adapter API."""

    def __init__(
        self,
        d_model: int,
        n_levels: int,
        n_heads: int,
        n_points: int,
        ratio: float = 1.0,
    ) -> None:
        super().__init__()
        kwargs = dict(
            embed_dims=d_model,
            num_heads=n_heads,
            num_levels=n_levels,
            num_points=n_points,
            batch_first=True,
            dropout=0.0)
        try:
            self.attn = MultiScaleDeformableAttention(
                **kwargs, value_proj_ratio=ratio)
        except TypeError:
            self.attn = MultiScaleDeformableAttention(**kwargs)

    def forward(
        self,
        query: torch.Tensor,
        reference_points: torch.Tensor,
        input_flatten: torch.Tensor,
        input_spatial_shapes: torch.Tensor,
        input_level_start_index: torch.Tensor,
        input_padding_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        identity = torch.zeros_like(query)
        return self.attn(
            query=query,
            value=input_flatten,
            identity=identity,
            reference_points=reference_points,
            spatial_shapes=input_spatial_shapes,
            level_start_index=input_level_start_index,
            key_padding_mask=input_padding_mask)


class Extractor(nn.Module):
    """Extract ViT semantic features into spatial prior tokens."""

    def __init__(
        self,
        dim: int,
        num_heads: int = 6,
        n_points: int = 4,
        n_levels: int = 1,
        deform_ratio: float = 1.0,
        with_cffn: bool = True,
        cffn_ratio: float = 0.25,
        drop: float = 0.0,
        drop_path: float = 0.0,
        norm_layer=partial(nn.LayerNorm, eps=1e-6),
        with_cp: bool = False,
    ) -> None:
        super().__init__()
        self.query_norm = norm_layer(dim)
        self.feat_norm = norm_layer(dim)
        self.attn = MMCVMSDeformAttn(
            d_model=dim,
            n_levels=n_levels,
            n_heads=num_heads,
            n_points=n_points,
            ratio=deform_ratio)
        self.with_cffn = with_cffn
        self.with_cp = with_cp
        if with_cffn:
            self.ffn = ConvFFN(
                in_features=dim,
                hidden_features=int(dim * cffn_ratio),
                drop=drop)
            self.ffn_norm = norm_layer(dim)
            self.drop_path = DropPath(drop_path) if drop_path > 0.0 else nn.Identity()

    def forward(
        self,
        query: torch.Tensor,
        reference_points: torch.Tensor,
        feat: torch.Tensor,
        spatial_shapes: torch.Tensor,
        level_start_index: torch.Tensor,
        height: int,
        width: int,
    ) -> torch.Tensor:

        def _inner_forward(query, feat):
            attn = self.attn(
                self.query_norm(query),
                reference_points,
                self.feat_norm(feat),
                spatial_shapes,
                level_start_index,
                None)
            query = query + attn
            if self.with_cffn:
                query = query + self.drop_path(
                    self.ffn(self.ffn_norm(query), height, width))
            return query

        if self.with_cp and query.requires_grad:
            return cp.checkpoint(_inner_forward, query, feat, use_reentrant=False)
        return _inner_forward(query, feat)


class InteractionBlockWithCls(nn.Module):
    """DINOv3 adapter interaction block using class-token aware inputs."""

    def __init__(
        self,
        dim: int,
        num_heads: int = 6,
        n_points: int = 4,
        norm_layer=partial(nn.LayerNorm, eps=1e-6),
        drop: float = 0.0,
        drop_path: float = 0.0,
        with_cffn: bool = True,
        cffn_ratio: float = 0.25,
        deform_ratio: float = 1.0,
        extra_extractor: bool = False,
        with_cp: bool = False,
    ) -> None:
        super().__init__()
        self.extractor = Extractor(
            dim=dim,
            n_levels=1,
            num_heads=num_heads,
            n_points=n_points,
            norm_layer=norm_layer,
            deform_ratio=deform_ratio,
            with_cffn=with_cffn,
            cffn_ratio=cffn_ratio,
            drop=drop,
            drop_path=drop_path,
            with_cp=with_cp)
        self.extra_extractors = None
        if extra_extractor:
            self.extra_extractors = nn.Sequential(*[
                Extractor(
                    dim=dim,
                    num_heads=num_heads,
                    n_points=n_points,
                    norm_layer=norm_layer,
                    with_cffn=with_cffn,
                    cffn_ratio=cffn_ratio,
                    deform_ratio=deform_ratio,
                    drop=drop,
                    drop_path=drop_path,
                    with_cp=with_cp) for _ in range(2)
            ])

    def forward(
        self,
        x: torch.Tensor,
        c: torch.Tensor,
        cls: torch.Tensor,
        deform_inputs2,
        height: int,
        width: int,
    ):
        c = self.extractor(
            query=c,
            reference_points=deform_inputs2[0],
            feat=x,
            spatial_shapes=deform_inputs2[1],
            level_start_index=deform_inputs2[2],
            height=height,
            width=width)
        if self.extra_extractors is not None:
            for extractor in self.extra_extractors:
                c = extractor(
                    query=c,
                    reference_points=deform_inputs2[0],
                    feat=x,
                    spatial_shapes=deform_inputs2[1],
                    level_start_index=deform_inputs2[2],
                    height=height,
                    width=width)
        return x, c, cls


class SpatialPriorModule(nn.Module):
    """Small CNN branch that provides 1/4, 1/8, 1/16 and 1/32 priors."""

    def __init__(self, inplanes: int = 64, embed_dim: int = 384) -> None:
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(3, inplanes, kernel_size=3, stride=2, padding=1, bias=False),
            nn.SyncBatchNorm(inplanes),
            nn.ReLU(inplace=True),
            nn.Conv2d(inplanes, inplanes, kernel_size=3, stride=1, padding=1, bias=False),
            nn.SyncBatchNorm(inplanes),
            nn.ReLU(inplace=True),
            nn.Conv2d(inplanes, inplanes, kernel_size=3, stride=1, padding=1, bias=False),
            nn.SyncBatchNorm(inplanes),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1))
        self.conv2 = nn.Sequential(
            nn.Conv2d(inplanes, 2 * inplanes, kernel_size=3, stride=2, padding=1, bias=False),
            nn.SyncBatchNorm(2 * inplanes),
            nn.ReLU(inplace=True))
        self.conv3 = nn.Sequential(
            nn.Conv2d(2 * inplanes, 4 * inplanes, kernel_size=3, stride=2, padding=1, bias=False),
            nn.SyncBatchNorm(4 * inplanes),
            nn.ReLU(inplace=True))
        self.conv4 = nn.Sequential(
            nn.Conv2d(4 * inplanes, 4 * inplanes, kernel_size=3, stride=2, padding=1, bias=False),
            nn.SyncBatchNorm(4 * inplanes),
            nn.ReLU(inplace=True))
        self.fc1 = nn.Conv2d(inplanes, embed_dim, kernel_size=1)
        self.fc2 = nn.Conv2d(2 * inplanes, embed_dim, kernel_size=1)
        self.fc3 = nn.Conv2d(4 * inplanes, embed_dim, kernel_size=1)
        self.fc4 = nn.Conv2d(4 * inplanes, embed_dim, kernel_size=1)

    def forward(self, x: torch.Tensor):
        c1 = self.stem(x)
        c2 = self.conv2(c1)
        c3 = self.conv3(c2)
        c4 = self.conv4(c3)
        c1 = self.fc1(c1)
        c2 = self.fc2(c2)
        c3 = self.fc3(c3)
        c4 = self.fc4(c4)

        batch_size, channels, _, _ = c1.shape
        c2 = c2.view(batch_size, channels, -1).transpose(1, 2)
        c3 = c3.view(batch_size, channels, -1).transpose(1, 2)
        c4 = c4.view(batch_size, channels, -1).transpose(1, 2)
        return c1, c2, c3, c4


@MODELS.register_module()
class DINOv3ViTAdapter(BaseModule):
    """DINOv3 ViT plus adapter, exposed as an MMSeg backbone."""

    def __init__(
        self,
        arch: Union[str, dict] = 'vitl16',
        img_size: Union[int, Tuple[int, int]] = 512,
        patch_size: int = 16,
        in_channels: int = 3,
        interaction_indexes: Sequence[int] = (5, 11, 17, 23),
        pretrain_size: int = 512,
        conv_inplane: int = 64,
        n_points: int = 4,
        deform_num_heads: int = 16,
        drop_path_rate: float = 0.3,
        with_cffn: bool = True,
        cffn_ratio: float = 0.25,
        deform_ratio: float = 0.5,
        add_vit_feature: bool = True,
        use_extra_extractor: bool = True,
        with_cp: bool = True,
        frozen_backbone: bool = False,
        norm: bool = True,
        auto_pad: bool = True,
        norm_eval: bool = True,
        backbone_init_cfg: Optional[dict] = None,
        init_cfg: Optional[dict] = None,
        **backbone_kwargs,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        if patch_size != 16:
            raise ValueError('DINOv3ViTAdapter currently expects patch_size=16.')

        self.dinov3 = DINOv3ViT(
            arch=arch,
            img_size=img_size,
            patch_size=patch_size,
            in_channels=in_channels,
            out_indices=tuple(interaction_indexes),
            norm=norm,
            output_cls_token=False,
            auto_pad=auto_pad,
            frozen_stages=-1,
            norm_eval=norm_eval,
            init_cfg=backbone_init_cfg,
            **backbone_kwargs)
        embed_dim = self.dinov3.embed_dims
        self.embed_dims = embed_dim
        self.out_channels = [embed_dim] * 4
        self.interaction_indexes = tuple(interaction_indexes)
        self.pretrain_size = (pretrain_size, pretrain_size)
        self.patch_size = patch_size
        self.add_vit_feature = add_vit_feature
        self.norm = norm
        self.auto_pad = auto_pad
        self.frozen_backbone = False

        self.level_embed = nn.Parameter(torch.zeros(3, embed_dim))
        self.spm = SpatialPriorModule(
            inplanes=conv_inplane, embed_dim=embed_dim)
        self.interactions = nn.Sequential(*[
            InteractionBlockWithCls(
                dim=embed_dim,
                num_heads=deform_num_heads,
                n_points=n_points,
                drop_path=drop_path_rate,
                norm_layer=partial(nn.LayerNorm, eps=1e-6),
                with_cffn=with_cffn,
                cffn_ratio=cffn_ratio,
                deform_ratio=deform_ratio,
                extra_extractor=(
                    idx == len(self.interaction_indexes) - 1
                    and use_extra_extractor),
                with_cp=with_cp) for idx in range(len(self.interaction_indexes))
        ])
        self.up = nn.ConvTranspose2d(embed_dim, embed_dim, 2, 2)
        self.norm1 = nn.SyncBatchNorm(embed_dim)
        self.norm2 = nn.SyncBatchNorm(embed_dim)
        self.norm3 = nn.SyncBatchNorm(embed_dim)
        self.norm4 = nn.SyncBatchNorm(embed_dim)

        self._init_adapter_weights()
        self.set_backbone_frozen(frozen_backbone)

    def _init_adapter_weights(self) -> None:
        self.up.apply(self._init_weights)
        self.spm.apply(self._init_weights)
        self.interactions.apply(self._init_weights)
        nn.init.normal_(self.level_embed)

    @staticmethod
    def _init_weights(module: nn.Module) -> None:
        if isinstance(module, nn.Linear):
            nn.init.trunc_normal_(module.weight, std=0.02)
            if module.bias is not None:
                nn.init.constant_(module.bias, 0)
        elif isinstance(module, (nn.LayerNorm, nn.BatchNorm2d, nn.SyncBatchNorm)):
            nn.init.constant_(module.bias, 0)
            nn.init.constant_(module.weight, 1.0)
        elif isinstance(module, (nn.Conv2d, nn.ConvTranspose2d)):
            fan_out = module.kernel_size[0] * module.kernel_size[1] * module.out_channels
            fan_out //= module.groups
            module.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if module.bias is not None:
                module.bias.data.zero_()

    def set_backbone_frozen(self, frozen: bool = True) -> None:
        self.frozen_backbone = frozen
        for param in self.dinov3.parameters():
            param.requires_grad = not frozen
        if frozen:
            self.dinov3.eval()
        else:
            self.dinov3.train(self.training)

    def train(self, mode: bool = True):
        super().train(mode)
        if self.frozen_backbone:
            self.dinov3.eval()
        return self

    def _maybe_pad(self, x: torch.Tensor) -> torch.Tensor:
        if not self.auto_pad:
            return x
        height, width = x.shape[-2:]
        divisor = self.patch_size * 2
        pad_h = (divisor - height % divisor) % divisor
        pad_w = (divisor - width % divisor) % divisor
        if pad_h == 0 and pad_w == 0:
            return x
        return F.pad(x, (0, pad_w, 0, pad_h))

    def _add_level_embed(
        self,
        c2: torch.Tensor,
        c3: torch.Tensor,
        c4: torch.Tensor,
    ):
        return (
            c2 + self.level_embed[0],
            c3 + self.level_embed[1],
            c4 + self.level_embed[2],
        )

    def forward(self, x: torch.Tensor):
        x = self._maybe_pad(x)
        _, _, height, width = x.shape
        deform_inputs1, deform_inputs2 = deform_inputs(x, self.patch_size)
        del deform_inputs1

        c1, c2, c3, c4 = self.spm(x)
        c2, c3, c4 = self._add_level_embed(c2, c3, c4)
        c2_len, c3_len = c2.size(1), c3.size(1)
        c = torch.cat([c2, c3, c4], dim=1)

        height_c, width_c = height // 16, width // 16
        height_toks, width_toks = height // self.patch_size, width // self.patch_size
        context = torch.no_grad() if self.frozen_backbone else nullcontext()
        with context:
            all_layers = self.dinov3.backbone.get_intermediate_layers(
                x,
                n=self.interaction_indexes,
                return_class_token=True,
                norm=self.norm)

        first_tokens, _ = all_layers[0]
        batch_size, _, dim = first_tokens.shape

        outs = []
        for idx, layer in enumerate(self.interactions):
            vit_tokens, cls_token = all_layers[idx]
            _, c, _ = layer(
                vit_tokens,
                c,
                cls_token,
                deform_inputs2,
                height_c,
                width_c)
            outs.append(
                vit_tokens.transpose(1, 2).view(
                    batch_size, dim, height_toks, width_toks).contiguous())

        c2 = c[:, 0:c2_len, :]
        c3 = c[:, c2_len:c2_len + c3_len, :]
        c4 = c[:, c2_len + c3_len:, :]

        c2 = c2.transpose(1, 2).view(
            batch_size, dim, height_c * 2, width_c * 2).contiguous()
        c3 = c3.transpose(1, 2).view(
            batch_size, dim, height_c, width_c).contiguous()
        c4 = c4.transpose(1, 2).view(
            batch_size, dim, height_c // 2, width_c // 2).contiguous()
        c1 = self.up(c2) + c1

        if self.add_vit_feature:
            x1, x2, x3, x4 = outs
            x1 = F.interpolate(
                x1, size=(4 * height_c, 4 * width_c), mode='bilinear',
                align_corners=False)
            x2 = F.interpolate(
                x2, size=(2 * height_c, 2 * width_c), mode='bilinear',
                align_corners=False)
            x3 = F.interpolate(
                x3, size=(height_c, width_c), mode='bilinear',
                align_corners=False)
            x4 = F.interpolate(
                x4, size=(height_c // 2, width_c // 2), mode='bilinear',
                align_corners=False)
            c1, c2, c3, c4 = c1 + x1, c2 + x2, c3 + x3, c4 + x4

        return (
            self.norm1(c1),
            self.norm2(c2),
            self.norm3(c3),
            self.norm4(c4),
        )
