"""Patch-wise linear segmentation head for PASTIS + DINOv3."""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
from mmengine.model import BaseModule
from mmseg.registry import MODELS


@MODELS.register_module()
class PASTISLinearProbeHead(BaseModule):
    """Linear per-token classifier expanded to pixel-level logits.

    The head maps each DINOv3 token to a ``patch_size x patch_size`` block of
    class logits.  For 256x256 inputs and ViT/16 features, this is equivalent to
    ``D -> num_classes * 16 * 16`` followed by a deterministic rearrange.
    """

    def __init__(
        self,
        in_channels: int,
        num_classes: int,
        patch_size: int = 16,
        init_cfg: Optional[dict] = None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        self.in_channels = in_channels
        self.num_classes = num_classes
        self.patch_size = patch_size
        self.proj = nn.Conv2d(
            in_channels,
            num_classes * patch_size * patch_size,
            kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        logits = self.proj(x)
        batch_size, _, feat_h, feat_w = logits.shape
        patch = self.patch_size
        logits = logits.view(
            batch_size,
            self.num_classes,
            patch,
            patch,
            feat_h,
            feat_w)
        logits = logits.permute(0, 1, 4, 2, 5, 3).contiguous()
        return logits.view(
            batch_size,
            self.num_classes,
            feat_h * patch,
            feat_w * patch)
