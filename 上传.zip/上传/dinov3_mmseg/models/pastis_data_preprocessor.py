"""Data preprocessor for PASTIS time-series tensors."""

from __future__ import annotations

from typing import Any, Dict

import torch
from mmengine.model import BaseDataPreprocessor
from mmseg.registry import MODELS


@MODELS.register_module()
class PASTISDataPreProcessor(BaseDataPreprocessor):
    """Move PASTIS batches to device and stack list inputs when needed."""

    def forward(self, data: Dict[str, Any], training: bool = False) -> Dict[str, Any]:
        data = self.cast_data(data)
        inputs = data['inputs']
        if isinstance(inputs, (list, tuple)):
            inputs = torch.stack(list(inputs), dim=0)
        data['inputs'] = inputs.float()
        return data
