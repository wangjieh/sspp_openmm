"""Hooks registered by the DINOv3 MMSeg project."""

from .freeze_backbone_hook import FreezeBackboneHook
from .pastis_unfreeze_hook import PASTISBackboneUnfreezeHook

__all__ = ['FreezeBackboneHook', 'PASTISBackboneUnfreezeHook']
