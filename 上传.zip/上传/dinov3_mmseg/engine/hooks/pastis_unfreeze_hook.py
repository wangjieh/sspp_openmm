"""Hook for staged PASTIS DINOv3 finetuning."""

from __future__ import annotations

from mmengine.hooks import Hook
from mmseg.registry import HOOKS


@HOOKS.register_module()
class PASTISBackboneUnfreezeHook(Hook):
    """Freeze DINOv3 first, then unfreeze and scale optimizer LR."""

    def __init__(self, unfreeze_epoch: int = 10, lr_mult: float = 0.1) -> None:
        self.unfreeze_epoch = unfreeze_epoch
        self.lr_mult = lr_mult
        self._unfrozen = False
        self._base_lrs = None

    def before_train(self, runner) -> None:
        optimizer = runner.optim_wrapper.optimizer
        self._base_lrs = [group['lr'] for group in optimizer.param_groups]

    def before_train_epoch(self, runner) -> None:
        model = runner.model.module if hasattr(runner.model, 'module') else runner.model
        if runner.epoch < self.unfreeze_epoch:
            if hasattr(model, 'set_backbone_frozen'):
                model.set_backbone_frozen(True)
            return

        if self._unfrozen:
            return

        if not hasattr(model, 'set_backbone_frozen'):
            raise AttributeError(
                'PASTISBackboneUnfreezeHook requires model.set_backbone_frozen().')
        model.set_backbone_frozen(False)
        optimizer = runner.optim_wrapper.optimizer
        if self._base_lrs is None:
            self._base_lrs = [group['lr'] for group in optimizer.param_groups]
        for param_group, base_lr in zip(optimizer.param_groups, self._base_lrs):
            param_group['lr'] = base_lr * self.lr_mult
        runner.logger.info(
            f'Unfroze DINOv3 backbone at epoch {runner.epoch}; '
            f'scaled optimizer LR by {self.lr_mult}.')
        self._unfrozen = True
