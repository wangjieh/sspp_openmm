"""Generic backbone freezing hook for MMSeg experiments."""

from __future__ import annotations

from mmengine.hooks import Hook
from mmseg.registry import HOOKS


@HOOKS.register_module()
class FreezeBackboneHook(Hook):
    """Freeze the model backbone while keeping heads and adapters trainable."""

    def __init__(self, freeze: bool = True) -> None:
        self.freeze = freeze

    @staticmethod
    def _unwrap_model(model):
        return model.module if hasattr(model, 'module') else model

    @staticmethod
    def _set_module_frozen(module, frozen: bool) -> None:
        for param in module.parameters():
            param.requires_grad = not frozen
        if frozen:
            module.eval()

    def _apply(self, runner) -> None:
        model = self._unwrap_model(runner.model)
        if not hasattr(model, 'backbone'):
            raise AttributeError('FreezeBackboneHook requires model.backbone.')

        backbone = model.backbone
        if hasattr(backbone, 'set_backbone_frozen'):
            backbone.set_backbone_frozen(self.freeze)
        else:
            self._set_module_frozen(backbone, self.freeze)

    def before_train(self, runner) -> None:
        self._apply(runner)

    def before_train_epoch(self, runner) -> None:
        self._apply(runner)
