"""Ningbo-2m semantic segmentation dataset."""

from __future__ import annotations

from typing import Optional, Sequence

from mmseg.datasets import BaseSegDataset
from mmseg.registry import DATASETS


def _build_palette(num_classes: int) -> list[list[int]]:
    palette = []
    for label in range(num_classes):
        palette.append([
            (37 * label) % 256,
            (17 * label + 83) % 256,
            (29 * label + 151) % 256,
        ])
    return palette


@DATASETS.register_module()
class Ningbo2mDataset(BaseSegDataset):
    """Ningbo-2m RGB tif segmentation dataset.

    Directory convention expected by configs:

    ``data_root/train/images``, ``data_root/train/masks``,
    ``data_root/val/images`` and ``data_root/val/masks``.
    """

    METAINFO = dict(
        classes=tuple(f'class_{idx}' for idx in range(73)),
        palette=_build_palette(73),
    )

    def __init__(
        self,
        classes: Optional[Sequence[str]] = None,
        palette: Optional[Sequence[Sequence[int]]] = None,
        img_suffix: str = '.tif',
        seg_map_suffix: str = '.tif',
        reduce_zero_label: bool = False,
        metainfo: Optional[dict] = None,
        **kwargs,
    ) -> None:
        metainfo = dict(metainfo or {})
        if classes is not None:
            metainfo['classes'] = tuple(classes)
        if palette is not None:
            metainfo['palette'] = [list(color) for color in palette]
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            reduce_zero_label=reduce_zero_label,
            metainfo=metainfo or None,
            **kwargs)
