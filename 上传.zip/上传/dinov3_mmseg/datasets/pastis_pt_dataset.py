"""PASTIS ``.pt`` dataset for DINOv3 semantic segmentation.

The preprocessed PASTIS split is expected to look like this::

    pastis_dataset_64/
      pastis_r_train/
        s2_images/0.pt
        targets.pt
      pastis_r_valid/
        s2_images/0.pt
        targets.pt
      pastis_r_test/
        s2_images/0.pt
        targets.pt

Each image tensor must be ``T x 13 x H x W``.  The dataset computes Sentinel-2
band min/max from the train split, normalizes all bands, selects RGB
``[B04, B03, B02]``, resizes RGB images and labels to the configured size, and
returns MMSeg-style ``SegDataSample`` objects.
"""

from __future__ import annotations

from pathlib import Path
from typing import ClassVar, Dict, List, Optional, Sequence, Tuple

import torch
import torch.nn.functional as F
from mmengine.structures import PixelData
from mmseg.registry import DATASETS
from mmseg.structures import SegDataSample
from torch.utils.data import Dataset


def _natural_pt_sort(paths: Sequence[Path]) -> List[Path]:
    def sort_key(path: Path):
        try:
            return (0, int(path.stem))
        except ValueError:
            return (1, path.stem)

    return sorted(paths, key=sort_key)


@DATASETS.register_module()
class PASTISPtDataset(Dataset):
    """Read preprocessed PASTIS Sentinel-2 tensors for MMSeg training.

    Args:
        data_root: Root directory containing ``pastis_r_train`` etc.
        split: One of ``train``, ``valid`` or ``test``.
        train_split: Split used for dataset-level band min/max statistics.
        image_size: Output spatial size for RGB time series and labels.
        rgb_indices: Sentinel-2 RGB indices in the preprocessed 13-band tensor.
            The default is ``(3, 2, 1)`` = ``B04, B03, B02``.
        ignore_index: Label value ignored by loss/evaluator. PASTIS uses ``-1``.
        band_min/band_max: Optional precomputed 13-band min/max. If omitted,
            they are scanned from ``train_split/s2_images/*.pt``.
    """

    METAINFO = dict(
        classes=tuple(f'class_{idx}' for idx in range(19)),
        palette=[
            [0, 0, 0],
            [230, 25, 75],
            [60, 180, 75],
            [255, 225, 25],
            [0, 130, 200],
            [245, 130, 48],
            [145, 30, 180],
            [70, 240, 240],
            [240, 50, 230],
            [210, 245, 60],
            [250, 190, 190],
            [0, 128, 128],
            [230, 190, 255],
            [170, 110, 40],
            [255, 250, 200],
            [128, 0, 0],
            [170, 255, 195],
            [128, 128, 0],
            [0, 0, 128],
        ],
    )

    SPLIT_DIRS: ClassVar[Dict[str, str]] = {
        'train': 'pastis_r_train',
        'valid': 'pastis_r_valid',
        'val': 'pastis_r_valid',
        'test': 'pastis_r_test',
    }
    _MINMAX_CACHE: ClassVar[Dict[Tuple[str, str], Tuple[torch.Tensor, torch.Tensor]]] = {}

    def __init__(
        self,
        data_root: str,
        split: str,
        train_split: str = 'train',
        image_size: int = 256,
        rgb_indices: Sequence[int] = (3, 2, 1),
        ignore_index: int = -1,
        band_min: Optional[Sequence[float]] = None,
        band_max: Optional[Sequence[float]] = None,
        metainfo: Optional[dict] = None,
    ) -> None:
        self.data_root = Path(data_root)
        self.split = split
        self.train_split = train_split
        self.image_size = image_size
        self.rgb_indices = tuple(rgb_indices)
        self.ignore_index = ignore_index
        self._metainfo = dict(self.METAINFO)
        if metainfo is not None:
            self._metainfo.update(metainfo)

        split_dir = self._resolve_split_dir(split)
        self.split_dir = self.data_root / split_dir
        self.image_dir = self.split_dir / 's2_images'
        self.target_path = self.split_dir / 'targets.pt'

        if not self.image_dir.is_dir():
            raise FileNotFoundError(f'Missing image directory: {self.image_dir}')
        if not self.target_path.is_file():
            raise FileNotFoundError(f'Missing target tensor: {self.target_path}')

        self.image_paths = _natural_pt_sort(list(self.image_dir.glob('*.pt')))
        if not self.image_paths:
            raise FileNotFoundError(f'No .pt image files found in {self.image_dir}')

        self.targets = torch.load(self.target_path, map_location='cpu')
        if not isinstance(self.targets, torch.Tensor):
            raise TypeError(f'{self.target_path} must contain a tensor.')
        if self.targets.ndim != 3:
            raise ValueError(
                f'{self.target_path} must have shape N x H x W, got '
                f'{tuple(self.targets.shape)}.')
        if len(self.image_paths) != int(self.targets.shape[0]):
            raise ValueError(
                f'Image/target count mismatch for {self.split_dir}: '
                f'{len(self.image_paths)} images vs {self.targets.shape[0]} targets.')

        if band_min is not None or band_max is not None:
            if band_min is None or band_max is None:
                raise ValueError('band_min and band_max must be provided together.')
            self.band_min = torch.as_tensor(band_min, dtype=torch.float32)
            self.band_max = torch.as_tensor(band_max, dtype=torch.float32)
        else:
            self.band_min, self.band_max = self._get_train_band_minmax()

        if self.band_min.numel() != 13 or self.band_max.numel() != 13:
            raise ValueError('band_min and band_max must contain 13 values.')
        for index in self.rgb_indices:
            if index < 0 or index >= 13:
                raise ValueError(f'RGB band index must be in [0, 12], got {index}.')

    @property
    def metainfo(self) -> dict:
        return self._metainfo

    def __len__(self) -> int:
        return len(self.image_paths)

    def __getitem__(self, index: int) -> dict:
        image = torch.load(self.image_paths[index], map_location='cpu')
        if not isinstance(image, torch.Tensor):
            raise TypeError(f'{self.image_paths[index]} must contain a tensor.')
        if image.ndim != 4 or image.shape[1] != 13:
            raise ValueError(
                f'{self.image_paths[index]} must have shape T x 13 x H x W, '
                f'got {tuple(image.shape)}.')

        rgb = self._normalize_select_resize_rgb(image)
        target = self._resize_target(self.targets[index])

        data_sample = SegDataSample()
        data_sample.gt_sem_seg = PixelData(data=target.unsqueeze(0))
        data_sample.set_metainfo(
            dict(
                img_path=str(self.image_paths[index]),
                seg_map_path=str(self.target_path),
                sample_idx=index,
                ori_shape=tuple(self.targets[index].shape[-2:]),
                img_shape=(self.image_size, self.image_size),
                pad_shape=(self.image_size, self.image_size),
            ))
        return dict(inputs=rgb, data_samples=data_sample)

    def _resolve_split_dir(self, split: str) -> str:
        return self.SPLIT_DIRS.get(split, split)

    def _get_train_band_minmax(self) -> Tuple[torch.Tensor, torch.Tensor]:
        train_dir = self.data_root / self._resolve_split_dir(self.train_split) / 's2_images'
        cache_key = (str(train_dir.resolve()), self.train_split)
        if cache_key not in self._MINMAX_CACHE:
            self._MINMAX_CACHE[cache_key] = self._scan_band_minmax(train_dir)
        return tuple(t.clone() for t in self._MINMAX_CACHE[cache_key])  # type: ignore[return-value]

    @staticmethod
    def _scan_band_minmax(image_dir: Path) -> Tuple[torch.Tensor, torch.Tensor]:
        image_paths = _natural_pt_sort(list(image_dir.glob('*.pt')))
        if not image_paths:
            raise FileNotFoundError(f'No .pt image files found in {image_dir}')

        band_min = torch.full((13, ), float('inf'), dtype=torch.float32)
        band_max = torch.full((13, ), float('-inf'), dtype=torch.float32)
        for image_path in image_paths:
            image = torch.load(image_path, map_location='cpu')
            if not isinstance(image, torch.Tensor):
                raise TypeError(f'{image_path} must contain a tensor.')
            if image.ndim != 4 or image.shape[1] != 13:
                raise ValueError(
                    f'{image_path} must have shape T x 13 x H x W, '
                    f'got {tuple(image.shape)}.')
            image = image.float()
            for band_idx in range(13):
                values = image[:, band_idx].reshape(-1)
                finite = values[torch.isfinite(values)]
                if finite.numel() == 0:
                    continue
                band_min[band_idx] = torch.minimum(band_min[band_idx], finite.min())
                band_max[band_idx] = torch.maximum(band_max[band_idx], finite.max())

        if not torch.isfinite(band_min).all() or not torch.isfinite(band_max).all():
            raise ValueError(f'Could not compute finite 13-band min/max from {image_dir}.')
        return band_min, band_max

    def _normalize_select_resize_rgb(self, image: torch.Tensor) -> torch.Tensor:
        image = image.float()
        band_min = self.band_min.view(1, 13, 1, 1)
        band_max = self.band_max.view(1, 13, 1, 1)
        denom = (band_max - band_min).clamp_min(1e-6)
        image = ((image - band_min) / denom).clamp(0.0, 1.0)

        # Match the DINOv3 eval preprocessing: quantize to uint8, then return
        # to [0, 1] floating point before satellite normalization in the model.
        image = (image * 255.0).clamp(0.0, 255.0).to(torch.uint8).float() / 255.0
        rgb = image[:, self.rgb_indices, :, :]
        if rgb.shape[-2:] != (self.image_size, self.image_size):
            rgb = F.interpolate(
                rgb,
                size=(self.image_size, self.image_size),
                mode='bilinear',
                align_corners=False)
        return rgb.contiguous()

    def _resize_target(self, target: torch.Tensor) -> torch.Tensor:
        target = target.long()
        if target.shape[-2:] == (self.image_size, self.image_size):
            return target.contiguous()
        target = F.interpolate(
            target[None, None].float(),
            size=(self.image_size, self.image_size),
            mode='nearest')
        return target[0, 0].long().contiguous()
