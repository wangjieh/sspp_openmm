# Copyright (c) Open-CD. All rights reserved.
"""CAU-FLOOD 数据集专用变换：rasterio 加载 + 无效区域掩膜。"""
import numpy as np
from mmcv.transforms.base import BaseTransform

from opencd.registry import TRANSFORMS

try:
    import rasterio
except ImportError:
    rasterio = None


@TRANSFORMS.register_module()
class CAUFloodLoadImageFromFile(BaseTransform):
    """使用 rasterio 加载 CAU-FLOOD 的双时相图像和标签，并计算无效区域掩膜。

    无效区域定义：光学 nodata（像素值全为0）或 SAR 像素值为0 的区域。
    无效区域在标签中设置为 255（ignore_index），不参与训练和评估。

    Required Keys:
    - img_path (list[str]): [光学影像路径, SAR影像路径]
    - seg_map_path (str, optional): 标签路径

    Modified Keys:
    - img: list[np.ndarray]  每个元素为 (H, W, C) uint8
    - img_shape, ori_shape, pad_shape, flip, flip_direction

    Added Keys:
    - gt_seg_map (np.ndarray): 标签 (H, W) uint8，无效区域已设为 255
    - gt_seg_ignore_map (np.ndarray): 无效区域掩膜 (H, W) uint8 (0=有效, 255=无效)
    - seg_fields: 包含 'gt_seg_map', 'gt_seg_ignore_map'
    """

    def __init__(self,
                 ignore_empty=False,
                 to_float32=False):
        super().__init__()
        self.ignore_empty = ignore_empty
        self.to_float32 = to_float32

    def transform(self, results: dict) -> dict:
        # ---- 加载图像 ----
        imgs = []
        for filepath in results['img_path']:
            img = self._load_image(filepath)
            if img is None:
                if self.ignore_empty:
                    return None
                raise FileNotFoundError(f'无法读取图像: {filepath}')
            imgs.append(img)
        results['img'] = imgs
        results['img_shape'] = imgs[0].shape[:2]
        results['ori_shape'] = imgs[0].shape[:2]
        results['pad_shape'] = results['img_shape']
        results['flip'] = False
        results['flip_direction'] = None

        # ---- 加载标签 + 计算无效区域掩膜（仅在有标签时） ----
        if results.get('seg_map_path') is not None:
            with rasterio.open(results['seg_map_path']) as src:
                label = src.read(1).astype(np.uint8)       # (H, W)

            opt_img = imgs[0]  # (H, W, 3) uint8
            sar_img = imgs[1]  # (H, W, 3) uint8（原始单通道已复制为3通道）

            # 光学 nodata：RGB 三通道全为 0
            opt_nodata = np.all(opt_img == 0, axis=-1)     # (H, W) bool
            # SAR 无效：原始单通道（取任一通道）为 0
            sar_invalid = (sar_img[:, :, 0] == 0)          # (H, W) bool
            # 综合无效掩膜
            ignore_mask = (opt_nodata | sar_invalid).astype(np.uint8) * 255

            # 标签中无效区域设为 255（ignore_index）
            label[ignore_mask == 255] = 255

            results['gt_seg_map'] = label
            results['gt_seg_ignore_map'] = ignore_mask
            results['seg_fields'] = ['gt_seg_map', 'gt_seg_ignore_map']

        return results

    # ------------------------------------------------------------------ #
    @staticmethod
    def _load_image(filepath):
        """使用 rasterio 读取单张图像，返回 (H, W, C) uint8。"""
        if rasterio is None:
            raise ImportError(
                'CAUFloodLoadImageFromFile 需要 rasterio，请先安装: '
                'pip install rasterio')
        try:
            with rasterio.open(filepath) as src:
                data = src.read()          # (bands, H, W)
                nodata_val = src.nodata
                if nodata_val is not None:
                    mask = (data == nodata_val)
                    data[mask] = 0
        except Exception as e:
            print(f'[CAUFloodLoader] 读取失败 {filepath}: {e}')
            return None

        if data.ndim == 2:
            data = data[np.newaxis, ...]   # (1, H, W)

        data = np.transpose(data, (1, 2, 0))  # (H, W, C)
        if data.shape[2] == 1:
            data = np.repeat(data, 3, axis=2)  # 灰度 → 3通道

        return data.astype(np.uint8)

    def __repr__(self):
        return (f'{self.__class__.__name__}('
                f'ignore_empty={self.ignore_empty})')


@TRANSFORMS.register_module()
class MultiImgApplyIgnoreMask(BaseTransform):
    """在数据增强之后、打包之前，将无效区域掩膜应用到标签上。

    本变换将 gt_seg_ignore_map 中标记为 255 的像素在 gt_seg_map 中
    也设置为 255（ignore_index），从而在计算损失时忽略这些区域。

    前置条件：CAUFloodLoadImageFromFile 已将 gt_seg_ignore_map 加入
    seg_fields，因此 RandomCrop / RandomFlip / RandomRotate 等变换会
    对其执行与 gt_seg_map 完全相同的几何变换，保持空间对齐。

    Required Keys:
    - gt_seg_map
    - gt_seg_ignore_map

    Modified Keys:
    - gt_seg_map: 无效区域设为 255
    """

    def transform(self, results: dict) -> dict:
        if ('gt_seg_map' in results
                and 'gt_seg_ignore_map' in results):
            results['gt_seg_map'][
                results['gt_seg_ignore_map'] == 255] = 255
        return results

    def __repr__(self):
        return f'{self.__class__.__name__}()'
