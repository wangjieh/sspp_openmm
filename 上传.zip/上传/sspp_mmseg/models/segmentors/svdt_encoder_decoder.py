"""SVDT segmentor with invalid-pixel inference post-processing."""

from __future__ import annotations

from ..._registry import MODELS


_IMPORT_ERROR = None

try:
    import torch
    import torch.nn.functional as F
    from mmseg.models.segmentors import EncoderDecoder
except ImportError as exc:  # pragma: no cover - local machines may lack MMSeg.
    torch = None
    F = None
    EncoderDecoder = object
    _IMPORT_ERROR = exc


if _IMPORT_ERROR is not None:

    @MODELS.register_module()
    class SVDTEncoderDecoder(EncoderDecoder):
        """Placeholder used when MMSegmentation is unavailable."""

        def __init__(self, *args, **kwargs):
            raise ImportError(
                "SVDTEncoderDecoder requires MMSegmentation and PyTorch. "
                f"The current import error was: {_IMPORT_ERROR!r}")

else:

    @MODELS.register_module()
    class SVDTEncoderDecoder(EncoderDecoder):
        """EncoderDecoder that forces SVDT invalid pixels to background."""

        def __init__(self,
                     *args,
                     force_invalid_to_background=True,
                     background_label=0,
                     invalid_mask_key="svdt_invalid_mask",
                     **kwargs):
            super().__init__(*args, **kwargs)
            self.force_invalid_to_background = force_invalid_to_background
            self.background_label = background_label
            self.invalid_mask_key = invalid_mask_key

        def postprocess_result(self, seg_logits, data_samples=None):
            data_samples = super().postprocess_result(seg_logits, data_samples)
            if not self.force_invalid_to_background:
                return data_samples

            for data_sample in data_samples:
                invalid_mask = data_sample.metainfo.get(self.invalid_mask_key)
                if invalid_mask is None or not hasattr(data_sample, "pred_sem_seg"):
                    continue

                pred = data_sample.pred_sem_seg.data
                mask = torch.as_tensor(
                    invalid_mask, dtype=torch.bool, device=pred.device)
                mask = self._resize_mask(mask, pred.shape[-2:])
                if pred.ndim == 3:
                    pred = pred.clone()
                    pred[:, mask] = self.background_label
                else:
                    pred = pred.clone()
                    pred[mask] = self.background_label
                data_sample.pred_sem_seg.data = pred

            return data_samples

        @staticmethod
        def _resize_mask(mask, target_shape):
            if mask.ndim == 3 and mask.shape[0] == 1:
                mask = mask[0]
            elif mask.ndim == 3 and mask.shape[-1] == 1:
                mask = mask[..., 0]
            if mask.ndim != 2:
                raise ValueError(
                    "SVDT invalid mask must have shape (H, W) or (1, H, W).")
            if tuple(mask.shape) == tuple(target_shape):
                return mask
            mask = F.interpolate(
                mask[None, None].float(),
                size=target_shape,
                mode="nearest")
            return mask[0, 0].bool()


__all__ = ["SVDTEncoderDecoder"]
