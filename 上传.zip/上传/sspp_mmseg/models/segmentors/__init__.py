"""Segmentor registrations for the SkySense++ MMSeg plugin."""

from .svdt_encoder_decoder import SVDTEncoderDecoder

__all__ = ["SVDTEncoderDecoder"]
