"""Dual-branch SkySense++ backbone for optical-SAR segmentation."""

from __future__ import annotations

from ..._registry import MODELS


_IMPORT_ERROR = None

try:
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from mmcv.cnn import ConvModule
    from mmengine.model import BaseModule

    from .skysensepp_backbones import SkySensePPS1, SkySensePPS2
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc


def _missing_dependency_message() -> str:
    return (
        "SkySense++ dual-branch backbone requires PyTorch, MMCV, MMEngine, "
        "MMSegmentation, and MMPRETRAIN 1.x. The current import error was: "
        f"{_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @MODELS.register_module()
    class SkySensePPDualBranchS1S2:
        """Placeholder used when OpenMMLab dependencies are unavailable."""

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    def _build_backbone(cfg, fallback_cls):
        if cfg is None:
            return fallback_cls()
        if not isinstance(cfg, dict):
            return cfg
        cfg = cfg.copy()
        if hasattr(MODELS, "build"):
            return MODELS.build(cfg)
        cfg.pop("type", None)
        return fallback_cls(**cfg)


    @MODELS.register_module()
    class SkySensePPDualBranchS1S2(BaseModule):
        """Fuse SkySense++ S2 optical and S1 SAR features.

        Input layout is 12 channels: 10 Sentinel-2-compatible channels followed
        by 2 Sentinel-1-compatible channels.
        """

        def __init__(self,
                     opt_backbone=None,
                     sar_backbone=None,
                     input_split=(10, 2),
                     feat_channels=1024,
                     out_channels=1024,
                     pyramid_scales=(1.0, 0.5, 0.25, 0.125),
                     norm_cfg=dict(type="SyncBN", requires_grad=True),
                     act_cfg=dict(type="ReLU"),
                     init_cfg=None):
            super().__init__(init_cfg=init_cfg)
            self.input_split = tuple(int(value) for value in input_split)
            if len(self.input_split) != 2:
                raise ValueError("input_split must contain OPT and SAR sizes.")
            self.pyramid_scales = tuple(float(value)
                                        for value in pyramid_scales)
            self.out_channels = int(out_channels)

            opt_backbone = opt_backbone or dict(
                type="SkySensePPS2", in_channels=self.input_split[0])
            sar_backbone = sar_backbone or dict(
                type="SkySensePPS1", in_channels=self.input_split[1])
            self.opt_backbone = _build_backbone(opt_backbone, SkySensePPS2)
            self.sar_backbone = _build_backbone(sar_backbone, SkySensePPS1)

            self.fusion_convs = nn.ModuleList([
                ConvModule(
                    feat_channels * 2,
                    self.out_channels,
                    kernel_size=1,
                    norm_cfg=norm_cfg,
                    act_cfg=act_cfg,
                ) for _ in self.pyramid_scales
            ])

        def forward(self, x):
            opt_channels, sar_channels = self.input_split
            expected_channels = opt_channels + sar_channels
            if x.shape[1] != expected_channels:
                raise ValueError(
                    f"Expected {expected_channels} input channels, got "
                    f"{x.shape[1]}.")

            opt_x = x[:, :opt_channels, :, :]
            sar_x = x[:, opt_channels:, :, :]
            opt_feats = self.opt_backbone(opt_x)
            sar_feats = self.sar_backbone(sar_x)
            if len(opt_feats) != len(sar_feats):
                raise ValueError(
                    "OPT and SAR backbones must return the same number of "
                    f"feature maps, got {len(opt_feats)} and {len(sar_feats)}.")
            if len(opt_feats) != len(self.fusion_convs):
                raise ValueError(
                    "pyramid_scales length must match backbone out_indices, "
                    f"got {len(self.fusion_convs)} and {len(opt_feats)}.")

            outs = []
            for opt_feat, sar_feat, fusion_conv, scale in zip(
                    opt_feats, sar_feats, self.fusion_convs,
                    self.pyramid_scales):
                fused = fusion_conv(torch.cat([opt_feat, sar_feat], dim=1))
                if scale != 1.0:
                    height = max(1, int(round(fused.shape[-2] * scale)))
                    width = max(1, int(round(fused.shape[-1] * scale)))
                    fused = F.interpolate(
                        fused,
                        size=(height, width),
                        mode="bilinear",
                        align_corners=False)
                outs.append(fused)
            return tuple(outs)


__all__ = ["SkySensePPDualBranchS1S2"]
