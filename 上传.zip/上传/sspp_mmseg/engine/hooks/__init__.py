"""Hook registrations for the SkySense++ MMSeg plugin."""

from .freeze_backbone_hook import FreezeBackboneHook

__all__ = ["FreezeBackboneHook"]

