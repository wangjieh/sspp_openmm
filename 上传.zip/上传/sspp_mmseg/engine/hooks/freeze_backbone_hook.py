"""Training hooks for staged SkySense++ fine-tuning."""

from __future__ import annotations

from ..._registry import HOOKS

try:
    from mmengine.hooks import Hook
except ImportError:  # pragma: no cover - local machines may lack MMEngine.

    class Hook:
        """Fallback base class used only for import-time checks."""


@HOOKS.register_module()
class FreezeBackboneHook(Hook):
    """Freeze ``model.backbone`` for the first ``freeze_epochs`` epochs."""

    priority = "NORMAL"

    def __init__(self, freeze_epochs=10):
        self.freeze_epochs = int(freeze_epochs)
        self._is_frozen = None

    def before_train(self, runner):
        self._set_state(runner, freeze=True)

    def before_train_epoch(self, runner):
        should_freeze = runner.epoch < self.freeze_epochs
        self._set_state(runner, freeze=should_freeze)

    def _set_state(self, runner, freeze):
        if self._is_frozen == freeze:
            return
        model = getattr(runner, "model", runner)
        model = getattr(model, "module", model)
        backbone = getattr(model, "backbone", None)
        if backbone is None:
            return
        for param in backbone.parameters():
            param.requires_grad = not freeze
        if freeze:
            backbone.eval()
        else:
            backbone.train()
        self._is_frozen = freeze

