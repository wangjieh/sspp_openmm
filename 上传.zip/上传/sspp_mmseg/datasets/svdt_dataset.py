"""SVDT semantic segmentation dataset."""

from __future__ import annotations

from .._registry import DATASETS

try:
    from mmseg.datasets import BaseSegDataset
except ImportError:  # pragma: no cover - local machines may lack MMSeg.
    BaseSegDataset = object


@DATASETS.register_module()
class SVDTDataset(BaseSegDataset):
    """SVDT cropland segmentation dataset.

    The annotation PNG stores background as 0 and cropland as 255. The
    ``SVDTMapAnnotationsAndIgnorePixels`` transform maps 255 to class 1 and
    ignores invalid RGB pixels in the image.
    """

    METAINFO = dict(
        classes=("background", "cropland"),
        palette=[[0, 0, 0], [0, 255, 0]],
    )

    def __init__(self,
                 img_suffix=".png",
                 seg_map_suffix=".png",
                 reduce_zero_label=False,
                 **kwargs):
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            reduce_zero_label=reduce_zero_label,
            **kwargs)

