"""Dataset registrations for the SkySense++ MMSeg plugin."""

from .svdt_dataset import SVDTDataset
from .transforms import *  # noqa: F401,F403

__all__ = ["SVDTDataset"]

