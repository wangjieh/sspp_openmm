"""Dataset registrations for the SkySense++ MMSeg plugin."""

from .loveda_dataset import LoveDADataset
from .ningbo2m_dataset import Ningbo2mDataset
from .ningbo2m_new_dataset import Ningbo2mNewDataset
from .svdt_dataset import SVDTDataset
from .transforms import *  # noqa: F401,F403
from .whu_opt_sar_dataset import WHUOptSARDataset

__all__ = [
    "SVDTDataset",
    "LoveDADataset",
    "Ningbo2mDataset",
    "Ningbo2mNewDataset",
    "WHUOptSARDataset",
]
