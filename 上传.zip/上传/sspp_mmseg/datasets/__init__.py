"""Dataset registrations for the SkySense++ MMSeg plugin."""

from .ningbo2m_dataset import Ningbo2mDataset
from .svdt_dataset import SVDTDataset
from .transforms import *  # noqa: F401,F403

__all__ = ["SVDTDataset", "Ningbo2mDataset"]
