"""Eight-class Ningbo-2m semantic segmentation dataset."""

from __future__ import annotations

from .._registry import DATASETS

try:
    from mmseg.datasets import BaseSegDataset
except ImportError:  # pragma: no cover - local machines may lack MMSeg.
    BaseSegDataset = object


@DATASETS.register_module()
class Ningbo2mNewDataset(BaseSegDataset):
    """Eight-class Ningbo-2m land-cover segmentation dataset.

    The mask TIFF stores valid classes as values 0 through 7 and uses 255 as
    ignore. White RGB image pixels are converted to ignore by
    ``Ningbo2mNewWhitePixelsToIgnore`` in the data pipeline.
    """

    METAINFO = dict(
        classes=(
            "Background",
            "Grass",
            "Bare_land",
            "Road",
            "Forest",
            "River",
            "Cropland",
            "Residential",
        ),
        palette=[
            [0, 0, 0],
            [124, 252, 0],
            [210, 180, 140],
            [128, 128, 128],
            [34, 139, 34],
            [0, 191, 255],
            [255, 215, 0],
            [220, 20, 60],
        ],
    )

    def __init__(self,
                 img_suffix=".tif",
                 seg_map_suffix=".tif",
                 reduce_zero_label=False,
                 **kwargs):
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            reduce_zero_label=reduce_zero_label,
            **kwargs)


__all__ = ["Ningbo2mNewDataset"]
