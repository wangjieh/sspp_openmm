"""WHU-OPT-SAR semantic segmentation dataset."""

from __future__ import annotations

from .._registry import DATASETS

try:
    import os.path as osp

    from mmengine import fileio
    from mmseg.datasets import BaseSegDataset
except ImportError:  # pragma: no cover - local machines may lack MMSeg.
    BaseSegDataset = object
    fileio = None
    osp = None


CLASSES = (
    "farmland",
    "city",
    "village",
    "water",
    "forest",
    "road",
    "others",
)

PALETTE = [
    [255, 255, 0],
    [255, 0, 0],
    [255, 128, 0],
    [0, 0, 255],
    [0, 128, 0],
    [128, 128, 128],
    [255, 255, 255],
]


@DATASETS.register_module()
class WHUOptSARDataset(BaseSegDataset):
    """WHU optical-SAR multimodal segmentation dataset.

    The dataset stores three sibling folders per split: ``opt`` for four-band
    optical TIFFs, ``sar`` for one-band SAR TIFFs, and ``lbl`` for labels.
    """

    METAINFO = dict(classes=CLASSES, palette=PALETTE)

    def __init__(self,
                 opt_suffix=".tif",
                 sar_suffix=".tif",
                 seg_map_suffix=".tif",
                 reduce_zero_label=False,
                 **kwargs):
        self.opt_suffix = opt_suffix
        self.sar_suffix = sar_suffix
        super().__init__(
            img_suffix=opt_suffix,
            seg_map_suffix=seg_map_suffix,
            reduce_zero_label=reduce_zero_label,
            **kwargs)

    def load_data_list(self):
        """Load OPT/SAR/LBL triplets."""
        if fileio is None or osp is None:
            raise ImportError("WHUOptSARDataset requires mmengine and mmseg.")

        data_list = []
        opt_dir = self.data_prefix.get("opt_path", None)
        sar_dir = self.data_prefix.get("sar_path", None)
        ann_dir = self.data_prefix.get("seg_map_path", None)
        if opt_dir is None or sar_dir is None or ann_dir is None:
            raise ValueError(
                "WHUOptSARDataset requires data_prefix keys: opt_path, "
                "sar_path, and seg_map_path.")

        for opt_name in fileio.list_dir_or_file(
                dir_path=opt_dir,
                list_dir=False,
                suffix=self.opt_suffix,
                recursive=True,
                backend_args=self.backend_args):
            stem = opt_name[:-len(self.opt_suffix)]
            sar_name = stem + self.sar_suffix
            seg_name = stem + self.seg_map_suffix
            opt_path = osp.join(opt_dir, opt_name)
            data_info = dict(
                img_path=opt_path,
                opt_path=opt_path,
                sar_path=osp.join(sar_dir, sar_name),
                seg_map_path=osp.join(ann_dir, seg_name),
                label_map=self.label_map,
                reduce_zero_label=self.reduce_zero_label,
                seg_fields=[],
            )
            data_list.append(data_info)

        return sorted(data_list, key=lambda item: item["opt_path"])


__all__ = ["WHUOptSARDataset"]
