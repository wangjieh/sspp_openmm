"""Ningbo-2m semantic segmentation dataset."""

from __future__ import annotations

from .._registry import DATASETS

try:
    from mmseg.datasets import BaseSegDataset
except ImportError:  # pragma: no cover - local machines may lack MMSeg.
    BaseSegDataset = object


def _make_palette(num_classes=73):
    return [
        [(37 * i) % 255, (17 * i + 89) % 255, (29 * i + 151) % 255]
        for i in range(num_classes)
    ]


@DATASETS.register_module()
class Ningbo2mDataset(BaseSegDataset):
    """Ningbo-2m land-cover segmentation dataset.

    The label TIFF stores valid classes as values 0 through 72 and uses 255 as
    ignore. White RGB image pixels are converted to ignore by
    ``Ningbo2mWhitePixelsToIgnore`` in the data pipeline.
    """

    METAINFO = dict(
        classes=tuple(str(i) for i in range(73)),
        palette=_make_palette(73),
    )

    def __init__(self,
                 img_suffix=".tif",
                 seg_map_suffix=".tif",
                 reduce_zero_label=False,
                 **kwargs):
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            reduce_zero_label=reduce_zero_label,
            **kwargs)


__all__ = ["Ningbo2mDataset"]
