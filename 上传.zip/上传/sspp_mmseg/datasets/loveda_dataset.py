"""LOVE-DA semantic segmentation dataset."""

from __future__ import annotations

from .._registry import DATASETS

try:
    from mmseg.datasets import BaseSegDataset
except ImportError:  # pragma: no cover - local machines may lack MMSeg.
    BaseSegDataset = object


@DATASETS.register_module()
class LoveDADataset(BaseSegDataset):
    """LOVE-DA land-cover segmentation dataset.

    The official mask values are 0 for no-data and 1 through 7 for semantic
    classes. ``LoveDALoadAnnotationsFromRasterio`` maps 0 to ignore and maps
    1..7 to contiguous training IDs 0..6.
    """

    METAINFO = dict(
        classes=(
            "Background",
            "Building",
            "Road",
            "Water",
            "Barren",
            "Forest",
            "Agriculture",
        ),
        palette=[
            [255, 255, 255],
            [255, 0, 0],
            [255, 255, 0],
            [0, 0, 255],
            [159, 129, 183],
            [0, 255, 0],
            [255, 195, 128],
        ],
    )

    def __init__(self,
                 img_suffix=".png",
                 seg_map_suffix=".png",
                 reduce_zero_label=False,
                 **kwargs):
        super().__init__(
            img_suffix=img_suffix,
            seg_map_suffix=seg_map_suffix,
            reduce_zero_label=reduce_zero_label,
            **kwargs)


__all__ = ["LoveDADataset"]
