"""SVDT-specific annotation and invalid-pixel transforms."""

from __future__ import annotations

from ..._registry import TRANSFORMS

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc
else:
    _NUMPY_IMPORT_ERROR = None

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Fallback base class with MMEngine-like call behavior."""

        def __call__(self, results):
            return self.transform(results)


def _require_numpy():
    if np is None:
        raise ImportError(
            "SVDT transforms require numpy. The import error was: "
            f"{_NUMPY_IMPORT_ERROR!r}")


def _invalid_pixel_mask(img, black_value=(0, 0, 0), white_value=(255, 255, 255)):
    _require_numpy()
    img = np.asarray(img)
    if img.ndim < 3 or img.shape[-1] < 3:
        return np.zeros(img.shape[:2], dtype=bool)
    rgb = img[..., :3]
    invalid_black = np.all(rgb == np.array(black_value, dtype=rgb.dtype), axis=-1)
    invalid_white = np.all(rgb == np.array(white_value, dtype=rgb.dtype), axis=-1)
    return invalid_black | invalid_white


def force_invalid_pixels_to_background(pred_seg,
                                       img,
                                       background_label=0,
                                       black_value=(0, 0, 0),
                                       white_value=(255, 255, 255)):
    """Force invalid RGB pixels to background in an inference prediction."""

    _require_numpy()
    pred = np.asarray(pred_seg).copy()
    pred[_invalid_pixel_mask(img, black_value, white_value)] = background_label
    return pred


@TRANSFORMS.register_module()
class SVDTMapAnnotationsAndIgnorePixels(BaseTransform):
    """Map SVDT labels and ignore invalid RGB pixels during training/eval."""

    def __init__(self,
                 background_value=0,
                 background_label=0,
                 crop_value=255,
                 crop_label=1,
                 ignore_index=255,
                 black_value=(0, 0, 0),
                 white_value=(255, 255, 255)):
        self.background_value = background_value
        self.background_label = background_label
        self.crop_value = crop_value
        self.crop_label = crop_label
        self.ignore_index = ignore_index
        self.black_value = tuple(black_value)
        self.white_value = tuple(white_value)

    def transform(self, results):
        _require_numpy()
        invalid_mask = None
        if "img" in results:
            invalid_mask = _invalid_pixel_mask(
                results["img"], self.black_value, self.white_value)
            results["svdt_invalid_mask"] = invalid_mask

        if "gt_seg_map" not in results:
            return results

        gt_seg_map = np.asarray(results["gt_seg_map"]).copy()
        gt_seg_map[gt_seg_map == self.background_value] = self.background_label
        gt_seg_map[gt_seg_map == self.crop_value] = self.crop_label

        if invalid_mask is not None:
            gt_seg_map[invalid_mask] = self.ignore_index

        results["gt_seg_map"] = gt_seg_map.astype(np.uint8, copy=False)
        return results


@TRANSFORMS.register_module()
class SVDTForceInvalidPixelsToBackground(BaseTransform):
    """Post-process predictions so invalid image pixels become background."""

    def __init__(self,
                 background_label=0,
                 black_value=(0, 0, 0),
                 white_value=(255, 255, 255)):
        self.background_label = background_label
        self.black_value = tuple(black_value)
        self.white_value = tuple(white_value)

    def transform(self, results):
        pred_key = "pred_seg_map" if "pred_seg_map" in results else "pred_sem_seg"
        if pred_key in results and "img" in results:
            results[pred_key] = force_invalid_pixels_to_background(
                results[pred_key],
                results["img"],
                self.background_label,
                self.black_value,
                self.white_value)
        return results
