"""WHU-OPT-SAR rasterio loading and label mapping transforms."""

from __future__ import annotations

from ..._registry import TRANSFORMS

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc
else:
    _NUMPY_IMPORT_ERROR = None

try:
    import rasterio
except ImportError as exc:  # pragma: no cover
    rasterio = None
    _RASTERIO_IMPORT_ERROR = exc
else:
    _RASTERIO_IMPORT_ERROR = None

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Fallback base class with MMEngine-like call behavior."""

        def __call__(self, results):
            return self.transform(results)


DEFAULT_LABEL_MAP = {
    10: 0,
    20: 1,
    30: 2,
    40: 3,
    50: 4,
    60: 5,
    70: 6,
}
DEFAULT_OPT_MEAN = (104.695, 96.718, 79.112, 100.777)
DEFAULT_OPT_STD = (25.109, 27.273, 29.714, 32.046)
DEFAULT_SAR_MEAN = (54.002, )
DEFAULT_SAR_STD = (48.704, )


def _require_numpy():
    if np is None:
        raise ImportError(
            "WHU-OPT-SAR transforms require numpy. The import error was: "
            f"{_NUMPY_IMPORT_ERROR!r}")


def _require_rasterio():
    if rasterio is None:
        raise ImportError(
            "WHU-OPT-SAR transforms require rasterio. The import error was: "
            f"{_RASTERIO_IMPORT_ERROR!r}")


def _read_raster(path):
    _require_rasterio()
    with rasterio.open(path) as dataset:
        return dataset.read()


@TRANSFORMS.register_module()
class WHUOptSARLoadRasterio(BaseTransform):
    """Load WHU optical/SAR TIFFs and labels with rasterio.

    The output image has 12 channels: 10 Sentinel-2 slots followed by 2
    Sentinel-1 slots. Available WHU bands are normalized and copied into their
    corresponding pretrained slots; unavailable slots stay zero.
    """

    def __init__(self,
                 opt_channel_indices=(0, 1, 2, 6),
                 sar_channel_indices=(10, ),
                 output_channels=12,
                 opt_mean=DEFAULT_OPT_MEAN,
                 opt_std=DEFAULT_OPT_STD,
                 sar_mean=DEFAULT_SAR_MEAN,
                 sar_std=DEFAULT_SAR_STD,
                 label_map=DEFAULT_LABEL_MAP,
                 ignore_index=255):
        self.opt_channel_indices = tuple(int(index)
                                         for index in opt_channel_indices)
        self.sar_channel_indices = tuple(int(index)
                                         for index in sar_channel_indices)
        self.output_channels = int(output_channels)
        self.opt_mean = tuple(float(value) for value in opt_mean)
        self.opt_std = tuple(float(value) for value in opt_std)
        self.sar_mean = tuple(float(value) for value in sar_mean)
        self.sar_std = tuple(float(value) for value in sar_std)
        self.label_map = {int(k): int(v) for k, v in dict(label_map).items()}
        self.ignore_index = int(ignore_index)

    def transform(self, results):
        _require_numpy()

        opt = _read_raster(results["opt_path"])
        sar = _read_raster(results["sar_path"])
        h, w = opt.shape[1:]
        image = np.zeros((h, w, self.output_channels), dtype=np.float32)

        for source_index, target_index in enumerate(self.opt_channel_indices):
            band = opt[source_index].astype(np.float32)
            image[..., target_index] = (
                band - self.opt_mean[source_index]) / self.opt_std[source_index]

        for source_index, target_index in enumerate(self.sar_channel_indices):
            band = sar[source_index].astype(np.float32)
            image[..., target_index] = (
                band - self.sar_mean[source_index]) / self.sar_std[source_index]

        results["img"] = image
        results["img_shape"] = image.shape[:2]
        results["ori_shape"] = image.shape[:2]
        results["whu_opt_sar_present_channels"] = (
            self.opt_channel_indices + self.sar_channel_indices)

        if "seg_map_path" in results:
            label = _read_raster(results["seg_map_path"])[0]
            mapped = np.full(label.shape, self.ignore_index, dtype=np.uint8)
            for old_value, new_value in self.label_map.items():
                mapped[label == old_value] = new_value
            results["gt_seg_map"] = mapped
            results.setdefault("seg_fields", []).append("gt_seg_map")

        return results


__all__ = ["WHUOptSARLoadRasterio"]
