"""LOVE-DA rasterio loading and label transforms."""

from __future__ import annotations

from ..._registry import TRANSFORMS

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc
else:
    _NUMPY_IMPORT_ERROR = None

try:
    import rasterio
except ImportError as exc:  # pragma: no cover
    rasterio = None
    _RASTERIO_IMPORT_ERROR = exc
else:
    _RASTERIO_IMPORT_ERROR = None

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Fallback base class with MMEngine-like call behavior."""

        def __call__(self, results):
            return self.transform(results)


def _require_numpy():
    if np is None:
        raise ImportError(
            "LOVE-DA transforms require numpy. The import error was: "
            f"{_NUMPY_IMPORT_ERROR!r}")


def _require_rasterio():
    if rasterio is None:
        raise ImportError(
            "LOVE-DA rasterio loaders require rasterio. The import error "
            f"was: {_RASTERIO_IMPORT_ERROR!r}")


def _as_hwc_image(data):
    if data.ndim == 2:
        return data
    if data.ndim != 3:
        raise ValueError(f"Expected rasterio array with 2 or 3 dims, got "
                         f"shape {data.shape}.")
    if data.shape[0] == 1:
        return data[0]
    return data[:3].transpose(1, 2, 0)


def map_loveda_labels(gt_seg_map, ignore_index=255, invalid_to_ignore=True):
    """Map LOVE-DA original labels to contiguous training labels."""
    _require_numpy()
    gt_seg_map = np.asarray(gt_seg_map, dtype=np.uint8)
    mapped = np.full(gt_seg_map.shape, int(ignore_index), dtype=np.uint8)
    valid_mask = (gt_seg_map >= 1) & (gt_seg_map <= 7)
    mapped[valid_mask] = gt_seg_map[valid_mask] - 1

    if not invalid_to_ignore:
        invalid_mask = ~(valid_mask | (gt_seg_map == 0))
        mapped[invalid_mask] = gt_seg_map[invalid_mask]
    return mapped


@TRANSFORMS.register_module()
class LoveDALoadImageFromRasterio(BaseTransform):
    """Load LOVE-DA PNG images with rasterio without geospatial processing."""

    def __init__(self, to_float32=False):
        self.to_float32 = bool(to_float32)

    def transform(self, results):
        _require_numpy()
        _require_rasterio()

        with rasterio.open(results["img_path"]) as dataset:
            img = _as_hwc_image(dataset.read())

        if self.to_float32:
            img = img.astype(np.float32)

        results["img"] = img
        results["img_shape"] = img.shape[:2]
        results["ori_shape"] = img.shape[:2]
        return results


@TRANSFORMS.register_module()
class LoveDALoadAnnotationsFromRasterio(BaseTransform):
    """Load LOVE-DA PNG masks and map labels for training.

    Mapping:
        original 0 -> ignore_index
        original 1..7 -> training labels 0..6
    """

    def __init__(self,
                 reduce_zero_label=None,
                 ignore_index=255,
                 invalid_to_ignore=True):
        self.reduce_zero_label = reduce_zero_label
        self.ignore_index = int(ignore_index)
        self.invalid_to_ignore = bool(invalid_to_ignore)

    def transform(self, results):
        _require_numpy()
        _require_rasterio()

        with rasterio.open(results["seg_map_path"]) as dataset:
            gt_seg_map = dataset.read(1).astype(np.uint8, copy=False)

        reduce_zero_label = results.get("reduce_zero_label", False)
        if self.reduce_zero_label is None:
            self.reduce_zero_label = reduce_zero_label
        assert self.reduce_zero_label == reduce_zero_label, (
            "Initialize loader with reduce_zero_label as "
            f"{self.reduce_zero_label} but dataset uses {reduce_zero_label}.")

        mapped = map_loveda_labels(
            gt_seg_map,
            ignore_index=self.ignore_index,
            invalid_to_ignore=self.invalid_to_ignore)

        results["gt_seg_map"] = mapped
        results.setdefault("seg_fields", []).append("gt_seg_map")
        results["loveda_label_map"] = {label: label - 1 for label in range(1, 8)}
        return results


__all__ = [
    "LoveDALoadImageFromRasterio",
    "LoveDALoadAnnotationsFromRasterio",
    "map_loveda_labels",
]
