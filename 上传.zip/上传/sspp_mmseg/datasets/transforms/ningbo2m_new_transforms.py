"""Transforms for the eight-class Ningbo-2m dataset."""

from __future__ import annotations

from ..._registry import TRANSFORMS

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc
else:
    _NUMPY_IMPORT_ERROR = None

try:
    import rasterio
except ImportError as exc:  # pragma: no cover
    rasterio = None
    _RASTERIO_IMPORT_ERROR = exc
else:
    _RASTERIO_IMPORT_ERROR = None

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Fallback base class with MMEngine-like call behavior."""

        def __call__(self, results):
            return self.transform(results)


def _require_numpy():
    if np is None:
        raise ImportError(
            "Ningbo-2m-new transforms require numpy. The import error was: "
            f"{_NUMPY_IMPORT_ERROR!r}")


def _require_rasterio():
    if rasterio is None:
        raise ImportError(
            "Ningbo-2m-new rasterio loaders require rasterio. The import "
            f"error was: {_RASTERIO_IMPORT_ERROR!r}")


def _as_hwc_image(data):
    if data.ndim == 2:
        return data
    if data.ndim != 3:
        raise ValueError(f"Expected rasterio array with 2 or 3 dims, got "
                         f"shape {data.shape}.")
    if data.shape[0] == 1:
        return data[0]
    return data.transpose(1, 2, 0)


@TRANSFORMS.register_module()
class Ningbo2mNewLoadImageFromRasterio(BaseTransform):
    """Load eight-class Ningbo-2m RGB TIFF images with rasterio."""

    def __init__(self, to_float32=False):
        self.to_float32 = bool(to_float32)

    def transform(self, results):
        _require_numpy()
        _require_rasterio()

        with rasterio.open(results["img_path"]) as dataset:
            img = _as_hwc_image(dataset.read())

        if self.to_float32:
            img = img.astype(np.float32)

        results["img"] = img
        results["img_shape"] = img.shape[:2]
        results["ori_shape"] = img.shape[:2]
        return results


@TRANSFORMS.register_module()
class Ningbo2mNewLoadAnnotationsFromRasterio(BaseTransform):
    """Load eight-class Ningbo-2m TIFF segmentation masks with rasterio."""

    def __init__(self,
                 reduce_zero_label=None,
                 valid_labels=tuple(range(8)),
                 ignore_index=255,
                 invalid_to_ignore=True):
        self.reduce_zero_label = reduce_zero_label
        self.valid_labels = tuple(int(label) for label in valid_labels)
        self.ignore_index = int(ignore_index)
        self.invalid_to_ignore = bool(invalid_to_ignore)

    def transform(self, results):
        _require_numpy()
        _require_rasterio()

        with rasterio.open(results["seg_map_path"]) as dataset:
            gt_seg_map = dataset.read(1).astype(np.uint8, copy=False)

        reduce_zero_label = results.get("reduce_zero_label", False)
        if self.reduce_zero_label is None:
            self.reduce_zero_label = reduce_zero_label
        assert self.reduce_zero_label == reduce_zero_label, (
            "Initialize loader with reduce_zero_label as "
            f"{self.reduce_zero_label} but dataset uses {reduce_zero_label}.")
        if self.reduce_zero_label:
            gt_seg_map[gt_seg_map == 0] = self.ignore_index
            gt_seg_map = gt_seg_map - 1
            gt_seg_map[gt_seg_map == self.ignore_index - 1] = self.ignore_index

        if self.invalid_to_ignore:
            valid = np.isin(gt_seg_map, self.valid_labels)
            ignore = gt_seg_map == self.ignore_index
            gt_seg_map = gt_seg_map.copy()
            gt_seg_map[~(valid | ignore)] = self.ignore_index

        results["gt_seg_map"] = gt_seg_map
        results.setdefault("seg_fields", []).append("gt_seg_map")
        return results


@TRANSFORMS.register_module()
class Ningbo2mNewWhitePixelsToIgnore(BaseTransform):
    """Set mask pixels to ignore where the RGB image is pure white."""

    def __init__(self, white_value=(255, 255, 255), ignore_index=255):
        self.white_value = tuple(white_value)
        self.ignore_index = int(ignore_index)

    def transform(self, results):
        _require_numpy()
        if "img" not in results:
            return results

        img = np.asarray(results["img"])
        if img.ndim < 3 or img.shape[-1] < 3:
            white_mask = np.zeros(img.shape[:2], dtype=bool)
        else:
            rgb = img[..., :3]
            white_value = np.array(self.white_value, dtype=rgb.dtype)
            white_mask = np.all(rgb == white_value, axis=-1)
        results["ningbo2m_new_white_ignore_mask"] = white_mask

        if "gt_seg_map" not in results:
            return results

        gt_seg_map = np.asarray(results["gt_seg_map"]).copy()
        gt_seg_map[white_mask] = self.ignore_index
        results["gt_seg_map"] = gt_seg_map.astype(np.uint8, copy=False)
        return results


__all__ = [
    "Ningbo2mNewLoadImageFromRasterio",
    "Ningbo2mNewLoadAnnotationsFromRasterio",
    "Ningbo2mNewWhitePixelsToIgnore",
]
