"""Ningbo-2m-specific ignore-mask transforms."""

from __future__ import annotations

from ..._registry import TRANSFORMS

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc
else:
    _NUMPY_IMPORT_ERROR = None

try:
    import rasterio
except ImportError as exc:  # pragma: no cover
    rasterio = None
    _RASTERIO_IMPORT_ERROR = exc
else:
    _RASTERIO_IMPORT_ERROR = None

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Fallback base class with MMEngine-like call behavior."""

        def __call__(self, results):
            return self.transform(results)


def _require_numpy():
    if np is None:
        raise ImportError(
            "Ningbo-2m transforms require numpy. The import error was: "
            f"{_NUMPY_IMPORT_ERROR!r}")


def _require_rasterio():
    if rasterio is None:
        raise ImportError(
            "Ningbo-2m rasterio loaders require rasterio. The import error "
            f"was: {_RASTERIO_IMPORT_ERROR!r}")


def _as_hwc_image(data):
    if data.ndim == 2:
        return data
    if data.ndim != 3:
        raise ValueError(f"Expected rasterio array with 2 or 3 dims, got "
                         f"shape {data.shape}.")
    if data.shape[0] == 1:
        return data[0]
    return data.transpose(1, 2, 0)


@TRANSFORMS.register_module()
class Ningbo2mLoadImageFromRasterio(BaseTransform):
    """Load Ningbo-2m TIF images with rasterio."""

    def __init__(self, to_float32=False):
        self.to_float32 = bool(to_float32)

    def transform(self, results):
        _require_numpy()
        _require_rasterio()

        with rasterio.open(results["img_path"]) as dataset:
            img = _as_hwc_image(dataset.read())

        if self.to_float32:
            img = img.astype(np.float32)

        results["img"] = img
        results["img_shape"] = img.shape[:2]
        results["ori_shape"] = img.shape[:2]
        return results


@TRANSFORMS.register_module()
class Ningbo2mLoadAnnotationsFromRasterio(BaseTransform):
    """Load Ningbo-2m TIF segmentation masks with rasterio."""

    def __init__(self, reduce_zero_label=None, apply_dataset_label_map=True):
        self.reduce_zero_label = reduce_zero_label
        self.apply_dataset_label_map = bool(apply_dataset_label_map)

    def transform(self, results):
        _require_numpy()
        _require_rasterio()

        with rasterio.open(results["seg_map_path"]) as dataset:
            gt_seg_map = dataset.read(1).astype(np.uint8, copy=False)

        reduce_zero_label = results.get("reduce_zero_label", False)
        if self.reduce_zero_label is None:
            self.reduce_zero_label = reduce_zero_label
        assert self.reduce_zero_label == reduce_zero_label, (
            "Initialize loader with reduce_zero_label as "
            f"{self.reduce_zero_label} but dataset uses {reduce_zero_label}.")
        if self.reduce_zero_label:
            gt_seg_map[gt_seg_map == 0] = 255
            gt_seg_map = gt_seg_map - 1
            gt_seg_map[gt_seg_map == 254] = 255

        label_map = (
            results.get("label_map") if self.apply_dataset_label_map else None)
        if label_map is not None:
            gt_seg_map_copy = gt_seg_map.copy()
            for old_id, new_id in label_map.items():
                gt_seg_map[gt_seg_map_copy == old_id] = new_id

        results["gt_seg_map"] = gt_seg_map
        results.setdefault("seg_fields", []).append("gt_seg_map")
        return results


@TRANSFORMS.register_module()
class Ningbo2mWhitePixelsToIgnore(BaseTransform):
    """Set mask pixels to ignore where the RGB image is pure white."""

    def __init__(self, white_value=(255, 255, 255), ignore_index=255):
        self.white_value = tuple(white_value)
        self.ignore_index = int(ignore_index)

    def transform(self, results):
        _require_numpy()
        if "img" not in results:
            return results

        img = np.asarray(results["img"])
        if img.ndim < 3 or img.shape[-1] < 3:
            white_mask = np.zeros(img.shape[:2], dtype=bool)
        else:
            rgb = img[..., :3]
            white_value = np.array(self.white_value, dtype=rgb.dtype)
            white_mask = np.all(rgb == white_value, axis=-1)
        results["ningbo2m_white_ignore_mask"] = white_mask

        if "gt_seg_map" not in results:
            return results

        gt_seg_map = np.asarray(results["gt_seg_map"]).copy()
        gt_seg_map[white_mask] = self.ignore_index
        results["gt_seg_map"] = gt_seg_map.astype(np.uint8, copy=False)
        return results


@TRANSFORMS.register_module()
class Ningbo2mLabelsToIgnore(BaseTransform):
    """Set configured Ningbo-2m label values to ignore."""

    def __init__(self, labels=(), ignore_index=255):
        self.labels = tuple(int(label) for label in labels)
        self.ignore_index = int(ignore_index)

    def transform(self, results):
        _require_numpy()
        if "gt_seg_map" not in results or not self.labels:
            return results

        gt_seg_map = np.asarray(results["gt_seg_map"]).copy()
        ignore_mask = np.isin(gt_seg_map, self.labels)
        results["ningbo2m_no_train_mask"] = ignore_mask
        gt_seg_map[ignore_mask] = self.ignore_index
        results["gt_seg_map"] = gt_seg_map.astype(np.uint8, copy=False)
        return results


@TRANSFORMS.register_module()
class Ningbo2mRemapLabels(BaseTransform):
    """Remap remaining Ningbo-2m labels to contiguous training IDs."""

    def __init__(self, label_map, ignore_index=255):
        self.label_map = {
            int(old_label): int(new_label)
            for old_label, new_label in dict(label_map).items()
        }
        self.ignore_index = int(ignore_index)

    def transform(self, results):
        _require_numpy()
        if "gt_seg_map" not in results:
            return results

        gt_seg_map = np.asarray(results["gt_seg_map"])
        remapped = np.full(gt_seg_map.shape, self.ignore_index, dtype=np.uint8)
        for old_label, new_label in self.label_map.items():
            remapped[gt_seg_map == old_label] = new_label

        results["gt_seg_map"] = remapped
        results["ningbo2m_label_map"] = self.label_map
        return results


__all__ = [
    "Ningbo2mLoadImageFromRasterio",
    "Ningbo2mLoadAnnotationsFromRasterio",
    "Ningbo2mWhitePixelsToIgnore",
    "Ningbo2mLabelsToIgnore",
    "Ningbo2mRemapLabels",
]
