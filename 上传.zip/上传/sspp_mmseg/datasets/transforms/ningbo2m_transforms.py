"""Ningbo-2m-specific ignore-mask transforms."""

from __future__ import annotations

from ..._registry import TRANSFORMS

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc
else:
    _NUMPY_IMPORT_ERROR = None

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Fallback base class with MMEngine-like call behavior."""

        def __call__(self, results):
            return self.transform(results)


def _require_numpy():
    if np is None:
        raise ImportError(
            "Ningbo-2m transforms require numpy. The import error was: "
            f"{_NUMPY_IMPORT_ERROR!r}")


@TRANSFORMS.register_module()
class Ningbo2mWhitePixelsToIgnore(BaseTransform):
    """Set mask pixels to ignore where the RGB image is pure white."""

    def __init__(self, white_value=(255, 255, 255), ignore_index=255):
        self.white_value = tuple(white_value)
        self.ignore_index = int(ignore_index)

    def transform(self, results):
        _require_numpy()
        if "img" not in results:
            return results

        img = np.asarray(results["img"])
        if img.ndim < 3 or img.shape[-1] < 3:
            white_mask = np.zeros(img.shape[:2], dtype=bool)
        else:
            rgb = img[..., :3]
            white_value = np.array(self.white_value, dtype=rgb.dtype)
            white_mask = np.all(rgb == white_value, axis=-1)
        results["ningbo2m_white_ignore_mask"] = white_mask

        if "gt_seg_map" not in results:
            return results

        gt_seg_map = np.asarray(results["gt_seg_map"]).copy()
        gt_seg_map[white_mask] = self.ignore_index
        results["gt_seg_map"] = gt_seg_map.astype(np.uint8, copy=False)
        return results


@TRANSFORMS.register_module()
class Ningbo2mLabelsToIgnore(BaseTransform):
    """Set configured Ningbo-2m label values to ignore."""

    def __init__(self, labels=(), ignore_index=255):
        self.labels = tuple(int(label) for label in labels)
        self.ignore_index = int(ignore_index)

    def transform(self, results):
        _require_numpy()
        if "gt_seg_map" not in results or not self.labels:
            return results

        gt_seg_map = np.asarray(results["gt_seg_map"]).copy()
        ignore_mask = np.isin(gt_seg_map, self.labels)
        results["ningbo2m_no_train_mask"] = ignore_mask
        gt_seg_map[ignore_mask] = self.ignore_index
        results["gt_seg_map"] = gt_seg_map.astype(np.uint8, copy=False)
        return results


__all__ = ["Ningbo2mWhitePixelsToIgnore", "Ningbo2mLabelsToIgnore"]
