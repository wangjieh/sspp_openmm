"""SkySense++ HR UPerNet config for LOVE-DA semantic segmentation."""

custom_imports = dict(imports=["sspp_mmseg"], allow_failed_imports=False)

default_scope = "mmseg"
env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method="fork", opencv_num_threads=0),
    dist_cfg=dict(backend="nccl"))
find_unused_parameters = True
model_wrapper_cfg = dict(
    type="MMDistributedDataParallel", find_unused_parameters=True)
launcher = "pytorch"
log_level = "INFO"
load_from = None
resume = False

data_root = "data/LOVE-DA"
pretrained = "pretrain/skysensepp_release_hr.pth"
dataset_type = "LoveDADataset"
input_size = (512, 512)
ignore_index = 255
classes = (
    "Background",
    "Building",
    "Road",
    "Water",
    "Barren",
    "Forest",
    "Agriculture",
)
palette = [
    [255, 255, 255],
    [255, 0, 0],
    [255, 255, 0],
    [0, 0, 255],
    [159, 129, 183],
    [0, 255, 0],
    [255, 195, 128],
]
num_classes = len(classes)
metainfo = dict(classes=classes, palette=palette)
hr_channels = [352, 704, 1408, 2816]
norm_cfg = dict(type="SyncBN", requires_grad=True)

data_preprocessor = dict(
    type="SegDataPreProcessor",
    mean=[123.675, 116.28, 103.53],
    std=[58.395, 57.12, 57.375],
    bgr_to_rgb=False,
    pad_val=0,
    seg_pad_val=ignore_index,
    size=input_size)

pack_meta_keys = (
    "img_path",
    "seg_map_path",
    "ori_shape",
    "img_shape",
    "pad_shape",
    "scale_factor",
    "flip",
    "flip_direction",
    "reduce_zero_label",
)

train_pipeline = [
    dict(type="LoveDALoadImageFromRasterio"),
    dict(type="LoveDALoadAnnotationsFromRasterio", ignore_index=ignore_index),
    dict(type="RandomCrop", crop_size=input_size, cat_max_ratio=0.95),
    dict(type="RandomFlip", prob=0.5),
    dict(type="PackSegInputs", meta_keys=pack_meta_keys),
]
val_pipeline = [
    dict(type="LoveDALoadImageFromRasterio"),
    dict(type="LoveDALoadAnnotationsFromRasterio", ignore_index=ignore_index),
    dict(type="PackSegInputs", meta_keys=pack_meta_keys),
]
test_pipeline = [
    dict(type="LoveDALoadImageFromRasterio"),
    dict(type="PackSegInputs", meta_keys=pack_meta_keys),
]

train_dataloader = dict(
    batch_size=8,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=True),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        metainfo=metainfo,
        data_prefix=dict(
            img_path="img_dir/train",
            seg_map_path="ann_dir/train",
        ),
        pipeline=train_pipeline))
val_dataloader = dict(
    batch_size=1,
    num_workers=2,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        metainfo=metainfo,
        data_prefix=dict(
            img_path="img_dir/val",
            seg_map_path="ann_dir/val",
        ),
        pipeline=val_pipeline))
test_dataloader = dict(
    batch_size=1,
    num_workers=2,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        metainfo=metainfo,
        data_prefix=dict(img_path="img_dir/test"),
        pipeline=test_pipeline,
        test_mode=True))

val_evaluator = dict(type="IoUMetric", iou_metrics=["mIoU"])
test_evaluator = dict(
    type="IoUMetric",
    iou_metrics=["mIoU"],
    format_only=True,
    output_dir="work_dirs/loveda_hr_upernet_20e_512x512/test_results")

model = dict(
    type="EncoderDecoder",
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type="SkySensePPHR",
        in_channels=3,
        patch_size=4,
        window_size=8,
        init_cfg=dict(type="Pretrained", checkpoint=pretrained),
        out_indices=(0, 1, 2, 3)),
    decode_head=dict(
        type="UPerHead",
        in_channels=hr_channels,
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=512,
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        ignore_index=ignore_index,
        loss_decode=dict(
            type="CrossEntropyLoss",
            use_sigmoid=False,
            loss_weight=1.0)),
    train_cfg=dict(),
    test_cfg=dict(mode="whole"))

optim_wrapper = dict(
    type="OptimWrapper",
    optimizer=dict(
        type="AdamW", lr=5e-4, betas=(0.9, 0.999), weight_decay=0.01),
    clip_grad=dict(max_norm=1.0, norm_type=2))
param_scheduler = [
    dict(
        type="LinearLR",
        start_factor=1e-6,
        by_epoch=False,
        begin=0,
        end=1500),
    dict(type="PolyLR", eta_min=0.0, power=1.0, begin=0, end=20,
         by_epoch=True),
]

train_cfg = dict(type="EpochBasedTrainLoop", max_epochs=20, val_interval=1)
val_cfg = dict(type="ValLoop")
test_cfg = dict(type="TestLoop")

default_hooks = dict(
    timer=dict(type="IterTimerHook"),
    logger=dict(type="LoggerHook", interval=50),
    param_scheduler=dict(type="ParamSchedulerHook"),
    checkpoint=dict(
        type="CheckpointHook",
        interval=1,
        by_epoch=True,
        max_keep_ckpts=3,
        save_best="mIoU"),
    sampler_seed=dict(type="DistSamplerSeedHook"),
    visualization=dict(type="SegVisualizationHook"))

log_processor = dict(type="LogProcessor", window_size=50, by_epoch=True)
visualizer = dict(
    type="SegLocalVisualizer",
    vis_backends=[dict(type="LocalVisBackend")],
    name="visualizer")
auto_scale_lr = dict(enable=False, base_batch_size=8)
randomness = dict(seed=0, deterministic=False)
