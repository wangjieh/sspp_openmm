"""SkySense++ S1/S2 dual-branch UPerNet config for WHU-OPT-SAR."""

custom_imports = dict(imports=["sspp_mmseg"], allow_failed_imports=False)

default_scope = "mmseg"
env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method="fork", opencv_num_threads=0),
    dist_cfg=dict(backend="nccl"))
find_unused_parameters = True
model_wrapper_cfg = dict(
    type="MMDistributedDataParallel", find_unused_parameters=True)
launcher = "pytorch"
log_level = "INFO"
load_from = None
resume = False

data_root = "data/WHU-OPT-SAR"
pretrained_s2 = "pretrain/skysensepp_release_s2.pth"
pretrained_s1 = "pretrain/skysensepp_release_s1.pth"
dataset_type = "WHUOptSARDataset"
input_size = (128, 128)
num_classes = 8
ignore_index = 255
in_channels = 12
feature_channels = [1024, 1024, 1024, 1024]
norm_cfg = dict(type="SyncBN", requires_grad=True)

label_map = {
    0: 0,
    10: 1,
    20: 2,
    30: 3,
    40: 4,
    50: 5,
    60: 6,
    70: 7,
}
opt_mean = (104.695, 96.718, 79.112, 100.777)
opt_std = (25.109, 27.273, 29.714, 32.046)
sar_mean = (54.002, )
sar_std = (48.704, )

data_preprocessor = dict(
    type="SegDataPreProcessor",
    mean=[0.0] * in_channels,
    std=[1.0] * in_channels,
    bgr_to_rgb=False,
    pad_val=0,
    seg_pad_val=ignore_index,
    size=input_size)

pack_meta_keys = (
    "img_path",
    "opt_path",
    "sar_path",
    "seg_map_path",
    "ori_shape",
    "img_shape",
    "pad_shape",
    "scale_factor",
    "flip",
    "flip_direction",
    "reduce_zero_label",
    "whu_opt_sar_present_channels",
)

load_whu_opt_sar = dict(
    type="WHUOptSARLoadRasterio",
    opt_channel_indices=(0, 1, 2, 6),
    sar_channel_indices=(10, ),
    output_channels=in_channels,
    opt_mean=opt_mean,
    opt_std=opt_std,
    sar_mean=sar_mean,
    sar_std=sar_std,
    label_map=label_map,
    ignore_index=ignore_index)

train_pipeline = [
    load_whu_opt_sar,
    dict(type="RandomCrop", crop_size=input_size, cat_max_ratio=0.95),
    dict(type="RandomFlip", prob=0.5),
    dict(type="PackSegInputs", meta_keys=pack_meta_keys),
]
val_pipeline = [
    load_whu_opt_sar,
    dict(type="PackSegInputs", meta_keys=pack_meta_keys),
]
test_pipeline = val_pipeline

train_dataloader = dict(
    batch_size=4,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=True),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(
            opt_path="train_128/opt",
            sar_path="train_128/sar",
            seg_map_path="train_128/lbl",
        ),
        pipeline=train_pipeline))
val_dataloader = dict(
    batch_size=1,
    num_workers=2,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(
            opt_path="val_128/opt",
            sar_path="val_128/sar",
            seg_map_path="val_128/lbl",
        ),
        pipeline=val_pipeline))
test_dataloader = val_dataloader

val_evaluator = dict(type="IoUMetric", iou_metrics=["mIoU"])
test_evaluator = val_evaluator

model = dict(
    type="EncoderDecoder",
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type="SkySensePPDualBranchS1S2",
        input_split=(10, 2),
        feat_channels=1024,
        out_channels=1024,
        pyramid_scales=(1.0, 0.5, 0.25, 0.125),
        norm_cfg=norm_cfg,
        opt_backbone=dict(
            type="SkySensePPS2",
            in_channels=10,
            img_size=16,
            patch_size=4,
            out_indices=(5, 11, 17, 23),
            with_cp=True,
            init_cfg=dict(type="Pretrained", checkpoint=pretrained_s2)),
        sar_backbone=dict(
            type="SkySensePPS1",
            in_channels=2,
            img_size=16,
            patch_size=4,
            out_indices=(5, 11, 17, 23),
            with_cp=True,
            init_cfg=dict(type="Pretrained", checkpoint=pretrained_s1))),
    decode_head=dict(
        type="UPerHead",
        in_channels=feature_channels,
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=512,
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        ignore_index=ignore_index,
        loss_decode=dict(
            type="CrossEntropyLoss",
            use_sigmoid=False,
            loss_weight=1.0)),
    train_cfg=dict(),
    test_cfg=dict(mode="whole"))

optim_wrapper = dict(
    type="OptimWrapper",
    optimizer=dict(
        type="AdamW", lr=5e-4, betas=(0.9, 0.999), weight_decay=0.01),
    clip_grad=dict(max_norm=1.0, norm_type=2))
param_scheduler = [
    dict(
        type="LinearLR",
        start_factor=1e-6,
        by_epoch=False,
        begin=0,
        end=1500),
    dict(type="PolyLR", eta_min=0.0, power=1.0, begin=0, end=20,
         by_epoch=True),
]

train_cfg = dict(type="EpochBasedTrainLoop", max_epochs=20, val_interval=1)
val_cfg = dict(type="ValLoop")
test_cfg = dict(type="TestLoop")

default_hooks = dict(
    timer=dict(type="IterTimerHook"),
    logger=dict(type="LoggerHook", interval=50),
    param_scheduler=dict(type="ParamSchedulerHook"),
    checkpoint=dict(
        type="CheckpointHook",
        interval=1,
        by_epoch=True,
        max_keep_ckpts=3,
        save_best="mIoU"),
    sampler_seed=dict(type="DistSamplerSeedHook"),
    visualization=dict(type="SegVisualizationHook"))

log_processor = dict(type="LogProcessor", window_size=50, by_epoch=True)
visualizer = dict(
    type="SegLocalVisualizer",
    vis_backends=[dict(type="LocalVisBackend")],
    name="visualizer")
auto_scale_lr = dict(enable=False, base_batch_size=4)
randomness = dict(seed=0, deterministic=False)
