custom_imports = dict(imports=["sspp_mmseg"], allow_failed_imports=False)

model = dict(
    backbone=dict(
        type="SkySensePPHR",
        init_cfg=dict(
            type="Pretrained",
            checkpoint="pretrain/skysensepp_release_hr.pth",
        ),
        out_indices=(0, 1, 2, 3),
    ),
)

optim_wrapper = dict(
    constructor="SkySensePPLayerDecayOptimWrapperConstructor",
    optimizer=dict(type="AdamW", lr=1e-4, weight_decay=0.05),
    paramwise_cfg=dict(
        net_type="swin",
        arch="huge",
        layer_decay_rate=0.9,
        frozen_blocks=0,
    ),
)

