# SkySense++ MMSeg Config Notes

No pip installation is required. On a Linux server, expose the workspace root:

```bash
export PYTHONPATH=/path/to/skysensepp_openmm:$PYTHONPATH
```

Use the plugin through `custom_imports` in an OpenMMLab config:

```python
custom_imports = dict(imports=["sspp_mmseg"], allow_failed_imports=False)
```

Backbone types:

- `SkySensePPHR`: HR RGB backbone, 3 input channels, SwinV2-H style.
- `SkySensePPS1`: Sentinel-1 SAR backbone, 2 input channels.
- `SkySensePPS2`: Sentinel-2 multispectral backbone, 10 input channels.

The Sentinel-2 10-channel order used by SkySense++ is:
`B2, B3, B4, B8, B5, B6, B7, B8A, B11, B12`.

Layer-wise learning-rate decay is available through:

```python
optim_wrapper = dict(
    constructor="SkySensePPLayerDecayOptimWrapperConstructor",
    optimizer=dict(type="AdamW", lr=1e-4, weight_decay=0.05),
    paramwise_cfg=dict(
        net_type="swin",  # "vit" for S1/S2
        arch="huge",
        layer_decay_rate=0.9,
        frozen_blocks=0,
    ),
)
```
