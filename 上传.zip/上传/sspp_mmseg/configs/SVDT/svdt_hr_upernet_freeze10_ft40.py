custom_imports = dict(imports=["sspp_mmseg"], allow_failed_imports=False)

default_scope = "mmseg"
env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method="fork", opencv_num_threads=0),
    dist_cfg=dict(backend="nccl"))
find_unused_parameters = True
model_wrapper_cfg = dict(
    type="MMDistributedDataParallel", find_unused_parameters=True)
launcher = "pytorch"
log_level = "INFO"
load_from = None
resume = False

data_root = "data/SVDT"
pretrained = "pretrain/skysensepp_release_hr.pth"
dataset_type = "SVDTDataset"
crop_size = (512, 512)
num_classes = 2
ignore_index = 255
hr_channels = [352, 704, 1408, 2816]
norm_cfg = dict(type="SyncBN", requires_grad=True)

data_preprocessor = dict(
    type="SegDataPreProcessor",
    mean=[72.4085, 89.7399, 69.6123],
    std=[32.8544, 23.9954, 23.1234],
    bgr_to_rgb=True,
    pad_val=0,
    seg_pad_val=ignore_index,
    size=crop_size)

train_pack_meta_keys = (
    "img_path",
    "seg_map_path",
    "ori_shape",
    "img_shape",
    "pad_shape",
    "scale_factor",
    "flip",
    "flip_direction",
    "reduce_zero_label",
)
test_pack_meta_keys = train_pack_meta_keys + ("svdt_invalid_mask", )

train_pipeline = [
    dict(type="LoadImageFromFile"),
    dict(type="LoadAnnotations"),
    dict(type="SVDTMapAnnotationsAndIgnorePixels"),
    dict(type="RandomResize", scale=crop_size, ratio_range=(0.5, 2.0),
         keep_ratio=True),
    dict(type="RandomCrop", crop_size=crop_size, cat_max_ratio=0.95),
    dict(type="RandomFlip", prob=0.5),
    dict(type="PackSegInputs", meta_keys=train_pack_meta_keys),
]
val_pipeline = [
    dict(type="LoadImageFromFile"),
    dict(type="LoadAnnotations"),
    dict(type="SVDTMapAnnotationsAndIgnorePixels"),
    dict(type="PackSegInputs", meta_keys=test_pack_meta_keys),
]
test_pipeline = val_pipeline

train_dataloader = dict(
    batch_size=2,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=True),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(img_path="img_dir", seg_map_path="ann_dir"),
        ann_file="train.txt",
        pipeline=train_pipeline))
val_dataloader = dict(
    batch_size=1,
    num_workers=2,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(img_path="img_dir", seg_map_path="ann_dir"),
        ann_file="valid.txt",
        pipeline=val_pipeline))
test_dataloader = val_dataloader

val_evaluator = dict(type="IoUMetric", iou_metrics=["mIoU"])
test_evaluator = val_evaluator

model = dict(
    type="SVDTEncoderDecoder",
    data_preprocessor=data_preprocessor,
    backbone=dict(
        type="SkySensePPHR",
        patch_size=4,
        window_size=8,
        init_cfg=dict(type="Pretrained", checkpoint=pretrained),
        out_indices=(0, 1, 2, 3)),
    decode_head=dict(
        type="UPerHead",
        in_channels=hr_channels,
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=512,
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        ignore_index=ignore_index,
        loss_decode=dict(
            type="CrossEntropyLoss",
            use_sigmoid=False,
            loss_weight=1.0)),
    train_cfg=dict(),
    test_cfg=dict(mode="whole"))

optim_wrapper = dict(
    constructor="SkySensePPLayerDecayOptimWrapperConstructor",
    optimizer=dict(
        type="AdamW", lr=6e-5, betas=(0.9, 0.999), weight_decay=0.05),
    paramwise_cfg=dict(
        net_type="swin",
        arch="huge",
        layer_decay_rate=0.9,
        frozen_blocks=0),
    clip_grad=dict(max_norm=1.0, norm_type=2))
param_scheduler = [
    dict(type="LinearLR", start_factor=1e-6, by_epoch=True, begin=0, end=5),
    dict(type="PolyLR", eta_min=0.0, power=1.0, begin=0, end=50,
         by_epoch=True),
]

train_cfg = dict(type="EpochBasedTrainLoop", max_epochs=50, val_interval=1)
val_cfg = dict(type="ValLoop")
test_cfg = dict(type="TestLoop")

custom_hooks = [dict(type="FreezeBackboneHook", freeze_epochs=10)]
default_hooks = dict(
    timer=dict(type="IterTimerHook"),
    logger=dict(type="LoggerHook", interval=50),
    param_scheduler=dict(type="ParamSchedulerHook"),
    checkpoint=dict(
        type="CheckpointHook",
        interval=1,
        by_epoch=True,
        max_keep_ckpts=3,
        save_best="mIoU"),
    sampler_seed=dict(type="DistSamplerSeedHook"),
    visualization=dict(type="SegVisualizationHook"))

log_processor = dict(type="LogProcessor", window_size=50, by_epoch=True)
visualizer = dict(
    type="SegLocalVisualizer",
    vis_backends=[dict(type="LocalVisBackend")],
    name="visualizer")
auto_scale_lr = dict(enable=False, base_batch_size=16)
randomness = dict(seed=0, deterministic=False)
