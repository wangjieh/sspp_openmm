import ast
import importlib.util
import runpy
import sys
import types
import unittest
from unittest import mock
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
MMSEG = ROOT / 'dinov3_mmseg'
CONFIGS = ROOT / 'configs' / 'Ningbo2m'

CONFIG_NAMES = (
    'dinov3_large_upernet_full_50e.py',
    'dinov3_large_upernet_frozen_50e.py',
    'dinov3_large_adapter_upernet_full_50e.py',
    'dinov3_large_adapter_upernet_frozen_50e.py',
    'swin_huge_fpn_upernet_full_50e.py',
    'swin_huge_fpn_upernet_frozen_50e.py',
)


def read(path):
    return path.read_text(encoding='utf-8')


def load_config(name):
    return runpy.run_path(str(CONFIGS / name))


def has_register_decorator(class_node):
    return any(
        isinstance(dec, ast.Call)
        and isinstance(dec.func, ast.Attribute)
        and dec.func.attr == 'register_module'
        for dec in class_node.decorator_list)


def load_transforms_module_with_stubs():
    class BaseTransform:
        pass

    class Registry:
        def register_module(self):
            def decorator(cls):
                return cls
            return decorator

    mmcv_module = types.ModuleType('mmcv')
    mmcv_transforms = types.ModuleType('mmcv.transforms')
    mmcv_transforms.BaseTransform = BaseTransform
    mmcv_module.transforms = mmcv_transforms

    mmseg_module = types.ModuleType('mmseg')
    mmseg_registry = types.ModuleType('mmseg.registry')
    mmseg_registry.TRANSFORMS = Registry()
    mmseg_module.registry = mmseg_registry

    module_path = MMSEG / 'datasets' / 'transforms.py'
    spec = importlib.util.spec_from_file_location(
        'ningbo2m_test_transforms', module_path)
    module = importlib.util.module_from_spec(spec)
    with mock.patch.dict(sys.modules, {
            'mmcv': mmcv_module,
            'mmcv.transforms': mmcv_transforms,
            'mmseg': mmseg_module,
            'mmseg.registry': mmseg_registry,
    }):
        spec.loader.exec_module(module)
    return module


class FakeRasterioDataset:

    def __init__(self, mask):
        self.mask = mask

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        return False

    def read(self, index=None):
        return self.mask


class FakeRasterio:

    def __init__(self, mask):
        self.mask = mask

    def open(self, filename):
        return FakeRasterioDataset(self.mask)


class Ningbo2mStaticTest(unittest.TestCase):

    def test_dataset_and_transforms_are_registered(self):
        dataset_path = MMSEG / 'datasets' / 'ningbo2m_dataset.py'
        transforms_path = MMSEG / 'datasets' / 'transforms.py'
        init_path = MMSEG / 'datasets' / '__init__.py'

        self.assertTrue(dataset_path.is_file())
        self.assertTrue(transforms_path.is_file())

        dataset_tree = ast.parse(read(dataset_path))
        transform_tree = ast.parse(read(transforms_path))

        dataset_classes = {
            node.name: node for node in dataset_tree.body
            if isinstance(node, ast.ClassDef)
        }
        transform_classes = {
            node.name: node for node in transform_tree.body
            if isinstance(node, ast.ClassDef)
        }

        self.assertIn('Ningbo2mDataset', dataset_classes)
        self.assertTrue(has_register_decorator(dataset_classes['Ningbo2mDataset']))
        self.assertIn('LoadRasterioImageFromFile', transform_classes)
        self.assertIn('LoadRasterioAnnotations', transform_classes)
        self.assertTrue(
            has_register_decorator(transform_classes['LoadRasterioImageFromFile']))
        self.assertTrue(
            has_register_decorator(transform_classes['LoadRasterioAnnotations']))

        transforms_text = read(transforms_path)
        self.assertIn('import rasterio', transforms_text)
        self.assertIn('no_train_labels', transforms_text)
        self.assertIn('white_ignore_value', transforms_text)
        self.assertIn('label_map', transforms_text)
        self.assertIn('mask[ignore_mask] = self.ignore_index', transforms_text)

        init_text = read(init_path)
        self.assertIn('Ningbo2mDataset', init_text)
        self.assertIn('LoadRasterioImageFromFile', init_text)
        self.assertIn('LoadRasterioAnnotations', init_text)

    def test_dinov3_adapter_and_freeze_hook_are_registered(self):
        adapter_path = MMSEG / 'models' / 'dinov3_vit_adapter.py'
        hook_path = MMSEG / 'engine' / 'hooks' / 'freeze_backbone_hook.py'

        self.assertTrue(adapter_path.is_file())
        self.assertTrue(hook_path.is_file())

        adapter_tree = ast.parse(read(adapter_path))
        hook_tree = ast.parse(read(hook_path))

        adapter_classes = {
            node.name: node for node in adapter_tree.body
            if isinstance(node, ast.ClassDef)
        }
        hook_classes = {
            node.name: node for node in hook_tree.body
            if isinstance(node, ast.ClassDef)
        }

        self.assertIn('DINOv3ViTAdapter', adapter_classes)
        self.assertTrue(has_register_decorator(adapter_classes['DINOv3ViTAdapter']))
        self.assertIn('FreezeBackboneHook', hook_classes)
        self.assertTrue(has_register_decorator(hook_classes['FreezeBackboneHook']))

        adapter_text = read(adapter_path)
        self.assertIn('SpatialPriorModule', adapter_text)
        self.assertIn('InteractionBlockWithCls', adapter_text)
        self.assertIn('MultiScaleDeformableAttention', adapter_text)
        self.assertIn('set_backbone_frozen', adapter_text)

        model_init = read(MMSEG / 'models' / '__init__.py')
        hooks_init = read(MMSEG / 'engine' / 'hooks' / '__init__.py')
        self.assertIn('DINOv3ViTAdapter', model_init)
        self.assertIn('FreezeBackboneHook', hooks_init)

    def test_all_six_configs_exist_and_share_training_settings(self):
        self.assertFalse((CONFIGS / '_common.py').exists())
        for name in CONFIG_NAMES:
            with self.subTest(config=name):
                path = CONFIGS / name
                self.assertTrue(path.is_file())
                self.assertNotIn('from _common import', read(path))
                self.assertNotIn("_base_", read(path))
                self.assertNotIn('import sys', read(path))
                self.assertNotIn('from pathlib import Path', read(path))
                self.assertNotIn('sys.path', read(path))
                self.assertNotIn('def parse_label_list', read(path))
                self.assertNotIn("os.getenv('NINGBO2M_NO_TRAIN_LABELS'", read(path))
                self.assertIn('no_train_labels = []', read(path))
                self.assertNotIn("imports=['dinov3_mmseg']", read(path))
                self.assertIn(
                    "'dinov3_mmseg.datasets.ningbo2m_dataset'", read(path))
                self.assertIn("'dinov3_mmseg.datasets.transforms'", read(path))
                cfg = load_config(name)

                self.assertEqual(cfg['all_label_ids'], tuple(range(73)))
                self.assertEqual(
                    cfg['train_label_ids'],
                    tuple(label for label in cfg['all_label_ids']
                          if label not in cfg['no_train_labels']))
                self.assertEqual(cfg['num_classes'], len(cfg['train_label_ids']))
                self.assertEqual(cfg['ignore_index'], 255)
                self.assertEqual(
                    cfg['label_map'],
                    {
                        label: idx
                        for idx, label in enumerate(cfg['train_label_ids'])
                    })
                self.assertEqual(len(cfg['train_classes']), cfg['num_classes'])
                self.assertEqual(len(cfg['train_palette']), cfg['num_classes'])
                self.assertEqual(cfg['crop_size'], (512, 512))
                self.assertEqual(cfg['train_batch_size'], 8)
                self.assertEqual(cfg['max_epochs'], 50)
                self.assertEqual(cfg['optim_wrapper']['optimizer']['type'], 'AdamW')
                self.assertEqual(cfg['optim_wrapper']['optimizer']['lr'], 5e-4)
                self.assertEqual(
                    cfg['optim_wrapper']['optimizer']['weight_decay'], 0.01)
                self.assertEqual(cfg['param_scheduler'][0]['type'], 'LinearLR')
                self.assertEqual(cfg['param_scheduler'][0]['end'], 1500)
                self.assertEqual(cfg['param_scheduler'][0]['start_factor'], 1e-6)
                self.assertEqual(cfg['param_scheduler'][1]['type'], 'PolyLR')
                self.assertEqual(cfg['model']['decode_head']['type'], 'UPerHead')
                self.assertEqual(
                    cfg['model']['decode_head']['loss_decode']['type'],
                    'CrossEntropyLoss')
                self.assertEqual(
                    'ignore_index' in cfg['model']['decode_head']['loss_decode'],
                    False)
                self.assertIn('LoadRasterioImageFromFile', str(cfg['train_pipeline']))
                self.assertIn('LoadRasterioAnnotations', str(cfg['train_pipeline']))
                self.assertIn('no_train_labels', str(cfg['train_pipeline']))
                self.assertEqual(
                    cfg['train_dataloader']['dataset']['type'], 'Ningbo2mDataset')
                self.assertEqual(
                    cfg['train_dataloader']['dataset']['metainfo']['classes'],
                    cfg['train_classes'])
                self.assertEqual(
                    cfg['train_dataloader']['dataset']['metainfo']['palette'],
                    cfg['train_palette'])
                self.assertEqual(
                    cfg['train_pipeline'][1]['label_map'], cfg['label_map'])
                self.assertEqual(
                    cfg['test_pipeline'][1]['label_map'], cfg['label_map'])
                self.assertEqual(
                    cfg['model']['decode_head']['num_classes'], cfg['num_classes'])
                self.assertEqual(
                    cfg['train_dataloader']['dataset']['data_prefix']['img_path'],
                    'train/images')
                self.assertEqual(
                    cfg['train_dataloader']['dataset']['data_prefix']['seg_map_path'],
                    'train/masks')

    def test_config_model_variants_match_requested_matrix(self):
        direct_full = load_config('dinov3_large_upernet_full_50e.py')
        direct_frozen = load_config('dinov3_large_upernet_frozen_50e.py')
        adapter_full = load_config('dinov3_large_adapter_upernet_full_50e.py')
        adapter_frozen = load_config('dinov3_large_adapter_upernet_frozen_50e.py')
        swin_full = load_config('swin_huge_fpn_upernet_full_50e.py')
        swin_frozen = load_config('swin_huge_fpn_upernet_frozen_50e.py')

        self.assertEqual(direct_full['model']['backbone']['type'], 'DINOv3ViT')
        self.assertNotIn('neck', direct_full['model'])
        self.assertEqual(
            direct_full['model']['decode_head']['in_channels'],
            [1024, 1024, 1024, 1024])

        self.assertEqual(direct_frozen['model']['backbone']['type'], 'DINOv3ViT')
        self.assertEqual(direct_frozen['model']['backbone']['frozen_stages'], 24)
        self.assertEqual(direct_frozen['custom_hooks'], [])

        self.assertEqual(
            adapter_full['model']['backbone']['type'], 'DINOv3ViTAdapter')
        self.assertFalse(adapter_full['model']['backbone']['frozen_backbone'])
        self.assertEqual(
            adapter_frozen['model']['backbone']['type'], 'DINOv3ViTAdapter')
        self.assertTrue(adapter_frozen['model']['backbone']['frozen_backbone'])
        self.assertEqual(adapter_frozen['custom_hooks'], [])

        self.assertEqual(swin_full['model']['backbone']['type'], 'SwinTransformer')
        self.assertEqual(swin_full['model']['backbone']['embed_dims'], 352)
        self.assertEqual(swin_full['model']['neck']['type'], 'FPN')
        self.assertEqual(
            swin_full['model']['neck']['in_channels'],
            [352, 704, 1408, 2816])
        self.assertEqual(swin_frozen['model']['backbone']['type'], 'SwinTransformer')
        self.assertEqual(swin_frozen['model']['backbone']['frozen_stages'], 4)
        self.assertEqual(swin_frozen['custom_hooks'], [])

    def test_no_train_labels_are_ignored_and_remaining_labels_are_remapped(self):
        transforms_module = load_transforms_module_with_stubs()
        mask = np.array([[0, 1, 2, 3, 4, 5, 6, 255]], dtype=np.uint8)
        img = np.zeros((1, 8, 3), dtype=np.uint8)
        img[0, 1] = np.array([255, 255, 255], dtype=np.uint8)

        fake_rasterio = FakeRasterio(mask)
        loader = transforms_module.LoadRasterioAnnotations(
            ignore_index=255,
            no_train_labels=[3, 5],
            label_map={0: 0, 1: 1, 2: 2, 4: 3, 6: 4},
            label_min=0,
            label_max=6)

        with mock.patch.dict(sys.modules, {'rasterio': fake_rasterio}):
            output = loader.transform({
                'seg_map_path': 'mask.tif',
                'img': img,
            })

        expected = np.array([[0, 255, 2, 255, 3, 255, 4, 255]], dtype=np.int64)
        np.testing.assert_array_equal(output['gt_seg_map'], expected)
        self.assertEqual(output['gt_seg_map'].dtype, np.int64)


if __name__ == '__main__':
    unittest.main()
