import importlib.util
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SSPP_MMSEG = REPO_ROOT / "sspp_mmseg"
LOVEDA_CONFIG = (
    SSPP_MMSEG
    / "configs"
    / "LOVE-DA"
    / "loveda_hr_upernet_20e_512x512.py"
)


class TestLoveDAMMSegSupport(unittest.TestCase):

    def test_dataset_and_transform_files_are_registered(self):
        dataset_file = SSPP_MMSEG / "datasets" / "loveda_dataset.py"
        transform_file = (
            SSPP_MMSEG / "datasets" / "transforms" / "loveda_transforms.py"
        )
        datasets_init = SSPP_MMSEG / "datasets" / "__init__.py"
        transforms_init = SSPP_MMSEG / "datasets" / "transforms" / "__init__.py"

        self.assertTrue(dataset_file.exists())
        self.assertTrue(transform_file.exists())
        dataset_source = dataset_file.read_text(encoding="utf-8")
        transform_source = transform_file.read_text(encoding="utf-8")

        self.assertIn("class LoveDADataset", dataset_source)
        self.assertIn("@DATASETS.register_module()", dataset_source)
        self.assertIn('img_suffix=".png"', dataset_source)
        self.assertIn('seg_map_suffix=".png"', dataset_source)
        self.assertIn('"Agriculture"', dataset_source)

        self.assertIn("class LoveDALoadImageFromRasterio", transform_source)
        self.assertIn("class LoveDALoadAnnotationsFromRasterio",
                      transform_source)
        self.assertIn("import rasterio", transform_source)
        self.assertIn("map_loveda_labels", transform_source)
        self.assertIn("@TRANSFORMS.register_module()", transform_source)

        self.assertIn("LoveDADataset",
                      datasets_init.read_text(encoding="utf-8"))
        self.assertIn("LoveDALoadImageFromRasterio",
                      transforms_init.read_text(encoding="utf-8"))
        self.assertIn("LoveDALoadAnnotationsFromRasterio",
                      transforms_init.read_text(encoding="utf-8"))

    def test_label_mapping_uses_loveda_train_space(self):
        try:
            import numpy as np
        except ImportError as exc:
            self.skipTest(f"numpy is not available: {exc}")

        from sspp_mmseg.datasets.transforms import map_loveda_labels

        original = np.array(
            [[0, 1, 2, 3], [4, 5, 6, 7], [8, 255, 1, 0]],
            dtype=np.uint8)
        mapped = map_loveda_labels(original, ignore_index=255)

        np.testing.assert_array_equal(
            mapped,
            np.array(
                [[255, 0, 1, 2], [3, 4, 5, 6], [255, 255, 0, 255]],
                dtype=np.uint8))


class TestLoveDAMMSegConfig(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        if not LOVEDA_CONFIG.exists():
            raise AssertionError(f"Missing config: {LOVEDA_CONFIG}")
        cls.cfg = _load_config_module(LOVEDA_CONFIG)

    def test_model_uses_hr_upernet(self):
        cfg = self.cfg
        self.assertIn("sspp_mmseg", cfg.custom_imports["imports"])
        self.assertEqual(cfg.model["type"], "EncoderDecoder")
        self.assertEqual(cfg.model["backbone"]["type"], "SkySensePPHR")
        self.assertEqual(cfg.model["backbone"]["in_channels"], 3)
        self.assertEqual(cfg.model["backbone"]["patch_size"], 4)
        self.assertEqual(cfg.model["backbone"]["window_size"], 8)
        self.assertEqual(cfg.model["decode_head"]["type"], "UPerHead")
        self.assertEqual(cfg.model["decode_head"]["num_classes"], 7)
        self.assertEqual(cfg.model["decode_head"]["ignore_index"], 255)
        self.assertEqual(cfg.model["data_preprocessor"]["size"], (512, 512))

    def test_dataset_layout_and_pipelines(self):
        cfg = self.cfg
        self.assertEqual(cfg.dataset_type, "LoveDADataset")
        self.assertEqual(cfg.num_classes, 7)
        self.assertEqual(cfg.classes, (
            "Background",
            "Building",
            "Road",
            "Water",
            "Barren",
            "Forest",
            "Agriculture",
        ))

        train_dataset = cfg.train_dataloader["dataset"]
        self.assertEqual(train_dataset["data_prefix"]["img_path"],
                         "img_dir/train")
        self.assertEqual(train_dataset["data_prefix"]["seg_map_path"],
                         "ann_dir/train")
        val_dataset = cfg.val_dataloader["dataset"]
        self.assertEqual(val_dataset["data_prefix"]["img_path"], "img_dir/val")
        self.assertEqual(val_dataset["data_prefix"]["seg_map_path"],
                         "ann_dir/val")
        test_dataset = cfg.test_dataloader["dataset"]
        self.assertEqual(test_dataset["data_prefix"]["img_path"],
                         "img_dir/test")
        self.assertNotIn("seg_map_path", test_dataset["data_prefix"])
        self.assertTrue(test_dataset["test_mode"])

        train_pipeline_types = [step["type"] for step in cfg.train_pipeline]
        self.assertEqual(train_pipeline_types[:2], [
            "LoveDALoadImageFromRasterio",
            "LoveDALoadAnnotationsFromRasterio",
        ])
        self.assertIn("RandomCrop", train_pipeline_types)
        self.assertIn("RandomFlip", train_pipeline_types)

        test_pipeline_types = [step["type"] for step in cfg.test_pipeline]
        self.assertEqual(test_pipeline_types, [
            "LoveDALoadImageFromRasterio",
            "PackSegInputs",
        ])

    def test_training_and_test_settings(self):
        cfg = self.cfg
        self.assertEqual(cfg.env_cfg["dist_cfg"]["backend"], "nccl")
        self.assertTrue(cfg.find_unused_parameters)
        self.assertTrue(cfg.model_wrapper_cfg["find_unused_parameters"])
        self.assertEqual(cfg.train_cfg["type"], "EpochBasedTrainLoop")
        self.assertEqual(cfg.train_cfg["max_epochs"], 20)
        self.assertEqual(cfg.train_dataloader["batch_size"], 8)

        optimizer = cfg.optim_wrapper["optimizer"]
        self.assertEqual(optimizer["type"], "AdamW")
        self.assertEqual(optimizer["lr"], 5e-4)
        self.assertEqual(optimizer["weight_decay"], 0.01)

        scheduler_by_type = {item["type"]: item for item in cfg.param_scheduler}
        self.assertEqual(scheduler_by_type["LinearLR"]["end"], 1500)
        self.assertFalse(scheduler_by_type["LinearLR"]["by_epoch"])
        self.assertEqual(scheduler_by_type["LinearLR"]["start_factor"], 1e-6)
        self.assertEqual(scheduler_by_type["PolyLR"]["end"], 20)
        self.assertTrue(scheduler_by_type["PolyLR"]["by_epoch"])

        self.assertTrue(cfg.test_evaluator["format_only"])
        self.assertIn("test_results", cfg.test_evaluator["output_dir"])
        self.assertEqual(cfg.auto_scale_lr["base_batch_size"], 8)


def _load_config_module(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


if __name__ == "__main__":
    unittest.main(verbosity=2)
