import importlib.util
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SSPP_OPENCD = ROOT / "sspp_opencd"
CONFIG = (
    SSPP_OPENCD
    / "configs"
    / "BRIGHT"
    / "bright_s1s2_absdiff_upernet_20e_256x256.py"
)


def load_config_values(path):
    namespace = {}
    exec(compile(path.read_text(encoding="utf-8"), str(path), "exec"),
         namespace)
    return namespace


class TestBRIGHTOpenCDSource(unittest.TestCase):

    def test_dataset_transform_and_model_are_registered(self):
        dataset_file = SSPP_OPENCD / "datasets" / "bright_dataset.py"
        transform_file = (
            SSPP_OPENCD / "datasets" / "transforms" / "bright_transforms.py")
        transform_init = SSPP_OPENCD / "datasets" / "transforms" / "__init__.py"
        dataset_init = SSPP_OPENCD / "datasets" / "__init__.py"
        detector_file = (
            SSPP_OPENCD
            / "models"
            / "change_detectors"
            / "bright_absdiff_encoder_decoder.py"
        )
        detector_init = (
            SSPP_OPENCD / "models" / "change_detectors" / "__init__.py")
        registry_file = SSPP_OPENCD / "_registry.py"

        self.assertTrue(dataset_file.is_file())
        self.assertTrue(transform_file.is_file())
        self.assertTrue(detector_file.is_file())

        dataset_source = dataset_file.read_text(encoding="utf-8")
        transform_source = transform_file.read_text(encoding="utf-8")
        detector_source = detector_file.read_text(encoding="utf-8")

        self.assertIn("class BRIGHTDataset", dataset_source)
        self.assertIn("@DATASETS.register_module()", dataset_source)
        self.assertIn("split_basenames", dataset_source)
        self.assertIn("in stem", dataset_source)

        self.assertIn("class BRIGHTLoadRasterio", transform_source)
        self.assertIn("@TRANSFORMS.register_module()", transform_source)
        self.assertIn("import rasterio", transform_source)
        self.assertIn("opt_channel_indices=(2, 1, 0)", transform_source)
        self.assertIn("sar_channel_indices=(0, )", transform_source)

        self.assertIn("class SkySensePPDualBranchAbsDiffEncoderDecoder",
                      detector_source)
        self.assertIn("@MODELS.register_module()", detector_source)
        self.assertIn("SiamEncoderDecoder", detector_source)
        self.assertIn("self.opt_backbone", detector_source)
        self.assertIn("self.sar_backbone", detector_source)
        self.assertIn("torch.abs", detector_source)
        self.assertIn("F.interpolate", detector_source)

        self.assertIn("BRIGHTDataset",
                      dataset_init.read_text(encoding="utf-8"))
        self.assertIn("BRIGHTLoadRasterio",
                      transform_init.read_text(encoding="utf-8"))
        self.assertIn("TRANSFORMS", registry_file.read_text(encoding="utf-8"))
        self.assertIn("SkySensePPDualBranchAbsDiffEncoderDecoder",
                      detector_init.read_text(encoding="utf-8"))

    def test_bright_rasterio_loader_maps_channels_when_available(self):
        if importlib.util.find_spec("rasterio") is None:
            self.skipTest("rasterio is not available in this environment")

        import tempfile

        import numpy as np
        import rasterio

        from sspp_opencd.datasets.transforms import BRIGHTLoadRasterio

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            opt_path = root / "pre.tif"
            sar_path = root / "post.tif"
            label_path = root / "target.tif"

            opt = np.zeros((3, 2, 3), dtype=np.uint8)
            opt[0, :, :] = 156
            opt[1, :, :] = 143
            opt[2, :, :] = 130
            sar = np.full((1, 2, 3), 102, dtype=np.uint8)
            label = np.array([[[0, 1, 0], [1, 0, 1]]], dtype=np.uint8)

            with rasterio.open(
                    opt_path,
                    "w",
                    driver="GTiff",
                    width=3,
                    height=2,
                    count=3,
                    dtype=opt.dtype) as dataset:
                dataset.write(opt)
            with rasterio.open(
                    sar_path,
                    "w",
                    driver="GTiff",
                    width=3,
                    height=2,
                    count=1,
                    dtype=sar.dtype) as dataset:
                dataset.write(sar)
            with rasterio.open(
                    label_path,
                    "w",
                    driver="GTiff",
                    width=3,
                    height=2,
                    count=1,
                    dtype=label.dtype) as dataset:
                dataset.write(label)

            results = BRIGHTLoadRasterio().transform(
                dict(
                    img_path=[str(opt_path), str(sar_path)],
                    seg_map_path=str(label_path),
                    seg_fields=[]))

            self.assertEqual(len(results["img"]), 2)
            self.assertEqual(results["img"][0].shape, (2, 3, 10))
            self.assertEqual(results["img"][1].shape, (2, 3, 2))
            self.assertEqual(results["img_shape"], (2, 3))
            self.assertEqual(results["ori_shape"], (2, 3))
            self.assertIn("gt_seg_map", results["seg_fields"])
            self.assertEqual(results["bright_opt_present_channels"], (2, 1, 0))
            self.assertEqual(results["bright_sar_present_channels"], (0, ))

            for channel in (0, 1, 2):
                self.assertTrue(np.any(results["img"][0][..., channel] != 0))
            for channel in range(3, 10):
                self.assertTrue(np.all(results["img"][0][..., channel] == 0))
            self.assertTrue(np.any(results["img"][1][..., 0] != 0))
            self.assertTrue(np.all(results["img"][1][..., 1] == 0))
            np.testing.assert_array_equal(results["gt_seg_map"], label[0])


class TestBRIGHTOpenCDConfig(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        if not CONFIG.is_file():
            raise AssertionError(f"Missing config: {CONFIG}")
        cls.cfg = load_config_values(CONFIG)

    def test_model_uses_s1_s2_absdiff_upernet(self):
        cfg = self.cfg
        self.assertIn("sspp_opencd", cfg["custom_imports"]["imports"])

        model = cfg["model"]
        self.assertEqual(model["type"],
                         "SkySensePPDualBranchAbsDiffEncoderDecoder")
        self.assertEqual(model["input_split"], (10, 2))
        self.assertEqual(model["pyramid_scales"], (1.0, 0.5, 0.25, 0.125))

        opt_backbone = model["opt_backbone"]
        self.assertEqual(opt_backbone["type"], "SkySensePPS2")
        self.assertEqual(opt_backbone["in_channels"], 10)
        self.assertFalse(opt_backbone["with_cp"])
        self.assertIn("skysensepp_release_s2.pth",
                      opt_backbone["init_cfg"]["checkpoint"])

        sar_backbone = model["sar_backbone"]
        self.assertEqual(sar_backbone["type"], "SkySensePPS1")
        self.assertEqual(sar_backbone["in_channels"], 2)
        self.assertFalse(sar_backbone["with_cp"])
        self.assertIn("skysensepp_release_s1.pth",
                      sar_backbone["init_cfg"]["checkpoint"])

        decode_head = model["decode_head"]
        self.assertEqual(decode_head["type"], "mmseg.UPerHead")
        self.assertEqual(decode_head["in_channels"],
                         [1024, 1024, 1024, 1024])
        self.assertEqual(decode_head["num_classes"], 2)
        self.assertEqual(decode_head["loss_decode"]["type"],
                         "mmseg.CrossEntropyLoss")

    def test_data_preprocessor_and_pipeline(self):
        cfg = self.cfg
        data_preprocessor = cfg["model"]["data_preprocessor"]
        self.assertEqual(data_preprocessor["type"],
                         "DualInputSegDataPreProcessor")
        self.assertEqual(data_preprocessor["size"], (256, 256))
        self.assertFalse(data_preprocessor["bgr_to_rgb"])
        self.assertEqual(data_preprocessor["mean"], [0.0] * 12)
        self.assertEqual(data_preprocessor["std"], [1.0] * 12)

        load_step = cfg["load_bright"]
        self.assertEqual(load_step["type"], "BRIGHTLoadRasterio")
        self.assertEqual(load_step["opt_channel_indices"], (2, 1, 0))
        self.assertEqual(load_step["sar_channel_indices"], (0, ))
        self.assertEqual(load_step["output_channels"], (10, 2))
        self.assertEqual(load_step["opt_mean"], (88.674, 85.027, 76.558))
        self.assertEqual(load_step["opt_std"], (67.434, 58.458, 53.972))
        self.assertEqual(load_step["sar_mean"], (56.630, ))
        self.assertEqual(load_step["sar_std"], (45.191, ))

        train_pipeline_types = [
            step["type"] for step in cfg["train_pipeline"]
        ]
        self.assertEqual(train_pipeline_types[0], "BRIGHTLoadRasterio")
        self.assertIn("MultiImgRandomFlip", train_pipeline_types)
        self.assertEqual(train_pipeline_types[-1], "MultiImgPackSegInputs")

    def test_dataloaders_follow_bright_layout_and_splits(self):
        cfg = self.cfg
        self.assertEqual(cfg["dataset_type"], "BRIGHTDataset")
        self.assertEqual(cfg["train_dataloader"]["batch_size"], 8)

        expected = {
            "train_dataloader": "train_set.txt",
            "val_dataloader": "val_set.txt",
            "test_dataloader": "test_set.txt",
        }
        for dataloader_name, ann_file in expected.items():
            with self.subTest(dataloader=dataloader_name):
                dataset = cfg[dataloader_name]["dataset"]
                self.assertEqual(dataset["type"], "BRIGHTDataset")
                self.assertEqual(dataset["ann_file"], ann_file)
                self.assertEqual(dataset["data_prefix"]["img_path_from"],
                                 "pre-event_slices")
                self.assertEqual(dataset["data_prefix"]["img_path_to"],
                                 "post-event_slices")
                self.assertEqual(dataset["data_prefix"]["seg_map_path"],
                                 "target_slices")

    def test_optimizer_scheduler_and_epoch_hooks(self):
        cfg = self.cfg
        optimizer = cfg["optim_wrapper"]["optimizer"]
        self.assertEqual(optimizer["type"], "AdamW")
        self.assertEqual(optimizer["lr"], 5e-4)
        self.assertEqual(optimizer["weight_decay"], 0.01)

        self.assertEqual(cfg["train_cfg"]["type"], "EpochBasedTrainLoop")
        self.assertEqual(cfg["train_cfg"]["max_epochs"], 20)

        warmup = cfg["param_scheduler"][0]
        self.assertEqual(warmup["type"], "LinearLR")
        self.assertFalse(warmup["by_epoch"])
        self.assertEqual(warmup["end"], 1500)
        self.assertEqual(warmup["start_factor"], 1e-6)

        poly = cfg["param_scheduler"][1]
        self.assertEqual(poly["type"], "PolyLR")
        self.assertTrue(poly["by_epoch"])
        self.assertEqual(poly["end"], 20)

        self.assertTrue(cfg["log_processor"]["by_epoch"])
        self.assertTrue(cfg["default_hooks"]["checkpoint"]["by_epoch"])
        self.assertTrue(cfg["default_hooks"]["logger"]["log_metric_by_epoch"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
