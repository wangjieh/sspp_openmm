import importlib.util
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SSPP_MMSEG = REPO_ROOT / "sspp_mmseg"
WHU_CONFIG_DIR = SSPP_MMSEG / "configs" / "WHU-OPT-SAR"
WHU_CONFIG = WHU_CONFIG_DIR / "whu_opt_sar_s1s2_upernet_20e_128x128.py"


class TestWHUOptSARMMSegSupport(unittest.TestCase):

    def test_dataset_transform_and_dual_backbone_are_registered(self):
        dataset_file = SSPP_MMSEG / "datasets" / "whu_opt_sar_dataset.py"
        transform_file = (
            SSPP_MMSEG
            / "datasets"
            / "transforms"
            / "whu_opt_sar_transforms.py"
        )
        backbone_file = (
            SSPP_MMSEG
            / "models"
            / "backbones"
            / "skysensepp_dual_branch.py"
        )
        datasets_init = SSPP_MMSEG / "datasets" / "__init__.py"
        transforms_init = SSPP_MMSEG / "datasets" / "transforms" / "__init__.py"
        backbones_init = SSPP_MMSEG / "models" / "backbones" / "__init__.py"

        self.assertTrue(dataset_file.exists())
        self.assertTrue(transform_file.exists())
        self.assertTrue(backbone_file.exists())

        dataset_source = dataset_file.read_text(encoding="utf-8")
        transform_source = transform_file.read_text(encoding="utf-8")
        backbone_source = backbone_file.read_text(encoding="utf-8")

        self.assertIn("class WHUOptSARDataset", dataset_source)
        self.assertIn("@DATASETS.register_module()", dataset_source)
        self.assertIn('"opt_path"', dataset_source)
        self.assertIn('"sar_path"', dataset_source)
        self.assertIn('"seg_map_path"', dataset_source)

        self.assertIn("class WHUOptSARLoadRasterio", transform_source)
        self.assertIn("@TRANSFORMS.register_module()", transform_source)
        self.assertIn("import rasterio", transform_source)
        self.assertIn("opt_channel_indices", transform_source)
        self.assertIn("sar_channel_indices", transform_source)

        self.assertIn("class SkySensePPDualBranchS1S2", backbone_source)
        self.assertIn("@MODELS.register_module()", backbone_source)
        self.assertIn("SkySensePPS2", backbone_source)
        self.assertIn("SkySensePPS1", backbone_source)
        self.assertIn("ConvModule", backbone_source)
        self.assertIn("torch.cat", backbone_source)

        self.assertIn("WHUOptSARDataset",
                      datasets_init.read_text(encoding="utf-8"))
        self.assertIn("WHUOptSARLoadRasterio",
                      transforms_init.read_text(encoding="utf-8"))
        self.assertIn("SkySensePPDualBranchS1S2",
                      backbones_init.read_text(encoding="utf-8"))

    def test_skysensepp_vit_checkpointing_is_ddp_friendly(self):
        backbone_file = (
            SSPP_MMSEG
            / "models"
            / "backbones"
            / "skysensepp_backbones.py"
        )
        backbone_source = backbone_file.read_text(encoding="utf-8")

        self.assertIn("cp.checkpoint(", backbone_source)
        self.assertIn("_inner_forward, x", backbone_source)
        self.assertIn("use_reentrant=False", backbone_source)

    def test_rasterio_loader_maps_channels_and_labels_when_available(self):
        if importlib.util.find_spec("rasterio") is None:
            self.skipTest("rasterio is not available in this environment")

        import tempfile

        import numpy as np
        import rasterio

        from sspp_mmseg.datasets.transforms import WHUOptSARLoadRasterio

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            opt_path = root / "sample_opt.tif"
            sar_path = root / "sample_sar.tif"
            lbl_path = root / "sample_lbl.tif"

            opt = np.zeros((4, 2, 3), dtype=np.uint8)
            opt[0, :, :] = 105
            opt[1, :, :] = 97
            opt[2, :, :] = 79
            opt[3, :, :] = 101
            sar = np.full((1, 2, 3), 54, dtype=np.uint8)
            label = np.array([[[0, 10, 20], [30, 60, 70]]], dtype=np.uint8)

            with rasterio.open(
                    opt_path,
                    "w",
                    driver="GTiff",
                    width=3,
                    height=2,
                    count=4,
                    dtype=opt.dtype) as dataset:
                dataset.write(opt)
            with rasterio.open(
                    sar_path,
                    "w",
                    driver="GTiff",
                    width=3,
                    height=2,
                    count=1,
                    dtype=sar.dtype) as dataset:
                dataset.write(sar)
            with rasterio.open(
                    lbl_path,
                    "w",
                    driver="GTiff",
                    width=3,
                    height=2,
                    count=1,
                    dtype=label.dtype) as dataset:
                dataset.write(label)

            transform = WHUOptSARLoadRasterio()
            results = transform.transform(
                dict(
                    opt_path=str(opt_path),
                    sar_path=str(sar_path),
                    seg_map_path=str(lbl_path),
                    seg_fields=[]))

            self.assertEqual(results["img"].shape, (2, 3, 12))
            self.assertEqual(results["img_shape"], (2, 3))
            self.assertEqual(results["ori_shape"], (2, 3))
            self.assertEqual(results["gt_seg_map"].shape, (2, 3))
            self.assertIn("gt_seg_map", results["seg_fields"])

            present_channels = [0, 1, 2, 6, 10]
            missing_channels = [3, 4, 5, 7, 8, 9, 11]
            self.assertTrue(
                all(np.any(results["img"][..., index] != 0)
                    for index in present_channels))
            self.assertTrue(
                all(np.all(results["img"][..., index] == 0)
                    for index in missing_channels))
            np.testing.assert_array_equal(
                results["gt_seg_map"],
                np.array([[255, 0, 1], [2, 5, 6]], dtype=np.uint8))


class TestWHUOptSARMMSegConfig(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        if not WHU_CONFIG.exists():
            raise AssertionError(f"Missing config: {WHU_CONFIG}")
        cls.cfg = _load_config_module(WHU_CONFIG)

    def test_config_uses_dual_branch_s1_s2_upernet(self):
        cfg = self.cfg
        self.assertIn("sspp_mmseg", cfg.custom_imports["imports"])
        self.assertEqual(cfg.dataset_type, "WHUOptSARDataset")
        self.assertEqual(cfg.input_size, (128, 128))
        self.assertEqual(cfg.num_classes, 7)
        self.assertEqual(cfg.ignore_index, 255)
        self.assertNotIn(0, cfg.label_map)
        self.assertEqual(cfg.label_map[10], 0)
        self.assertEqual(cfg.label_map[70], 6)

        model = cfg.model
        self.assertEqual(model["type"], "EncoderDecoder")
        self.assertEqual(model["backbone"]["type"], "SkySensePPDualBranchS1S2")
        self.assertEqual(model["backbone"]["input_split"], (10, 2))
        self.assertEqual(model["backbone"]["out_channels"], 1024)
        self.assertEqual(model["backbone"]["opt_backbone"]["type"],
                         "SkySensePPS2")
        self.assertEqual(model["backbone"]["sar_backbone"]["type"],
                         "SkySensePPS1")
        self.assertIn("skysensepp_release_s2.pth",
                      model["backbone"]["opt_backbone"]["init_cfg"]["checkpoint"])
        self.assertIn("skysensepp_release_s1.pth",
                      model["backbone"]["sar_backbone"]["init_cfg"]["checkpoint"])
        self.assertEqual(model["decode_head"]["type"], "UPerHead")
        self.assertEqual(model["decode_head"]["in_channels"],
                         [1024, 1024, 1024, 1024])
        self.assertEqual(model["decode_head"]["num_classes"], 7)
        self.assertEqual(model["decode_head"]["loss_decode"]["type"],
                         "CrossEntropyLoss")
        self.assertFalse(model["data_preprocessor"]["bgr_to_rgb"])
        self.assertEqual(model["data_preprocessor"]["mean"], [0.0] * 12)
        self.assertEqual(model["data_preprocessor"]["std"], [1.0] * 12)

    def test_config_dataset_layout_pipeline_and_training_settings(self):
        cfg = self.cfg
        self.assertEqual(cfg.train_dataloader["batch_size"], 4)

        train_dataset = cfg.train_dataloader["dataset"]
        self.assertEqual(train_dataset["type"], "WHUOptSARDataset")
        self.assertEqual(train_dataset["data_prefix"]["opt_path"],
                         "train_128/opt")
        self.assertEqual(train_dataset["data_prefix"]["sar_path"],
                         "train_128/sar")
        self.assertEqual(train_dataset["data_prefix"]["seg_map_path"],
                         "train_128/lbl")

        val_dataset = cfg.val_dataloader["dataset"]
        self.assertEqual(val_dataset["data_prefix"]["opt_path"], "val_128/opt")
        self.assertEqual(val_dataset["data_prefix"]["sar_path"], "val_128/sar")
        self.assertEqual(val_dataset["data_prefix"]["seg_map_path"],
                         "val_128/lbl")

        train_pipeline_types = [
            step["type"] for step in train_dataset["pipeline"]
        ]
        self.assertEqual(train_pipeline_types[0], "WHUOptSARLoadRasterio")
        self.assertIn("RandomCrop", train_pipeline_types)
        self.assertIn("RandomFlip", train_pipeline_types)
        load_step = train_dataset["pipeline"][0]
        self.assertEqual(load_step["opt_channel_indices"], (0, 1, 2, 6))
        self.assertEqual(load_step["sar_channel_indices"], (10,))

        self.assertEqual(cfg.env_cfg["dist_cfg"]["backend"], "nccl")
        self.assertTrue(cfg.find_unused_parameters)
        self.assertTrue(cfg.model_wrapper_cfg["find_unused_parameters"])
        self.assertEqual(cfg.train_cfg["type"], "EpochBasedTrainLoop")
        self.assertEqual(cfg.train_cfg["max_epochs"], 20)

        optimizer = cfg.optim_wrapper["optimizer"]
        self.assertEqual(optimizer["type"], "AdamW")
        self.assertEqual(optimizer["lr"], 5e-4)
        self.assertEqual(optimizer["weight_decay"], 0.01)

        scheduler_by_type = {item["type"]: item for item in cfg.param_scheduler}
        self.assertEqual(scheduler_by_type["LinearLR"]["end"], 1500)
        self.assertFalse(scheduler_by_type["LinearLR"]["by_epoch"])
        self.assertEqual(scheduler_by_type["LinearLR"]["start_factor"], 1e-6)
        self.assertEqual(scheduler_by_type["PolyLR"]["end"], 20)
        self.assertTrue(scheduler_by_type["PolyLR"]["by_epoch"])


def _load_config_module(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


if __name__ == "__main__":
    unittest.main(verbosity=2)
