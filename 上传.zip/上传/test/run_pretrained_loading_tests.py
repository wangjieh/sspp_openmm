"""Convenience runner for SkySense++ pretrained-weight checks."""

from __future__ import annotations

import argparse
import os
import subprocess
import sys


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--checkpoint-dir",
        default=r"F:\PythonProject\Skysense++\SkySensePlusPlus-main\pretrain",
        help="Directory containing the three SkySense++ release checkpoints.")
    parser.add_argument(
        "--check-keys",
        action="store_true",
        help="Load checkpoint files and verify expected parameter keys.")
    parser.add_argument(
        "--load-models",
        action="store_true",
        help=(
            "Instantiate backbones and load checkpoint state_dicts. This needs "
            "PyTorch and OpenMMLab, and HR requires several GB of memory."))
    args = parser.parse_args()

    env = os.environ.copy()
    env["SSPP_CKPT_DIR"] = args.checkpoint_dir
    if args.check_keys or args.load_models:
        env["SSPP_RUN_REAL_CKPT"] = "1"
    if args.load_models:
        env["SSPP_LOAD_REAL_MODELS"] = "1"

    tests = ["test.test_pretrained_loading"]
    if args.load_models:
        tests = [
            "test.test_pretrained_loading.TestPretrainedCheckpoints."
            "test_real_checkpoints_load_into_backbones_when_enabled"
        ]
    elif args.check_keys:
        tests = [
            "test.test_pretrained_loading.TestPretrainedCheckpoints."
            "test_real_checkpoint_files_have_expected_keys_when_enabled"
        ]

    return subprocess.call(
        [sys.executable, "-m", "unittest", *tests, "-v"],
        env=env,
    )


if __name__ == "__main__":
    raise SystemExit(main())
