import importlib.util
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SSPP_MMSEG = REPO_ROOT / "sspp_mmseg"
OLD_CONFIG = (
    SSPP_MMSEG
    / "configs"
    / "Ningbo-2m"
    / "ningbo2m_hr_upernet_12e_512x512.py"
)
NEW_CONFIG = (
    SSPP_MMSEG
    / "configs"
    / "Ningbo-2m-new"
    / "ningbo2m_new_hr_upernet_12e_512x512.py"
)


class TestNingbo2mNewMMSegSupport(unittest.TestCase):

    def test_new_dataset_and_transform_files_are_registered(self):
        dataset_file = SSPP_MMSEG / "datasets" / "ningbo2m_new_dataset.py"
        transform_file = (
            SSPP_MMSEG
            / "datasets"
            / "transforms"
            / "ningbo2m_new_transforms.py"
        )
        datasets_init = SSPP_MMSEG / "datasets" / "__init__.py"
        transforms_init = SSPP_MMSEG / "datasets" / "transforms" / "__init__.py"

        self.assertTrue(dataset_file.exists())
        self.assertTrue(transform_file.exists())
        dataset_source = dataset_file.read_text(encoding="utf-8")
        transform_source = transform_file.read_text(encoding="utf-8")

        self.assertIn("class Ningbo2mNewDataset", dataset_source)
        self.assertIn("@DATASETS.register_module()", dataset_source)
        self.assertIn('"Background"', dataset_source)
        self.assertIn('"Residential"', dataset_source)
        self.assertIn('img_suffix=".tif"', dataset_source)
        self.assertIn('seg_map_suffix=".tif"', dataset_source)

        self.assertIn("class Ningbo2mNewLoadImageFromRasterio",
                      transform_source)
        self.assertIn("class Ningbo2mNewLoadAnnotationsFromRasterio",
                      transform_source)
        self.assertIn("class Ningbo2mNewWhitePixelsToIgnore",
                      transform_source)
        self.assertIn("import rasterio", transform_source)
        self.assertIn("@TRANSFORMS.register_module()", transform_source)
        self.assertIn("valid_labels=tuple(range(8))", transform_source)
        self.assertIn("ignore_index=255", transform_source)

        self.assertIn("Ningbo2mNewDataset",
                      datasets_init.read_text(encoding="utf-8"))
        self.assertIn("Ningbo2mNewLoadImageFromRasterio",
                      transforms_init.read_text(encoding="utf-8"))
        self.assertIn("Ningbo2mNewLoadAnnotationsFromRasterio",
                      transforms_init.read_text(encoding="utf-8"))
        self.assertIn("Ningbo2mNewWhitePixelsToIgnore",
                      transforms_init.read_text(encoding="utf-8"))

    def test_new_white_pixels_to_ignore(self):
        try:
            import numpy as np
        except ImportError as exc:
            self.skipTest(f"numpy is not available: {exc}")

        from sspp_mmseg.datasets.transforms import (
            Ningbo2mNewWhitePixelsToIgnore,
        )

        transform = Ningbo2mNewWhitePixelsToIgnore()
        results = transform.transform(
            dict(
                img=np.array(
                    [
                        [[255, 255, 255], [10, 20, 30]],
                        [[255, 254, 255], [255, 255, 255]],
                    ],
                    dtype=np.uint8),
                gt_seg_map=np.array([[0, 1], [7, 255]], dtype=np.uint8)))

        np.testing.assert_array_equal(
            results["gt_seg_map"],
            np.array([[255, 1], [7, 255]], dtype=np.uint8))
        np.testing.assert_array_equal(
            results["ningbo2m_new_white_ignore_mask"],
            np.array([[True, False], [False, True]], dtype=bool))

    def test_new_config_replaces_only_dataset_and_class_space(self):
        old_cfg = _load_config_module(OLD_CONFIG)
        new_cfg = _load_config_module(NEW_CONFIG)

        self.assertEqual(new_cfg.dataset_type, "Ningbo2mNewDataset")
        self.assertEqual(new_cfg.input_size, old_cfg.input_size)
        self.assertEqual(new_cfg.ignore_index, old_cfg.ignore_index)
        self.assertEqual(new_cfg.num_classes, 8)
        self.assertEqual(new_cfg.classes, (
            "Background",
            "Grass",
            "Bare_land",
            "Road",
            "Forest",
            "River",
            "Cropland",
            "Residential",
        ))

        self.assertEqual(
            new_cfg.model["decode_head"]["num_classes"], new_cfg.num_classes)
        self.assertEqual(
            new_cfg.train_dataloader["batch_size"],
            old_cfg.train_dataloader["batch_size"])
        self.assertEqual(
            new_cfg.optim_wrapper["optimizer"],
            old_cfg.optim_wrapper["optimizer"])
        self.assertEqual(new_cfg.param_scheduler, old_cfg.param_scheduler)
        self.assertEqual(new_cfg.train_cfg, old_cfg.train_cfg)
        self.assertEqual(new_cfg.auto_scale_lr, old_cfg.auto_scale_lr)

        train_pipeline_types = [step["type"] for step in new_cfg.train_pipeline]
        self.assertEqual(train_pipeline_types[:3], [
            "Ningbo2mNewLoadImageFromRasterio",
            "Ningbo2mNewLoadAnnotationsFromRasterio",
            "Ningbo2mNewWhitePixelsToIgnore",
        ])
        self.assertNotIn("Ningbo2mLabelsToIgnore", train_pipeline_types)
        self.assertNotIn("Ningbo2mRemapLabels", train_pipeline_types)
        self.assertIn("RandomCrop", train_pipeline_types)
        self.assertIn("RandomFlip", train_pipeline_types)

        self.assertFalse(hasattr(new_cfg, "no_train_labels"))
        self.assertFalse(hasattr(new_cfg, "train_label_map"))


def _load_config_module(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


if __name__ == "__main__":
    unittest.main(verbosity=2)
