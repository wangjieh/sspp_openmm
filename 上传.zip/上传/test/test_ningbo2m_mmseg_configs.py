import importlib.util
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SSPP_MMSEG = REPO_ROOT / "sspp_mmseg"
NINGBO_CONFIG_DIR = SSPP_MMSEG / "configs" / "Ningbo-2m"
NINGBO_CONFIG = NINGBO_CONFIG_DIR / "ningbo2m_hr_upernet_12e_512x512.py"


class TestNingbo2mMMSegSupport(unittest.TestCase):

    def test_dataset_and_transform_files_are_registered(self):
        dataset_file = SSPP_MMSEG / "datasets" / "ningbo2m_dataset.py"
        transform_file = (
            SSPP_MMSEG
            / "datasets"
            / "transforms"
            / "ningbo2m_transforms.py"
        )
        datasets_init = SSPP_MMSEG / "datasets" / "__init__.py"
        transforms_init = SSPP_MMSEG / "datasets" / "transforms" / "__init__.py"

        self.assertTrue(dataset_file.exists())
        self.assertTrue(transform_file.exists())
        dataset_source = dataset_file.read_text(encoding="utf-8")
        transform_source = transform_file.read_text(encoding="utf-8")

        self.assertIn("class Ningbo2mDataset", dataset_source)
        self.assertIn("@DATASETS.register_module()", dataset_source)
        self.assertIn('img_suffix=".tif"', dataset_source)
        self.assertIn('seg_map_suffix=".tif"', dataset_source)
        self.assertIn("classes=tuple(str(i) for i in range(73))",
                      dataset_source)

        self.assertIn("class Ningbo2mWhitePixelsToIgnore", transform_source)
        self.assertIn("@TRANSFORMS.register_module()", transform_source)
        self.assertIn("white_value", transform_source)
        self.assertIn("ignore_index", transform_source)
        self.assertIn('results["ningbo2m_white_ignore_mask"] = white_mask',
                      transform_source)

        self.assertIn("Ningbo2mDataset",
                      datasets_init.read_text(encoding="utf-8"))
        self.assertIn("Ningbo2mWhitePixelsToIgnore",
                      transforms_init.read_text(encoding="utf-8"))

    def test_transform_sets_white_image_pixels_to_ignore(self):
        try:
            import numpy as np
        except ImportError as exc:
            self.skipTest(f"numpy is not available: {exc}")

        from sspp_mmseg.datasets.transforms import Ningbo2mWhitePixelsToIgnore

        transform = Ningbo2mWhitePixelsToIgnore()
        results = transform.transform(
            dict(
                img=np.array(
                    [
                        [[255, 255, 255], [10, 20, 30]],
                        [[254, 255, 255], [255, 255, 255]],
                    ],
                    dtype=np.uint8),
                gt_seg_map=np.array([[1, 2], [255, 72]], dtype=np.uint8)))

        np.testing.assert_array_equal(
            results["gt_seg_map"],
            np.array([[255, 2], [255, 255]], dtype=np.uint8))
        np.testing.assert_array_equal(
            results["ningbo2m_white_ignore_mask"],
            np.array([[True, False], [False, True]], dtype=bool))


class TestNingbo2mMMSegConfig(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        if not NINGBO_CONFIG.exists():
            raise AssertionError(f"Missing config: {NINGBO_CONFIG}")
        cls.cfg = _load_config_module(NINGBO_CONFIG)

    def test_model_uses_hr_upernet_for_73_classes(self):
        cfg = self.cfg
        self.assertIn("sspp_mmseg", cfg.custom_imports["imports"])
        self.assertEqual(cfg.model["type"], "EncoderDecoder")
        self.assertEqual(cfg.model["backbone"]["type"], "SkySensePPHR")
        self.assertEqual(cfg.model["backbone"]["in_channels"], 3)
        self.assertEqual(cfg.model["backbone"]["patch_size"], 4)
        self.assertEqual(cfg.model["backbone"]["window_size"], 8)
        self.assertEqual(cfg.model["decode_head"]["type"], "UPerHead")
        self.assertEqual(cfg.model["decode_head"]["num_classes"], 73)
        self.assertEqual(cfg.model["decode_head"]["ignore_index"], 255)
        self.assertEqual(cfg.model["decode_head"]["loss_decode"]["type"],
                         "CrossEntropyLoss")
        self.assertEqual(cfg.model["data_preprocessor"]["size"], (512, 512))
        self.assertTrue(cfg.model["data_preprocessor"]["bgr_to_rgb"])
        self.assertIn("SyncBN", NINGBO_CONFIG.read_text(encoding="utf-8"))

    def test_dataset_layout_and_pipeline(self):
        cfg = self.cfg
        self.assertEqual(cfg.dataset_type, "Ningbo2mDataset")
        self.assertEqual(cfg.num_classes, 73)
        self.assertEqual(cfg.ignore_index, 255)
        self.assertEqual(cfg.train_dataloader["batch_size"], 8)

        train_dataset = cfg.train_dataloader["dataset"]
        self.assertEqual(train_dataset["type"], "Ningbo2mDataset")
        self.assertEqual(train_dataset["data_prefix"]["img_path"],
                         "train/images")
        self.assertEqual(train_dataset["data_prefix"]["seg_map_path"],
                         "train/masks")
        self.assertNotIn("ann_file", train_dataset)

        val_dataset = cfg.val_dataloader["dataset"]
        self.assertEqual(val_dataset["data_prefix"]["img_path"], "val/images")
        self.assertEqual(val_dataset["data_prefix"]["seg_map_path"],
                         "val/masks")

        train_pipeline_types = [step["type"] for step in cfg.train_pipeline]
        self.assertEqual(train_pipeline_types[:3], [
            "LoadImageFromFile",
            "LoadAnnotations",
            "Ningbo2mWhitePixelsToIgnore",
        ])
        self.assertIn("RandomCrop", train_pipeline_types)
        self.assertIn("RandomFlip", train_pipeline_types)
        self.assertNotIn("RandomResize", train_pipeline_types)

    def test_optimizer_scheduler_and_multigpu_settings(self):
        cfg = self.cfg
        self.assertEqual(cfg.env_cfg["dist_cfg"]["backend"], "nccl")
        self.assertTrue(cfg.find_unused_parameters)
        self.assertTrue(cfg.model_wrapper_cfg["find_unused_parameters"])
        self.assertEqual(cfg.train_cfg["type"], "EpochBasedTrainLoop")
        self.assertEqual(cfg.train_cfg["max_epochs"], 12)

        optimizer = cfg.optim_wrapper["optimizer"]
        self.assertEqual(optimizer["type"], "AdamW")
        self.assertEqual(optimizer["lr"], 5e-4)
        self.assertEqual(optimizer["weight_decay"], 0.01)

        scheduler_by_type = {item["type"]: item for item in cfg.param_scheduler}
        self.assertEqual(scheduler_by_type["LinearLR"]["end"], 1500)
        self.assertFalse(scheduler_by_type["LinearLR"]["by_epoch"])
        self.assertEqual(scheduler_by_type["LinearLR"]["start_factor"], 1e-6)
        self.assertEqual(scheduler_by_type["PolyLR"]["end"], 12)
        self.assertTrue(scheduler_by_type["PolyLR"]["by_epoch"])

        self.assertEqual(cfg.default_hooks["checkpoint"]["by_epoch"], True)
        self.assertEqual(cfg.log_processor["by_epoch"], True)
        self.assertEqual(cfg.auto_scale_lr["base_batch_size"], 8)


def _load_config_module(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


if __name__ == "__main__":
    unittest.main(verbosity=2)
