import importlib.util
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SSPP_MMDET = ROOT / "sspp_mmdet"
CONFIG = (
    SSPP_MMDET
    / "configs"
    / "DIOR"
    / "dior_hr_faster_rcnn_swinv2_layer_decay_20e_800x800.py"
)


DIOR_CLASSES = (
    "airplane",
    "airport",
    "baseballfield",
    "basketballcourt",
    "bridge",
    "chimney",
    "dam",
    "Expressway-Service-area",
    "Expressway-toll-station",
    "golffield",
    "groundtrackfield",
    "harbor",
    "overpass",
    "ship",
    "stadium",
    "storagetank",
    "tenniscourt",
    "trainstation",
    "vehicle",
    "windmill",
)


def load_config(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TestDIORMMDetSource(unittest.TestCase):

    def test_registry_exports_dataset_and_transform_registries(self):
        registry_source = (SSPP_MMDET / "_registry.py").read_text(
            encoding="utf-8")
        self.assertIn('DATASETS = _load_registry("DATASETS")', registry_source)
        self.assertIn('TRANSFORMS = _load_registry("TRANSFORMS")',
                      registry_source)

    def test_dior_hbb_dataset_is_registered_with_expected_classes(self):
        dataset_file = SSPP_MMDET / "datasets" / "dior_hbb_dataset.py"
        dataset_init = SSPP_MMDET / "datasets" / "__init__.py"
        package_init = SSPP_MMDET / "__init__.py"

        self.assertTrue(dataset_file.exists())
        source = dataset_file.read_text(encoding="utf-8")
        self.assertIn("class DIORHBBDetectionDataset", source)
        self.assertIn("@DATASETS.register_module()", source)
        self.assertIn("BaseDetDataset", source)
        self.assertIn("img_suffix=\"jpg\"", source)
        self.assertIn("hbb_dota_cleaned", source)
        for class_name in DIOR_CLASSES:
            self.assertIn(f'"{class_name}"', source)

        self.assertIn("DIORHBBDetectionDataset",
                      dataset_init.read_text(encoding="utf-8"))
        self.assertIn("datasets", package_init.read_text(encoding="utf-8"))

    def test_invalid_horizontal_box_transform_is_registered(self):
        transform_file = (
            SSPP_MMDET
            / "datasets"
            / "transforms"
            / "filter_invalid_horizontal_boxes.py"
        )
        transform_init = SSPP_MMDET / "datasets" / "transforms" / "__init__.py"
        self.assertTrue(transform_file.exists())
        source = transform_file.read_text(encoding="utf-8")
        self.assertIn("class FilterInvalidHorizontalBoxes", source)
        self.assertIn("@TRANSFORMS.register_module()", source)
        self.assertIn("too_small", source)
        self.assertIn("out_of_bounds", source)
        self.assertIn("gt_bboxes_labels", source)
        self.assertIn("gt_ignore_flags", source)
        self.assertIn("print_log", source)
        self.assertIn("FilterInvalidHorizontalBoxes",
                      transform_init.read_text(encoding="utf-8"))

    def test_swinv2_layer_decay_constructor_is_registered(self):
        optimizer_file = (
            SSPP_MMDET
            / "engine"
            / "optimizers"
            / "layer_decay_optimizer_constructor.py"
        )
        optimizer_init = SSPP_MMDET / "engine" / "optimizers" / "__init__.py"
        source = optimizer_file.read_text(encoding="utf-8")
        self.assertIn("class SwinV2LayerDecayOptimizerConstructor", source)
        self.assertIn("@OPTIM_WRAPPER_CONSTRUCTORS.register_module()", source)
        self.assertIn("get_swin_v2_layer_id", source)
        self.assertIn("custom_keys", source)
        self.assertIn("layer_decay_rate", source)
        self.assertIn("SwinV2LayerDecayOptimizerConstructor",
                      optimizer_init.read_text(encoding="utf-8"))

    def test_swinv2_layer_ids_match_skysense_original_rules(self):
        from sspp_mmdet.engine.optimizers.layer_decay_optimizer_constructor import (
            get_swin_v2_layer_id,
        )

        depths = (2, 2, 18, 2)
        num_max_layer = 26
        self.assertEqual(
            get_swin_v2_layer_id("backbone.patch_embed.proj.weight",
                                 num_max_layer, depths),
            0,
        )
        self.assertEqual(
            get_swin_v2_layer_id("backbone.stages.0.blocks.1.norm1.weight",
                                 num_max_layer, depths),
            2,
        )
        self.assertEqual(
            get_swin_v2_layer_id("backbone.stages.1.blocks.0.norm1.weight",
                                 num_max_layer, depths),
            3,
        )
        self.assertEqual(
            get_swin_v2_layer_id("backbone.stages.1.downsample.reduction.weight",
                                 num_max_layer, depths),
            3,
        )
        self.assertEqual(
            get_swin_v2_layer_id("neck.lateral_convs.0.conv.weight",
                                 num_max_layer, depths),
            25,
        )


class TestFilterInvalidHorizontalBoxesBehavior(unittest.TestCase):

    def test_filters_too_small_and_out_of_bounds_numpy_hboxes(self):
        try:
            import numpy as np
        except ImportError as exc:
            self.skipTest(f"numpy is unavailable: {exc}")

        from sspp_mmdet.datasets.transforms import FilterInvalidHorizontalBoxes

        transform = FilterInvalidHorizontalBoxes(min_size=1.0, log_interval=1)
        results = dict(
            img_shape=(100, 100),
            img_path="sample.jpg",
            gt_bboxes=np.array(
                [
                    [10.0, 10.0, 20.0, 20.0],
                    [10.0, 10.0, 10.5, 20.0],
                    [90.0, 90.0, 105.0, 95.0],
                    [-1.0, 2.0, 5.0, 8.0],
                ],
                dtype=np.float32),
            gt_bboxes_labels=np.array([1, 2, 3, 4], dtype=np.int64),
            gt_ignore_flags=np.array([False, True, False, True], dtype=bool),
        )

        with self.assertLogs(
                "sspp_mmdet.datasets.transforms.filter_invalid_horizontal_boxes",
                level="INFO") as logs:
            filtered = transform.transform(results)

        self.assertEqual(filtered["gt_bboxes"].shape[0], 1)
        np.testing.assert_array_equal(filtered["gt_bboxes_labels"],
                                      np.array([1], dtype=np.int64))
        np.testing.assert_array_equal(filtered["gt_ignore_flags"],
                                      np.array([False], dtype=bool))
        self.assertEqual(transform.reason_counts["too_small"], 1)
        self.assertEqual(transform.reason_counts["out_of_bounds"], 2)
        self.assertTrue(any("too_small=1" in item for item in logs.output))
        self.assertTrue(any("out_of_bounds=2" in item for item in logs.output))


class TestDIORMMDetConfig(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        if not CONFIG.exists():
            raise AssertionError(f"Missing config: {CONFIG}")
        cls.cfg = load_config(CONFIG)

    def test_config_is_standalone(self):
        self.assertFalse(hasattr(self.cfg, "_base_"))

    def test_model_uses_skysensepp_hr_faster_rcnn(self):
        cfg = self.cfg
        self.assertIn("sspp_mmdet", cfg.custom_imports["imports"])
        model = cfg.model
        self.assertEqual(model["type"], "mmdet.FasterRCNN")
        self.assertEqual(model["data_preprocessor"]["type"],
                         "mmdet.DetDataPreprocessor")
        self.assertEqual(model["data_preprocessor"]["batch_augments"], None)
        self.assertEqual(model["backbone"]["type"], "SkySensePPHR")
        self.assertEqual(model["backbone"]["in_channels"], 3)
        self.assertEqual(model["backbone"]["patch_size"], 4)
        self.assertEqual(model["backbone"]["window_size"], 8)
        self.assertEqual(model["backbone"]["drop_path_rate"], 0.3)
        self.assertEqual(model["neck"]["type"], "mmdet.FPN")
        self.assertEqual(model["neck"]["in_channels"], [352, 704, 1408, 2816])
        self.assertEqual(model["rpn_head"]["type"], "mmdet.RPNHead")
        self.assertEqual(model["roi_head"]["bbox_head"]["num_classes"], 20)
        self.assertEqual(model["roi_head"]["bbox_head"]["loss_cls"]["type"],
                         "mmdet.CrossEntropyLoss")
        self.assertEqual(model["roi_head"]["bbox_head"]["loss_bbox"]["type"],
                         "mmdet.SmoothL1Loss")

    def test_dataset_layout_and_pipeline(self):
        cfg = self.cfg
        self.assertEqual(cfg.dataset_type, "DIORHBBDetectionDataset")
        self.assertEqual(cfg.batch_size, 4)
        self.assertEqual(cfg.train_dataloader["batch_size"], 4)
        train_dataset = cfg.train_dataloader["dataset"]
        self.assertEqual(train_dataset["type"], "DIORHBBDetectionDataset")
        self.assertEqual(train_dataset["ann_file"],
                         "trainval/hbb_dota_cleaned")
        self.assertEqual(train_dataset["data_prefix"]["img_path"],
                         "trainval/images")

        val_dataset = cfg.val_dataloader["dataset"]
        self.assertEqual(val_dataset["ann_file"], "test/hbb_dota_cleaned")
        self.assertEqual(val_dataset["data_prefix"]["img_path"], "test/images")
        self.assertTrue(val_dataset["test_mode"])

        pipeline_types = [step["type"] for step in cfg.train_pipeline]
        self.assertEqual(pipeline_types[0], "mmdet.LoadImageFromFile")
        self.assertIn("mmdet.LoadAnnotations", pipeline_types)
        self.assertIn("mmdet.Resize", pipeline_types)
        self.assertIn("mmdet.RandomFlip", pipeline_types)
        self.assertIn("FilterInvalidHorizontalBoxes", pipeline_types)
        self.assertEqual(pipeline_types[-1], "mmdet.PackDetInputs")
        self.assertGreater(pipeline_types.index("FilterInvalidHorizontalBoxes"),
                           pipeline_types.index("mmdet.RandomFlip"))

    def test_optimizer_scheduler_and_epoch_outputs(self):
        cfg = self.cfg
        self.assertEqual(cfg.train_cfg["type"], "EpochBasedTrainLoop")
        self.assertEqual(cfg.train_cfg["max_epochs"], 20)
        self.assertEqual(cfg.default_hooks["checkpoint"]["by_epoch"], True)
        self.assertEqual(cfg.default_hooks["checkpoint"]["save_best"],
                         "dior/mAP")
        self.assertEqual(cfg.log_processor["by_epoch"], True)

        self.assertEqual(cfg.optim_wrapper["constructor"],
                         "SwinV2LayerDecayOptimizerConstructor")
        optimizer = cfg.optim_wrapper["optimizer"]
        self.assertEqual(optimizer["type"], "AdamW")
        self.assertEqual(optimizer["lr"], 1e-4)
        self.assertEqual(optimizer["betas"], (0.9, 0.999))
        self.assertEqual(optimizer["weight_decay"], 0.05)

        paramwise_cfg = cfg.optim_wrapper["paramwise_cfg"]
        self.assertEqual(paramwise_cfg["num_layers"], 24)
        self.assertEqual(paramwise_cfg["layer_decay_rate"], 0.9)
        self.assertEqual(paramwise_cfg["depths"], (2, 2, 18, 2))
        self.assertIn("bias", paramwise_cfg["custom_keys"])
        self.assertIn("absolute_pos_embed", paramwise_cfg["custom_keys"])
        self.assertIn("norm", paramwise_cfg["custom_keys"])

        schedulers = {item["type"]: item for item in cfg.param_scheduler}
        self.assertEqual(schedulers["LinearLR"]["start_factor"], 1e-3)
        self.assertEqual(schedulers["LinearLR"]["end"], 1000)
        self.assertFalse(schedulers["LinearLR"]["by_epoch"])
        self.assertEqual(schedulers["MultiStepLR"]["end"], 20)
        self.assertTrue(schedulers["MultiStepLR"]["by_epoch"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
