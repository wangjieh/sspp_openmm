import importlib
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


PLUGIN_PACKAGES = {
    "sspp_mmseg": ("mmseg", "sspp_mmseg.models.backbones"),
    "sspp_mmdet": ("mmdet", "sspp_mmdet.models.backbones"),
    "sspp_mmrotate": ("mmrotate", "sspp_mmrotate.models.backbones"),
    "sspp_opencd": ("opencd", "sspp_opencd.models.backbones"),
}

BACKBONE_SPECS = {
    "SkySensePPHR": {
        "checkpoint": "skysensepp_release_hr.pth",
        "input_shape": (1, 3, 64, 64),
        "required_keys": [
            "patch_embed.projection.weight",
            "stages.0.blocks.0.attn.w_msa.qkv.weight",
        ],
    },
    "SkySensePPS1": {
        "checkpoint": "skysensepp_release_s1.pth",
        "input_shape": (1, 2, 16, 16),
        "required_keys": [
            "patch_embed.projection.weight",
            "layers.0.attn.attn.in_proj_weight",
        ],
    },
    "SkySensePPS2": {
        "checkpoint": "skysensepp_release_s2.pth",
        "input_shape": (1, 10, 16, 16),
        "required_keys": [
            "patch_embed.projection.weight",
            "layers.0.attn.attn.in_proj_weight",
        ],
    },
}

DEFAULT_CHECKPOINT_DIR = Path(
    r"F:\PythonProject\Skysense++\SkySensePlusPlus-main\pretrain"
)
REPO_ROOT = Path(__file__).resolve().parents[1]


class TestPluginBackbones(unittest.TestCase):
    def test_plugin_packages_are_importable(self):
        for package_name in PLUGIN_PACKAGES:
            with self.subTest(package=package_name):
                importlib.import_module(package_name)

    def test_plugin_packages_import_with_only_pythonpath_from_external_cwd(self):
        code = "import " + ", ".join(PLUGIN_PACKAGES)
        env = os.environ.copy()
        old_pythonpath = env.get("PYTHONPATH")
        env["PYTHONPATH"] = (
            str(REPO_ROOT)
            if not old_pythonpath else f"{REPO_ROOT}{os.pathsep}{old_pythonpath}")
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-c", code],
                cwd=tmpdir,
                env=env,
                text=True,
                capture_output=True,
            )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_readme_documents_linux_pythonpath_usage(self):
        readme = (REPO_ROOT / "README.md").read_text(encoding="utf-8")
        self.assertIn(
            "export PYTHONPATH=/path/to/skysensepp_openmm:$PYTHONPATH",
            readme,
        )
        for package_name in PLUGIN_PACKAGES:
            self.assertIn(package_name, readme)

    def test_backbone_classes_are_registered_modules(self):
        for package_name, (_, backbones_module) in PLUGIN_PACKAGES.items():
            module = importlib.import_module(backbones_module)
            for class_name in BACKBONE_SPECS:
                with self.subTest(package=package_name, backbone=class_name):
                    backbone_cls = getattr(module, class_name)
                    self.assertTrue(callable(backbone_cls))

    def test_backbones_run_tiny_forward_without_annotations(self):
        torch = _import_torch()
        for package_name, (_, backbones_module) in PLUGIN_PACKAGES.items():
            module = importlib.import_module(backbones_module)
            for class_name, spec in BACKBONE_SPECS.items():
                with self.subTest(package=package_name, backbone=class_name):
                    model = _instantiate_model(
                        getattr(module, class_name), out_indices=(-1,))
                    model.eval()
                    x = torch.randn(*spec["input_shape"])
                    with torch.no_grad():
                        outputs = model(x)
                    self.assertIsInstance(outputs, tuple)
                    self.assertGreaterEqual(len(outputs), 1)
                    for output in outputs:
                        self.assertEqual(output.ndim, 4)


class TestPretrainedCheckpoints(unittest.TestCase):
    def test_real_checkpoint_files_have_expected_keys_when_enabled(self):
        if os.environ.get("SSPP_RUN_REAL_CKPT") != "1":
            self.skipTest("Set SSPP_RUN_REAL_CKPT=1 to load real checkpoints.")
        torch = _import_torch()
        ckpt_dir = Path(os.environ.get("SSPP_CKPT_DIR", DEFAULT_CHECKPOINT_DIR))

        for class_name, spec in BACKBONE_SPECS.items():
            ckpt_path = ckpt_dir / spec["checkpoint"]
            with self.subTest(backbone=class_name, checkpoint=str(ckpt_path)):
                self.assertTrue(ckpt_path.exists(), f"Missing checkpoint: {ckpt_path}")
                state_dict = torch.load(str(ckpt_path), map_location="cpu")
                if isinstance(state_dict, dict) and "state_dict" in state_dict:
                    state_dict = state_dict["state_dict"]
                if isinstance(state_dict, dict) and "checkpoint" in state_dict:
                    state_dict = state_dict["checkpoint"]
                for key in spec["required_keys"]:
                    self.assertIn(key, state_dict)

    def test_real_checkpoints_load_into_backbones_when_enabled(self):
        if os.environ.get("SSPP_LOAD_REAL_MODELS") != "1":
            self.skipTest(
                "Set SSPP_LOAD_REAL_MODELS=1 to instantiate backbones and "
                "load real checkpoints.")
        torch = _import_torch()
        module = importlib.import_module("sspp_mmseg.models.backbones")
        ckpt_dir = Path(os.environ.get("SSPP_CKPT_DIR", DEFAULT_CHECKPOINT_DIR))

        for class_name, spec in BACKBONE_SPECS.items():
            ckpt_path = ckpt_dir / spec["checkpoint"]
            with self.subTest(backbone=class_name, checkpoint=str(ckpt_path)):
                self.assertTrue(ckpt_path.exists(), f"Missing checkpoint: {ckpt_path}")
                model = _instantiate_model(getattr(module, class_name))
                state_dict = _load_checkpoint_state_dict(torch, ckpt_path)
                for key in spec["required_keys"]:
                    self.assertIn(key, state_dict)
                missing, unexpected = model.load_state_dict(state_dict, strict=False)
                allowed_missing = (
                    "relative_position_index",
                    "relative_coords_table",
                )
                missing = [
                    key for key in missing
                    if not any(token in key for token in allowed_missing)
                ]
                unexpected = [
                    key for key in unexpected
                    if not any(token in key for token in allowed_missing)
                ]
                self.assertEqual(missing, [])
                self.assertEqual(unexpected, [])


def _import_torch():
    try:
        return importlib.import_module("torch")
    except ImportError as exc:
        raise unittest.SkipTest(f"PyTorch is not available: {exc}") from exc


def _instantiate_model(backbone_cls, **kwargs):
    try:
        return backbone_cls(**kwargs)
    except ImportError as exc:
        raise unittest.SkipTest(
            f"OpenMMLab dependencies are not available: {exc}") from exc


def _load_checkpoint_state_dict(torch, ckpt_path):
    state_dict = torch.load(str(ckpt_path), map_location="cpu")
    if isinstance(state_dict, dict) and "state_dict" in state_dict:
        state_dict = state_dict["state_dict"]
    if isinstance(state_dict, dict) and "checkpoint" in state_dict:
        state_dict = state_dict["checkpoint"]
    return state_dict


if __name__ == "__main__":
    unittest.main(verbosity=2)
