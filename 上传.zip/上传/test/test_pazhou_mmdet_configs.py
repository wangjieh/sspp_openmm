import importlib.util
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SSPP_MMDET = ROOT / "sspp_mmdet"
CONFIG = (
    SSPP_MMDET
    / "configs"
    / "pazhou_competition"
    / "pazhou_hr_faster_rcnn_20e_800x800.py"
)


PAZHOU_CLASSES = (
    "Four-way junction",
    "Three-way junction",
    "Roundabout",
)


def load_config(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TestPazhouMMDetSource(unittest.TestCase):

    def test_dataset_and_transforms_are_exported(self):
        dataset_file = SSPP_MMDET / "datasets" / "pazhou_coco_dataset.py"
        dataset_init = SSPP_MMDET / "datasets" / "__init__.py"
        transform_init = SSPP_MMDET / "datasets" / "transforms" / "__init__.py"

        self.assertTrue(dataset_file.exists())
        source = dataset_file.read_text(encoding="utf-8")
        self.assertIn("class PazhouCocoDataset", source)
        self.assertIn("@DATASETS.register_module()", source)
        self.assertIn("CocoDataset", source)
        self.assertIn("filter_empty_gt", source)
        self.assertIn("test_slice", CONFIG.read_text(encoding="utf-8"))
        for class_name in PAZHOU_CLASSES:
            self.assertIn(f'"{class_name}"', source)

        self.assertIn("PazhouCocoDataset",
                      dataset_init.read_text(encoding="utf-8"))
        transform_exports = transform_init.read_text(encoding="utf-8")
        self.assertIn("LoadImageFromRasterio", transform_exports)
        self.assertIn("FilterSmallHorizontalBoxes", transform_exports)

    def test_rasterio_loader_is_registered_without_geospatial_processing(self):
        loader_file = SSPP_MMDET / "datasets" / "transforms" / "rasterio_loading.py"
        self.assertTrue(loader_file.exists())
        source = loader_file.read_text(encoding="utf-8")
        self.assertIn("class LoadImageFromRasterio", source)
        self.assertIn("@TRANSFORMS.register_module()", source)
        self.assertIn("rasterio.open", source)
        self.assertIn("dataset.read", source)
        self.assertNotIn("reproject", source)
        self.assertNotIn("warp", source)
        self.assertNotIn("resample", source)

    def test_small_box_filter_keeps_out_of_bounds_boxes(self):
        try:
            import numpy as np
        except ImportError as exc:
            self.skipTest(f"numpy is unavailable: {exc}")

        from sspp_mmdet.datasets.transforms import FilterSmallHorizontalBoxes

        transform = FilterSmallHorizontalBoxes(min_size=1.0, log_interval=1)
        results = dict(
            img_shape=(800, 800),
            img_path="sample.png",
            gt_bboxes=np.array(
                [
                    [0.0, 0.0, 0.5, 10.0],
                    [0.0, 0.0, 10.0, 0.5],
                    [-5.0, 0.0, 10.0, 10.0],
                    [0.0, 0.0, 10.0, 10.0],
                ],
                dtype=np.float32),
            gt_bboxes_labels=np.array([0, 1, 2, 1], dtype=np.int64),
            gt_ignore_flags=np.array([False, False, True, False], dtype=bool),
        )

        filtered = transform.transform(results)

        self.assertEqual(filtered["gt_bboxes"].shape[0], 2)
        np.testing.assert_array_equal(filtered["gt_bboxes_labels"],
                                      np.array([2, 1], dtype=np.int64))
        np.testing.assert_array_equal(filtered["gt_ignore_flags"],
                                      np.array([True, False], dtype=bool))
        self.assertEqual(transform.reason_counts["too_small"], 2)
        self.assertEqual(transform.reason_counts["out_of_bounds"], 0)


class TestPazhouMMDetConfig(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        if not CONFIG.exists():
            raise AssertionError(f"Missing config: {CONFIG}")
        cls.cfg = load_config(CONFIG)

    def test_config_is_standalone(self):
        self.assertFalse(hasattr(self.cfg, "_base_"))

    def test_model_uses_skysensepp_hr_faster_rcnn(self):
        cfg = self.cfg
        self.assertIn("sspp_mmdet", cfg.custom_imports["imports"])
        model = cfg.model
        self.assertEqual(model["type"], "FasterRCNN")
        self.assertEqual(model["data_preprocessor"]["mean"],
                         [70.667, 68.437, 61.733])
        self.assertEqual(model["data_preprocessor"]["std"],
                         [56.609, 53.159, 51.721])
        self.assertFalse(model["data_preprocessor"]["bgr_to_rgb"])
        self.assertEqual(model["backbone"]["type"], "SkySensePPHR")
        self.assertEqual(model["backbone"]["in_channels"], 3)
        self.assertEqual(model["backbone"]["patch_size"], 4)
        self.assertEqual(model["backbone"]["window_size"], 8)
        self.assertEqual(model["backbone"]["drop_path_rate"], 0.3)
        self.assertEqual(model["neck"]["type"], "FPN")
        self.assertEqual(model["neck"]["in_channels"], [352, 704, 1408, 2816])
        self.assertEqual(model["roi_head"]["bbox_head"]["num_classes"], 3)
        self.assertEqual(model["roi_head"]["bbox_head"]["loss_cls"]["type"],
                         "CrossEntropyLoss")
        self.assertEqual(model["roi_head"]["bbox_head"]["loss_bbox"]["type"],
                         "SmoothL1Loss")

    def test_dataset_layout_and_pipelines(self):
        cfg = self.cfg
        self.assertEqual(cfg.dataset_type, "PazhouCocoDataset")
        self.assertEqual(cfg.batch_size, 8)
        self.assertEqual(cfg.train_dataloader["batch_size"], 8)
        self.assertEqual(cfg.classes, PAZHOU_CLASSES)

        train_dataset = cfg.train_dataloader["dataset"]
        self.assertEqual(train_dataset["ann_file"],
                         "train_slices/annotations.json")
        self.assertEqual(train_dataset["data_prefix"]["img"],
                         "train_slices/images")
        self.assertFalse(train_dataset["filter_cfg"]["filter_empty_gt"])

        val_dataset = cfg.val_dataloader["dataset"]
        self.assertEqual(val_dataset["ann_file"], "val_slices/annotations.json")
        self.assertEqual(val_dataset["data_prefix"]["img"], "val_slices/images")
        self.assertTrue(val_dataset["test_mode"])

        test_dataset = cfg.test_dataloader["dataset"]
        self.assertEqual(test_dataset["ann_file"], "")
        self.assertEqual(test_dataset["data_prefix"]["img"],
                         "test_slice/images")
        self.assertTrue(test_dataset["test_mode"])

        train_types = [step["type"] for step in cfg.train_pipeline]
        self.assertEqual(train_types[0], "LoadImageFromRasterio")
        self.assertIn("LoadAnnotations", train_types)
        self.assertIn("Resize", train_types)
        self.assertIn("RandomFlip", train_types)
        self.assertIn("FilterSmallHorizontalBoxes", train_types)
        self.assertEqual(train_types[-1], "PackDetInputs")
        self.assertGreater(train_types.index("FilterSmallHorizontalBoxes"),
                           train_types.index("RandomFlip"))

        test_types = [step["type"] for step in cfg.test_pipeline]
        self.assertEqual(test_types[0], "LoadImageFromRasterio")
        self.assertNotIn("LoadAnnotations", test_types)
        self.assertNotIn("FilterSmallHorizontalBoxes", test_types)

    def test_optimizer_scheduler_and_epoch_outputs(self):
        cfg = self.cfg
        self.assertEqual(cfg.train_cfg["type"], "EpochBasedTrainLoop")
        self.assertEqual(cfg.train_cfg["max_epochs"], 20)
        self.assertTrue(cfg.default_hooks["checkpoint"]["by_epoch"])
        self.assertEqual(cfg.default_hooks["checkpoint"]["save_best"],
                         "pazhou/bbox_mAP")
        self.assertEqual(cfg.log_processor["by_epoch"], True)

        self.assertEqual(cfg.optim_wrapper["constructor"],
                         "SwinV2LayerDecayOptimizerConstructor")
        optimizer = cfg.optim_wrapper["optimizer"]
        self.assertEqual(optimizer["type"], "AdamW")
        self.assertEqual(optimizer["lr"], 1e-4)
        self.assertEqual(optimizer["betas"], (0.9, 0.999))
        self.assertEqual(optimizer["weight_decay"], 0.05)

        paramwise_cfg = cfg.optim_wrapper["paramwise_cfg"]
        self.assertEqual(paramwise_cfg["num_layers"], 24)
        self.assertEqual(paramwise_cfg["layer_decay_rate"], 0.9)
        self.assertEqual(paramwise_cfg["depths"], (2, 2, 18, 2))
        self.assertIn("bias", paramwise_cfg["custom_keys"])
        self.assertIn("absolute_pos_embed", paramwise_cfg["custom_keys"])
        self.assertIn("norm", paramwise_cfg["custom_keys"])

        schedulers = {item["type"]: item for item in cfg.param_scheduler}
        self.assertEqual(schedulers["LinearLR"]["start_factor"], 1e-3)
        self.assertEqual(schedulers["LinearLR"]["end"], 1000)
        self.assertFalse(schedulers["LinearLR"]["by_epoch"])
        self.assertEqual(schedulers["MultiStepLR"]["milestones"], [12, 16])
        self.assertEqual(schedulers["MultiStepLR"]["end"], 20)
        self.assertTrue(schedulers["MultiStepLR"]["by_epoch"])

    def test_coco_evaluators(self):
        cfg = self.cfg
        self.assertEqual(cfg.val_evaluator["type"], "CocoMetric")
        self.assertEqual(cfg.val_evaluator["metric"], "bbox")
        self.assertFalse(cfg.val_evaluator["format_only"])
        self.assertEqual(cfg.val_evaluator["prefix"], "pazhou")
        self.assertEqual(cfg.test_evaluator["type"], "CocoMetric")
        self.assertEqual(cfg.test_evaluator["metric"], "bbox")
        self.assertTrue(cfg.test_evaluator["format_only"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
