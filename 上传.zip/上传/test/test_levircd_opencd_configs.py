import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "sspp_opencd" / "configs" / "LEVIR-CD" / "levircd_hr_absdiff_upernet_20e_128x128.py"


def load_config_values(path):
    namespace = {}
    exec(compile(path.read_text(encoding="utf-8"), str(path), "exec"), namespace)
    return namespace


class TestLEVIRCDOpenCDSource(unittest.TestCase):

    def test_dataset_is_registered_and_uses_binary_label_format(self):
        dataset_init = ROOT / "sspp_opencd" / "datasets" / "__init__.py"
        dataset_file = ROOT / "sspp_opencd" / "datasets" / "levir_cd_dataset.py"
        registry_file = ROOT / "sspp_opencd" / "_registry.py"
        package_init = ROOT / "sspp_opencd" / "__init__.py"

        self.assertTrue(dataset_init.is_file())
        self.assertTrue(dataset_file.is_file())
        self.assertIn("DATASETS", registry_file.read_text(encoding="utf-8"))
        self.assertIn("datasets", package_init.read_text(encoding="utf-8"))

        dataset_source = dataset_file.read_text(encoding="utf-8")
        self.assertIn("class LEVIRCDDataset", dataset_source)
        self.assertIn("@DATASETS.register_module()", dataset_source)
        self.assertIn('img_suffix=".png"', dataset_source)
        self.assertIn('seg_map_suffix=".png"', dataset_source)
        self.assertIn('format_seg_map="to_binary"', dataset_source)
        self.assertIn('"unchanged"', dataset_source)
        self.assertIn('"changed"', dataset_source)

        init_source = dataset_init.read_text(encoding="utf-8")
        self.assertIn("LEVIRCDDataset", init_source)

    def test_abs_diff_detector_is_registered_and_uses_shared_backbone(self):
        detector_init = ROOT / "sspp_opencd" / "models" / "change_detectors" / "__init__.py"
        detector_file = (
            ROOT
            / "sspp_opencd"
            / "models"
            / "change_detectors"
            / "abs_diff_encoder_decoder.py"
        )
        models_init = ROOT / "sspp_opencd" / "models" / "__init__.py"

        self.assertTrue(detector_init.is_file())
        self.assertTrue(detector_file.is_file())
        self.assertIn("change_detectors", models_init.read_text(encoding="utf-8"))

        source = detector_file.read_text(encoding="utf-8")
        self.assertIn("class SkySensePPAbsDiffEncoderDecoder", source)
        self.assertIn("@MODELS.register_module()", source)
        self.assertIn("SiamEncoderDecoder", source)
        self.assertIn("torch.split", source)
        self.assertIn("torch.abs", source)
        self.assertIn("self.backbone(img_from)", source)
        self.assertIn("self.backbone(img_to)", source)

        init_source = detector_init.read_text(encoding="utf-8")
        self.assertIn("SkySensePPAbsDiffEncoderDecoder", init_source)


class TestLEVIRCDOpenCDConfig(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        if not CONFIG.is_file():
            raise AssertionError(f"Missing config: {CONFIG}")
        cls.cfg = load_config_values(CONFIG)

    def test_custom_import_and_model(self):
        cfg = self.cfg
        self.assertIn("sspp_opencd", cfg["custom_imports"]["imports"])

        model = cfg["model"]
        self.assertEqual(model["type"], "SkySensePPAbsDiffEncoderDecoder")
        self.assertEqual(model["backbone_inchannels"], 3)

        backbone = model["backbone"]
        self.assertEqual(backbone["type"], "SkySensePPHR")
        self.assertEqual(backbone["in_channels"], 3)
        self.assertEqual(backbone["patch_size"], 4)
        self.assertEqual(backbone["window_size"], 8)
        self.assertEqual(backbone["out_indices"], (0, 1, 2, 3))

        decode_head = model["decode_head"]
        self.assertEqual(decode_head["type"], "mmseg.UPerHead")
        self.assertEqual(decode_head["num_classes"], 2)
        self.assertEqual(decode_head["ignore_index"], 255)
        self.assertEqual(decode_head["loss_decode"]["type"], "mmseg.CrossEntropyLoss")
        self.assertNotIn("ignore_index", decode_head["loss_decode"])

    def test_dual_input_data_preprocessor(self):
        data_preprocessor = self.cfg["model"]["data_preprocessor"]
        self.assertEqual(data_preprocessor["type"], "DualInputSegDataPreProcessor")
        self.assertEqual(data_preprocessor["size"], (128, 128))
        self.assertTrue(data_preprocessor["bgr_to_rgb"])
        self.assertEqual(len(data_preprocessor["mean"]), 6)
        self.assertEqual(len(data_preprocessor["std"]), 6)

    def test_dataloaders_follow_levir_cd_directory_layout(self):
        cfg = self.cfg
        self.assertEqual(cfg["train_dataloader"]["batch_size"], 8)

        expected = {
            "train_dataloader": ("train_sliced/A", "train_sliced/B", "train_sliced/label"),
            "val_dataloader": ("val_sliced/A", "val_sliced/B", "val_sliced/label"),
            "test_dataloader": ("test_sliced/A", "test_sliced/B", "test_sliced/label"),
        }
        for dataloader_name, prefixes in expected.items():
            with self.subTest(dataloader=dataloader_name):
                dataset = cfg[dataloader_name]["dataset"]
                self.assertEqual(dataset["type"], "LEVIRCDDataset")
                self.assertEqual(dataset["data_prefix"]["img_path_from"], prefixes[0])
                self.assertEqual(dataset["data_prefix"]["img_path_to"], prefixes[1])
                self.assertEqual(dataset["data_prefix"]["seg_map_path"], prefixes[2])

    def test_pipeline_uses_random_flip_only(self):
        train_pipeline = self.cfg["train_pipeline"]
        types = [step["type"] for step in train_pipeline]

        self.assertEqual(types[0], "MultiImgLoadImageFromFile")
        self.assertIn("MultiImgLoadAnnotations", types)
        self.assertIn("MultiImgRandomFlip", types)
        self.assertEqual(types[-1], "MultiImgPackSegInputs")
        self.assertNotIn("MultiImgRandomCrop", types)
        self.assertNotIn("MultiImgRandomRotate", types)

    def test_optimizer_scheduler_and_epoch_hooks(self):
        cfg = self.cfg
        optimizer = cfg["optim_wrapper"]["optimizer"]
        self.assertEqual(optimizer["type"], "AdamW")
        self.assertEqual(optimizer["lr"], 5e-4)
        self.assertEqual(optimizer["weight_decay"], 0.01)

        self.assertEqual(cfg["train_cfg"]["type"], "EpochBasedTrainLoop")
        self.assertEqual(cfg["train_cfg"]["max_epochs"], 20)

        schedulers = cfg["param_scheduler"]
        warmup = schedulers[0]
        self.assertEqual(warmup["type"], "LinearLR")
        self.assertFalse(warmup["by_epoch"])
        self.assertEqual(warmup["end"], 1500)
        self.assertEqual(warmup["start_factor"], 1e-6)

        poly = schedulers[1]
        self.assertEqual(poly["type"], "PolyLR")
        self.assertTrue(poly["by_epoch"])
        self.assertEqual(poly["end"], 20)

        self.assertTrue(cfg["log_processor"]["by_epoch"])
        self.assertTrue(cfg["default_hooks"]["checkpoint"]["by_epoch"])
        self.assertTrue(cfg["default_hooks"]["logger"]["log_metric_by_epoch"])


if __name__ == "__main__":
    unittest.main()
