import importlib.util
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SSPP_MMROTATE = ROOT / "sspp_mmrotate"
CONFIG = (
    SSPP_MMROTATE
    / "configs"
    / "DOTA-R"
    / "dota2_hr_oriented_rcnn_20e_800x800.py"
)


DOTA2_CLASSES = (
    "airport",
    "baseball-diamond",
    "basketball-court",
    "bridge",
    "container-crane",
    "ground-track-field",
    "harbor",
    "helicopter",
    "helipad",
    "large-vehicle",
    "plane",
    "roundabout",
    "ship",
    "small-vehicle",
    "soccer-ball-field",
    "storage-tank",
    "swimming-pool",
    "tennis-court",
)


def load_config(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TestDOTA2MMRotateSource(unittest.TestCase):

    def test_dota2_dataset_is_registered_with_expected_classes(self):
        dataset_file = SSPP_MMROTATE / "datasets" / "dota2_dataset.py"
        dataset_init = SSPP_MMROTATE / "datasets" / "__init__.py"

        self.assertTrue(dataset_file.exists())
        source = dataset_file.read_text(encoding="utf-8")
        self.assertIn("class DOTA2Dataset", source)
        self.assertIn("@DATASETS.register_module()", source)
        self.assertIn("DOTADataset", source)
        self.assertIn("img_suffix=\"png\"", source)
        for class_name in DOTA2_CLASSES:
            self.assertIn(f'"{class_name}"', source)

        self.assertIn("DOTA2Dataset", dataset_init.read_text(encoding="utf-8"))

    def test_reuses_existing_rotated_filter_and_swinv2_constructor(self):
        transform_init = SSPP_MMROTATE / "datasets" / "transforms" / "__init__.py"
        optimizer_init = SSPP_MMROTATE / "engine" / "optimizers" / "__init__.py"
        self.assertIn("FilterInvalidRotatedBoxes",
                      transform_init.read_text(encoding="utf-8"))
        self.assertIn("SwinV2LayerDecayOptimizerConstructor",
                      optimizer_init.read_text(encoding="utf-8"))


class TestDOTA2MMRotateConfig(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        if not CONFIG.exists():
            raise AssertionError(f"Missing config: {CONFIG}")
        cls.cfg = load_config(CONFIG)

    def test_config_is_standalone(self):
        self.assertFalse(hasattr(self.cfg, "_base_"))

    def test_model_uses_hr_oriented_rcnn(self):
        cfg = self.cfg
        self.assertIn("sspp_mmrotate", cfg.custom_imports["imports"])
        model = cfg.model
        self.assertEqual(model["type"], "mmdet.FasterRCNN")
        self.assertEqual(model["backbone"]["type"], "SkySensePPHR")
        self.assertEqual(model["backbone"]["in_channels"], 3)
        self.assertEqual(model["backbone"]["patch_size"], 4)
        self.assertEqual(model["backbone"]["window_size"], 8)
        self.assertEqual(model["backbone"]["drop_path_rate"], 0.3)
        self.assertEqual(model["neck"]["type"], "mmdet.FPN")
        self.assertEqual(model["rpn_head"]["type"], "OrientedRPNHead")
        self.assertEqual(model["roi_head"]["bbox_head"]["num_classes"], 18)
        self.assertEqual(model["roi_head"]["bbox_head"]["loss_cls"]["type"],
                         "mmdet.CrossEntropyLoss")
        self.assertEqual(model["roi_head"]["bbox_head"]["loss_bbox"]["type"],
                         "mmdet.SmoothL1Loss")

    def test_dataset_layout_and_pipeline(self):
        cfg = self.cfg
        self.assertEqual(cfg.dataset_type, "DOTA2Dataset")
        self.assertEqual(cfg.num_classes, 18)
        self.assertEqual(cfg.batch_size, 4)
        self.assertEqual(cfg.train_dataloader["batch_size"], 4)

        train_dataset = cfg.train_dataloader["dataset"]
        self.assertEqual(train_dataset["type"], "DOTA2Dataset")
        self.assertEqual(train_dataset["ann_file"], "trainval/labelTxt_obb")
        self.assertEqual(train_dataset["data_prefix"]["img_path"],
                         "trainval/images")

        val_dataset = cfg.val_dataloader["dataset"]
        self.assertEqual(val_dataset["ann_file"], "val/labelTxt_obb")
        self.assertEqual(val_dataset["data_prefix"]["img_path"], "val/images")
        self.assertTrue(val_dataset["test_mode"])

        pipeline_types = [step["type"] for step in cfg.train_pipeline]
        self.assertEqual(pipeline_types[0], "mmdet.LoadImageFromFile")
        self.assertIn("mmdet.LoadAnnotations", pipeline_types)
        self.assertIn("ConvertBoxType", pipeline_types)
        self.assertIn("mmdet.Resize", pipeline_types)
        self.assertIn("mmdet.RandomFlip", pipeline_types)
        self.assertIn("FilterInvalidRotatedBoxes", pipeline_types)
        self.assertEqual(pipeline_types[-1], "mmdet.PackDetInputs")
        self.assertGreater(pipeline_types.index("FilterInvalidRotatedBoxes"),
                           pipeline_types.index("mmdet.RandomFlip"))

    def test_optimizer_scheduler_and_epoch_outputs(self):
        cfg = self.cfg
        self.assertEqual(cfg.train_cfg["type"], "EpochBasedTrainLoop")
        self.assertEqual(cfg.train_cfg["max_epochs"], 20)
        self.assertEqual(cfg.default_hooks["checkpoint"]["by_epoch"], True)
        self.assertEqual(cfg.log_processor["by_epoch"], True)
        self.assertTrue(cfg.find_unused_parameters)
        self.assertTrue(cfg.model_wrapper_cfg["find_unused_parameters"])

        self.assertEqual(cfg.optim_wrapper["constructor"],
                         "SwinV2LayerDecayOptimizerConstructor")
        optimizer = cfg.optim_wrapper["optimizer"]
        self.assertEqual(optimizer["type"], "AdamW")
        self.assertEqual(optimizer["lr"], 1e-4)
        self.assertEqual(optimizer["betas"], (0.9, 0.999))
        self.assertEqual(optimizer["weight_decay"], 0.05)

        paramwise_cfg = cfg.optim_wrapper["paramwise_cfg"]
        self.assertEqual(paramwise_cfg["num_layers"], 24)
        self.assertEqual(paramwise_cfg["layer_decay_rate"], 0.9)
        self.assertEqual(paramwise_cfg["depths"], (2, 2, 18, 2))
        self.assertIn("bias", paramwise_cfg["custom_keys"])
        self.assertIn("absolute_pos_embed", paramwise_cfg["custom_keys"])
        self.assertIn("norm", paramwise_cfg["custom_keys"])

        schedulers = {item["type"]: item for item in cfg.param_scheduler}
        self.assertEqual(schedulers["LinearLR"]["start_factor"], 1e-3)
        self.assertEqual(schedulers["LinearLR"]["end"], 1000)
        self.assertFalse(schedulers["LinearLR"]["by_epoch"])
        self.assertEqual(schedulers["MultiStepLR"]["end"], 20)
        self.assertTrue(schedulers["MultiStepLR"]["by_epoch"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
