import importlib.util
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
SSPP_MMSEG = REPO_ROOT / "sspp_mmseg"
SVDT_CONFIG_DIR = SSPP_MMSEG / "configs" / "SVDT"


class TestSVDTMMSegSupport(unittest.TestCase):
    def test_dataset_and_transform_files_are_registered(self):
        dataset_file = SSPP_MMSEG / "datasets" / "svdt_dataset.py"
        transform_file = SSPP_MMSEG / "datasets" / "transforms" / "svdt_transforms.py"
        segmentor_file = SSPP_MMSEG / "models" / "segmentors" / "svdt_encoder_decoder.py"
        datasets_init = SSPP_MMSEG / "datasets" / "__init__.py"
        transforms_init = SSPP_MMSEG / "datasets" / "transforms" / "__init__.py"
        models_init = SSPP_MMSEG / "models" / "__init__.py"

        self.assertTrue(dataset_file.exists())
        self.assertTrue(transform_file.exists())
        self.assertTrue(segmentor_file.exists())
        self.assertIn("SVDTDataset", dataset_file.read_text(encoding="utf-8"))
        self.assertIn("SVDTMapAnnotationsAndIgnorePixels",
                      transform_file.read_text(encoding="utf-8"))
        self.assertIn("SVDTEncoderDecoder",
                      segmentor_file.read_text(encoding="utf-8"))
        self.assertIn("SVDTDataset", datasets_init.read_text(encoding="utf-8"))
        self.assertIn("SVDTMapAnnotationsAndIgnorePixels",
                      transforms_init.read_text(encoding="utf-8"))
        self.assertIn("segmentors", models_init.read_text(encoding="utf-8"))

    def test_transform_documents_label_and_ignore_rules(self):
        source = (
            SSPP_MMSEG / "datasets" / "transforms" / "svdt_transforms.py"
        ).read_text(encoding="utf-8")
        self.assertIn("gt_seg_map[gt_seg_map == self.crop_value] = self.crop_label", source)
        self.assertIn("invalid_black", source)
        self.assertIn("invalid_white", source)
        self.assertIn('results["svdt_invalid_mask"] = invalid_mask', source)
        self.assertIn("gt_seg_map[invalid_mask] = self.ignore_index", source)

    def test_transform_maps_labels_and_ignores_black_white_pixels(self):
        try:
            import numpy as np
        except ImportError as exc:
            self.skipTest(f"numpy is not available: {exc}")

        from sspp_mmseg.datasets.transforms import SVDTMapAnnotationsAndIgnorePixels

        transform = SVDTMapAnnotationsAndIgnorePixels()
        results = transform.transform(
            dict(
                img=np.array(
                    [[[0, 0, 0], [255, 255, 255], [10, 20, 30]]],
                    dtype=np.uint8),
                gt_seg_map=np.array([[0, 255, 255]], dtype=np.uint8)))

        np.testing.assert_array_equal(
            results["gt_seg_map"], np.array([[255, 255, 1]], dtype=np.uint8))
        np.testing.assert_array_equal(
            results["svdt_invalid_mask"],
            np.array([[True, True, False]], dtype=bool))

    def test_four_svdt_configs_exist_with_expected_strategies(self):
        expected = {
            "svdt_hr_upernet_freeze10_ft40.py": ("UPerHead", "FreezeBackboneHook", 10),
            "svdt_hr_upernet_frozen_backbone.py": ("UPerHead", "frozen_stages", 3),
            "svdt_hr_linear_freeze10_ft40.py": ("FCNHead", "FreezeBackboneHook", 10),
            "svdt_hr_linear_frozen_backbone.py": ("FCNHead", "frozen_stages", 3),
        }
        for filename, (head_type, freeze_marker, freeze_value) in expected.items():
            with self.subTest(config=filename):
                config_path = SVDT_CONFIG_DIR / filename
                self.assertTrue(config_path.exists(), config_path)
                cfg = _load_config_module(config_path)
                self.assertEqual(cfg.model["type"], "SVDTEncoderDecoder")
                self.assertEqual(cfg.model["backbone"]["type"], "SkySensePPHR")
                self.assertEqual(cfg.model["backbone"]["patch_size"], 4)
                self.assertEqual(cfg.model["backbone"]["window_size"], 8)
                self.assertEqual(cfg.model["decode_head"]["type"], head_type)
                self.assertEqual(cfg.train_cfg["max_epochs"], 50)
                self.assertEqual(cfg.train_dataloader["dataset"]["type"], "SVDTDataset")
                self.assertEqual(cfg.train_dataloader["dataset"]["ann_file"], "train.txt")
                self.assertEqual(cfg.val_dataloader["dataset"]["ann_file"], "valid.txt")
                self.assertEqual(cfg.train_dataloader["sampler"]["type"], "DefaultSampler")
                self.assertTrue(cfg.train_dataloader["sampler"]["shuffle"])
                self.assertEqual(cfg.val_dataloader["sampler"]["type"], "DefaultSampler")
                self.assertFalse(cfg.val_dataloader["sampler"]["shuffle"])
                self.assertEqual(cfg.env_cfg["dist_cfg"]["backend"], "nccl")
                self.assertTrue(cfg.find_unused_parameters)
                self.assertTrue(cfg.model_wrapper_cfg["find_unused_parameters"])
                self.assertIn("auto_scale_lr", cfg.__dict__)
                self.assertIn("sspp_mmseg", cfg.custom_imports["imports"])
                text = config_path.read_text(encoding="utf-8")
                self.assertIn("SyncBN", text)
                self.assertIn("svdt_invalid_mask", text)
                self.assertIn(freeze_marker, text)
                self.assertIn(str(freeze_value), text)


def _load_config_module(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


if __name__ == "__main__":
    unittest.main(verbosity=2)
