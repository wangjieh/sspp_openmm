"""Change detectors for the SkySense++ Open-CD plugin."""

from .abs_diff_encoder_decoder import SkySensePPAbsDiffEncoderDecoder

__all__ = ["SkySensePPAbsDiffEncoderDecoder"]
