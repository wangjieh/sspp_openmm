"""Shared-backbone absolute-difference change detector."""

from __future__ import annotations

from ..._registry import MODELS


_IMPORT_ERROR = None

try:
    import torch
    from opencd.models.change_detectors.siamencoder_decoder import (
        SiamEncoderDecoder,
    )
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    SiamEncoderDecoder = object


def _missing_dependency_message() -> str:
    return (
        "SkySensePPAbsDiffEncoderDecoder requires PyTorch and Open-CD to be "
        f"installed and importable. The current import error was: {_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @MODELS.register_module()
    class SkySensePPAbsDiffEncoderDecoder(SiamEncoderDecoder):
        """Placeholder used when Open-CD dependencies are unavailable."""

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    @MODELS.register_module()
    class SkySensePPAbsDiffEncoderDecoder(SiamEncoderDecoder):
        """Siamese encoder-decoder using abs-diff multi-level features.

        The two temporal images share ``self.backbone``. Each backbone output
        level is fused as ``abs(feat_from - feat_to)`` and passed directly to
        the decode head, which matches UPerHead-style multi-scale inputs.
        """

        def extract_feat(self, inputs):
            """Extract and fuse multi-level features from two RGB images."""
            img_from, img_to = torch.split(
                inputs, self.backbone_inchannels, dim=1)
            feat_from = self.backbone(img_from)
            feat_to = self.backbone(img_to)
            diff_feats = tuple(
                torch.abs(feat_from_i - feat_to_i)
                for feat_from_i, feat_to_i in zip(feat_from, feat_to))
            if self.with_neck:
                return self.neck(diff_feats)
            return diff_feats


__all__ = ["SkySensePPAbsDiffEncoderDecoder"]
