"""Dual-branch SkySense++ absolute-difference change detector."""

from __future__ import annotations

from ..._registry import MODELS


_IMPORT_ERROR = None

try:
    import torch
    import torch.nn.functional as F
    from opencd.models.change_detectors.siamencoder_decoder import (
        SiamEncoderDecoder,
    )
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    SiamEncoderDecoder = object


def _missing_dependency_message() -> str:
    return (
        "SkySensePPDualBranchAbsDiffEncoderDecoder requires PyTorch and "
        "Open-CD to be installed and importable. The current import error was: "
        f"{_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @MODELS.register_module()
    class SkySensePPDualBranchAbsDiffEncoderDecoder(SiamEncoderDecoder):
        """Placeholder used when Open-CD dependencies are unavailable."""

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    @MODELS.register_module()
    class SkySensePPDualBranchAbsDiffEncoderDecoder(SiamEncoderDecoder):
        """Two-backbone optical/SAR change detector using abs-diff features."""

        def __init__(self,
                     opt_backbone,
                     sar_backbone,
                     input_split=(10, 2),
                     pyramid_scales=(1.0, 0.5, 0.25, 0.125),
                     **kwargs):
            super().__init__(backbone=opt_backbone, **kwargs)
            self.opt_backbone = self.backbone
            self.sar_backbone = MODELS.build(sar_backbone)
            self.input_split = tuple(int(value) for value in input_split)
            if len(self.input_split) != 2:
                raise ValueError("input_split must contain OPT and SAR sizes.")
            self.pyramid_scales = tuple(float(value)
                                        for value in pyramid_scales)

        def extract_feat(self, inputs):
            """Extract S2/S1 features and fuse them as ``abs(SAR - OPT)``."""
            opt_channels, sar_channels = self.input_split
            expected_channels = opt_channels + sar_channels
            if inputs.shape[1] != expected_channels:
                raise ValueError(
                    f"Expected {expected_channels} input channels, got "
                    f"{inputs.shape[1]}.")

            opt_x = inputs[:, :opt_channels, :, :]
            sar_x = inputs[:, opt_channels:, :, :]
            opt_feats = self.opt_backbone(opt_x)
            sar_feats = self.sar_backbone(sar_x)
            if len(opt_feats) != len(sar_feats):
                raise ValueError(
                    "OPT and SAR backbones must return the same number of "
                    f"feature maps, got {len(opt_feats)} and {len(sar_feats)}.")
            if len(opt_feats) != len(self.pyramid_scales):
                raise ValueError(
                    "pyramid_scales length must match backbone out_indices, "
                    f"got {len(self.pyramid_scales)} and {len(opt_feats)}.")

            diff_feats = []
            for opt_feat, sar_feat, scale in zip(
                    opt_feats, sar_feats, self.pyramid_scales):
                if sar_feat.shape[-2:] != opt_feat.shape[-2:]:
                    sar_feat = F.interpolate(
                        sar_feat,
                        size=opt_feat.shape[-2:],
                        mode="bilinear",
                        align_corners=False)
                if sar_feat.shape[1] != opt_feat.shape[1]:
                    raise ValueError(
                        "OPT and SAR feature channels must match, got "
                        f"{opt_feat.shape[1]} and {sar_feat.shape[1]}.")
                diff_feat = torch.abs(sar_feat - opt_feat)
                if scale != 1.0:
                    height = max(1, int(round(diff_feat.shape[-2] * scale)))
                    width = max(1, int(round(diff_feat.shape[-1] * scale)))
                    diff_feat = F.interpolate(
                        diff_feat,
                        size=(height, width),
                        mode="bilinear",
                        align_corners=False)
                diff_feats.append(diff_feat)

            diff_feats = tuple(diff_feats)
            if self.with_neck:
                return self.neck(diff_feats)
            return diff_feats


__all__ = ["SkySensePPDualBranchAbsDiffEncoderDecoder"]
