"""Framework registry helpers for the SkySense++ Open-CD plugin."""

from __future__ import annotations

import importlib


class _FallbackRegistry:
    """Small no-op registry used when OpenMMLab is not installed locally."""

    def register_module(self, *args, **kwargs):
        if args and callable(args[0]):
            return args[0]

        def _decorate(module):
            return module

        return _decorate


def _load_registry(registry_name: str):
    package_root = __name__.split(".")[0]
    framework_map = {
        "sspp_mmseg": "mmseg",
        "sspp_mmdet": "mmdet",
        "sspp_mmrotate": "mmrotate",
        "sspp_opencd": "opencd",
    }
    framework = framework_map.get(package_root, "opencd")
    try:
        registry_module = importlib.import_module(f"{framework}.registry")
    except ImportError:
        registry_module = None
    if registry_module is not None and hasattr(registry_module, registry_name):
        return getattr(registry_module, registry_name)
    try:
        mmengine_registry = importlib.import_module("mmengine.registry")
    except ImportError:
        return _FallbackRegistry()
    return getattr(mmengine_registry, registry_name, _FallbackRegistry())


MODELS = _load_registry("MODELS")
DATASETS = _load_registry("DATASETS")
OPTIM_WRAPPER_CONSTRUCTORS = _load_registry("OPTIM_WRAPPER_CONSTRUCTORS")
