"""SkySense++ HR + abs-diff UPerNet config for LEVIR-CD."""

default_scope = "opencd"
custom_imports = dict(imports=["sspp_opencd"], allow_failed_imports=False)

data_root = "data/LEVIR-CD"
pretrained = "pretrain/skysensepp_release_hr.pth"

input_size = (128, 128)
num_classes = 2
batch_size = 8
max_epochs = 20
base_lr = 5e-4

hr_channels = [352, 704, 1408, 2816]
norm_cfg = dict(type="SyncBN", requires_grad=True)

model_wrapper_cfg = dict(
    type="MMDistributedDataParallel",
    find_unused_parameters=True,
)
find_unused_parameters = True

data_preprocessor = dict(
    type="DualInputSegDataPreProcessor",
    mean=[123.675, 116.28, 103.53] * 2,
    std=[58.395, 57.12, 57.375] * 2,
    bgr_to_rgb=True,
    size=input_size,
    pad_val=0,
    seg_pad_val=255,
    test_cfg=dict(size=input_size),
)

model = dict(
    type="SkySensePPAbsDiffEncoderDecoder",
    data_preprocessor=data_preprocessor,
    backbone_inchannels=3,
    backbone=dict(
        type="SkySensePPHR",
        in_channels=3,
        patch_size=4,
        window_size=8,
        out_indices=(0, 1, 2, 3),
        init_cfg=dict(type="Pretrained", checkpoint=pretrained),
    ),
    decode_head=dict(
        type="mmseg.UPerHead",
        in_channels=hr_channels,
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=512,
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        ignore_index=255,
        loss_decode=dict(
            type="mmseg.CrossEntropyLoss",
            use_sigmoid=False,
            loss_weight=1.0,
        ),
    ),
    train_cfg=dict(),
    test_cfg=dict(mode="whole"),
)

dataset_type = "LEVIRCDDataset"

train_pipeline = [
    dict(type="MultiImgLoadImageFromFile"),
    dict(type="MultiImgLoadAnnotations"),
    dict(type="MultiImgRandomFlip", prob=0.5, direction="horizontal"),
    dict(type="MultiImgRandomFlip", prob=0.5, direction="vertical"),
    dict(type="MultiImgPackSegInputs"),
]

test_pipeline = [
    dict(type="MultiImgLoadImageFromFile"),
    dict(type="MultiImgLoadAnnotations"),
    dict(type="MultiImgPackSegInputs"),
]

train_dataloader = dict(
    batch_size=batch_size,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=True),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(
            img_path_from="train_sliced/A",
            img_path_to="train_sliced/B",
            seg_map_path="train_sliced/label",
        ),
        pipeline=train_pipeline,
    ),
)

val_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(
            img_path_from="val_sliced/A",
            img_path_to="val_sliced/B",
            seg_map_path="val_sliced/label",
        ),
        pipeline=test_pipeline,
    ),
)

test_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(
            img_path_from="test_sliced/A",
            img_path_to="test_sliced/B",
            seg_map_path="test_sliced/label",
        ),
        pipeline=test_pipeline,
    ),
)

val_evaluator = dict(type="mmseg.IoUMetric", iou_metrics=["mFscore", "mIoU"])
test_evaluator = val_evaluator

optim_wrapper = dict(
    type="OptimWrapper",
    optimizer=dict(
        type="AdamW",
        lr=base_lr,
        betas=(0.9, 0.999),
        weight_decay=0.01,
    ),
    clip_grad=dict(max_norm=1.0, norm_type=2),
)

param_scheduler = [
    dict(
        type="LinearLR",
        start_factor=1e-6,
        by_epoch=False,
        begin=0,
        end=1500,
    ),
    dict(
        type="PolyLR",
        eta_min=0.0,
        power=1.0,
        begin=0,
        end=max_epochs,
        by_epoch=True,
    ),
]

train_cfg = dict(
    type="EpochBasedTrainLoop",
    max_epochs=max_epochs,
    val_interval=1,
)
val_cfg = dict(type="ValLoop")
test_cfg = dict(type="TestLoop")

default_hooks = dict(
    timer=dict(type="IterTimerHook"),
    logger=dict(type="LoggerHook", interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type="ParamSchedulerHook"),
    checkpoint=dict(
        type="CheckpointHook",
        by_epoch=True,
        interval=1,
        max_keep_ckpts=3,
        save_best="mIoU",
        rule="greater",
    ),
    sampler_seed=dict(type="DistSamplerSeedHook"),
    visualization=dict(
        type="CDVisualizationHook",
        interval=1,
        img_shape=(*input_size, 3),
    ),
)

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method="fork", opencv_num_threads=0),
    dist_cfg=dict(backend="nccl"),
)

vis_backends = [dict(type="LocalVisBackend")]
visualizer = dict(
    type="CDLocalVisualizer",
    vis_backends=vis_backends,
    name="visualizer",
)

log_processor = dict(type="LogProcessor", window_size=50, by_epoch=True)
log_level = "INFO"
load_from = None
resume = False

tta_model = dict(type="mmseg.SegTTAModel")

auto_scale_lr = dict(enable=False, base_batch_size=batch_size)
