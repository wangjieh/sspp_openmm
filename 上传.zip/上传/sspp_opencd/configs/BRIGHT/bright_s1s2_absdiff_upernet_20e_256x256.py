"""SkySense++ S1/S2 abs-diff UPerNet config for BRIGHT."""

default_scope = "opencd"
custom_imports = dict(imports=["sspp_opencd"], allow_failed_imports=False)

data_root = "data/BRIGHT"
pretrained_s2 = "pretrain/skysensepp_release_s2.pth"
pretrained_s1 = "pretrain/skysensepp_release_s1.pth"

input_size = (256, 256)
num_classes = 2
batch_size = 8
max_epochs = 20
base_lr = 5e-4
ignore_index = 255
in_channels = 12
feature_channels = [1024, 1024, 1024, 1024]
norm_cfg = dict(type="SyncBN", requires_grad=True)

opt_mean = (88.674, 85.027, 76.558)
opt_std = (67.434, 58.458, 53.972)
sar_mean = (56.630, )
sar_std = (45.191, )

model_wrapper_cfg = dict(
    type="MMDistributedDataParallel",
    find_unused_parameters=True,
)
find_unused_parameters = True

data_preprocessor = dict(
    type="DualInputSegDataPreProcessor",
    mean=[0.0] * in_channels,
    std=[1.0] * in_channels,
    bgr_to_rgb=False,
    size=input_size,
    pad_val=0,
    seg_pad_val=ignore_index,
    test_cfg=dict(size=input_size),
)

model = dict(
    type="SkySensePPDualBranchAbsDiffEncoderDecoder",
    data_preprocessor=data_preprocessor,
    input_split=(10, 2),
    pyramid_scales=(1.0, 0.5, 0.25, 0.125),
    opt_backbone=dict(
        type="SkySensePPS2",
        in_channels=10,
        img_size=16,
        patch_size=4,
        out_indices=(5, 11, 17, 23),
        with_cp=False,
        init_cfg=dict(type="Pretrained", checkpoint=pretrained_s2),
    ),
    sar_backbone=dict(
        type="SkySensePPS1",
        in_channels=2,
        img_size=16,
        patch_size=4,
        out_indices=(5, 11, 17, 23),
        with_cp=False,
        init_cfg=dict(type="Pretrained", checkpoint=pretrained_s1),
    ),
    decode_head=dict(
        type="mmseg.UPerHead",
        in_channels=feature_channels,
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=512,
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        ignore_index=ignore_index,
        loss_decode=dict(
            type="mmseg.CrossEntropyLoss",
            use_sigmoid=False,
            loss_weight=1.0,
        ),
    ),
    train_cfg=dict(),
    test_cfg=dict(mode="whole"),
)

dataset_type = "BRIGHTDataset"

pack_meta_keys = (
    "img_path",
    "seg_map_path",
    "ori_shape",
    "img_shape",
    "pad_shape",
    "scale_factor",
    "flip",
    "flip_direction",
    "bright_opt_present_channels",
    "bright_sar_present_channels",
    "bright_present_channels",
)

load_bright = dict(
    type="BRIGHTLoadRasterio",
    opt_channel_indices=(2, 1, 0),
    sar_channel_indices=(0, ),
    output_channels=(10, 2),
    opt_mean=opt_mean,
    opt_std=opt_std,
    sar_mean=sar_mean,
    sar_std=sar_std,
)

train_pipeline = [
    load_bright,
    dict(type="MultiImgRandomFlip", prob=0.5, direction="horizontal"),
    dict(type="MultiImgRandomFlip", prob=0.5, direction="vertical"),
    dict(type="MultiImgPackSegInputs", meta_keys=pack_meta_keys),
]

test_pipeline = [
    load_bright,
    dict(type="MultiImgPackSegInputs", meta_keys=pack_meta_keys),
]

train_dataloader = dict(
    batch_size=batch_size,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=True),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(
            img_path_from="train/pre-event",
            img_path_to="train/post-event",
            seg_map_path="train/target",
        ),
        pipeline=train_pipeline,
    ),
)

val_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(
            img_path_from="val/pre-event",
            img_path_to="val/post-event",
            seg_map_path="val/target",
        ),
        pipeline=test_pipeline,
    ),
)

test_dataloader = val_dataloader

val_evaluator = dict(type="mmseg.IoUMetric", iou_metrics=["mFscore", "mIoU"])
test_evaluator = val_evaluator

optim_wrapper = dict(
    type="OptimWrapper",
    optimizer=dict(
        type="AdamW",
        lr=base_lr,
        betas=(0.9, 0.999),
        weight_decay=0.01,
    ),
    clip_grad=dict(max_norm=1.0, norm_type=2),
)

param_scheduler = [
    dict(
        type="LinearLR",
        start_factor=1e-6,
        by_epoch=False,
        begin=0,
        end=1500,
    ),
    dict(
        type="PolyLR",
        eta_min=0.0,
        power=1.0,
        begin=0,
        end=max_epochs,
        by_epoch=True,
    ),
]

train_cfg = dict(
    type="EpochBasedTrainLoop",
    max_epochs=max_epochs,
    val_interval=1,
)
val_cfg = dict(type="ValLoop")
test_cfg = dict(type="TestLoop")

default_hooks = dict(
    timer=dict(type="IterTimerHook"),
    logger=dict(type="LoggerHook", interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type="ParamSchedulerHook"),
    checkpoint=dict(
        type="CheckpointHook",
        by_epoch=True,
        interval=1,
        max_keep_ckpts=3,
        save_best="mIoU",
        rule="greater",
    ),
    sampler_seed=dict(type="DistSamplerSeedHook"),
    visualization=dict(
        type="CDVisualizationHook",
        interval=1,
        img_shape=(*input_size, 3),
    ),
)

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method="fork", opencv_num_threads=0),
    dist_cfg=dict(backend="nccl"),
)

vis_backends = [dict(type="LocalVisBackend")]
visualizer = dict(
    type="CDLocalVisualizer",
    vis_backends=vis_backends,
    name="visualizer",
)

log_processor = dict(type="LogProcessor", window_size=50, by_epoch=True)
log_level = "INFO"
load_from = None
resume = False

tta_model = dict(type="mmseg.SegTTAModel")

auto_scale_lr = dict(enable=False, base_batch_size=batch_size)
