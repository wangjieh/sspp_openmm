"""BRIGHT rasterio loading and SkySense++ channel mapping transforms."""

from __future__ import annotations

from ..._registry import TRANSFORMS

try:
    import numpy as np
except ImportError as exc:  # pragma: no cover
    np = None
    _NUMPY_IMPORT_ERROR = exc
else:
    _NUMPY_IMPORT_ERROR = None

try:
    import rasterio
except ImportError as exc:  # pragma: no cover
    rasterio = None
    _RASTERIO_IMPORT_ERROR = exc
else:
    _RASTERIO_IMPORT_ERROR = None

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Fallback base class with MMEngine-like call behavior."""

        def __call__(self, results):
            return self.transform(results)


DEFAULT_OPT_MEAN = (88.674, 85.027, 76.558)
DEFAULT_OPT_STD = (67.434, 58.458, 53.972)
DEFAULT_SAR_MEAN = (56.630, )
DEFAULT_SAR_STD = (45.191, )


def _require_numpy():
    if np is None:
        raise ImportError(
            "BRIGHT transforms require numpy. The import error was: "
            f"{_NUMPY_IMPORT_ERROR!r}")


def _require_rasterio():
    if rasterio is None:
        raise ImportError(
            "BRIGHT transforms require rasterio. The import error was: "
            f"{_RASTERIO_IMPORT_ERROR!r}")


def _read_raster(path):
    _require_rasterio()
    with rasterio.open(path) as dataset:
        return dataset.read()


@TRANSFORMS.register_module()
class BRIGHTLoadRasterio(BaseTransform):
    """Load BRIGHT optical/SAR TIFFs and map them to S2/S1 slots.

    ``results["img"]`` is a two-item list. The first image has 10
    Sentinel-2-compatible channels and the second has 2 Sentinel-1-compatible
    channels; Open-CD's ``MultiImgPackSegInputs`` concatenates them to 12
    channels before the model sees them.
    """

    def __init__(self,
                 opt_channel_indices=(2, 1, 0),
                 sar_channel_indices=(0, ),
                 output_channels=(10, 2),
                 opt_mean=DEFAULT_OPT_MEAN,
                 opt_std=DEFAULT_OPT_STD,
                 sar_mean=DEFAULT_SAR_MEAN,
                 sar_std=DEFAULT_SAR_STD):
        self.opt_channel_indices = tuple(int(index)
                                         for index in opt_channel_indices)
        self.sar_channel_indices = tuple(int(index)
                                         for index in sar_channel_indices)
        self.output_channels = tuple(int(value) for value in output_channels)
        if len(self.output_channels) != 2:
            raise ValueError("output_channels must be (opt_channels, sar_channels).")
        self.opt_mean = tuple(float(value) for value in opt_mean)
        self.opt_std = tuple(float(value) for value in opt_std)
        self.sar_mean = tuple(float(value) for value in sar_mean)
        self.sar_std = tuple(float(value) for value in sar_std)

    def transform(self, results):
        _require_numpy()

        opt_path, sar_path = results["img_path"]
        opt = _read_raster(opt_path)
        sar = _read_raster(sar_path)
        h, w = opt.shape[1:]
        opt_image = np.zeros(
            (h, w, self.output_channels[0]), dtype=np.float32)
        sar_image = np.zeros(
            (h, w, self.output_channels[1]), dtype=np.float32)

        for source_index, target_index in enumerate(self.opt_channel_indices):
            band = opt[source_index].astype(np.float32)
            opt_image[..., target_index] = (
                band - self.opt_mean[source_index]) / self.opt_std[source_index]

        for source_index, target_index in enumerate(self.sar_channel_indices):
            band = sar[source_index].astype(np.float32)
            sar_image[..., target_index] = (
                band - self.sar_mean[source_index]) / self.sar_std[source_index]

        results["img"] = [opt_image, sar_image]
        results["img_shape"] = opt_image.shape[:2]
        results["ori_shape"] = opt_image.shape[:2]
        results["bright_opt_present_channels"] = self.opt_channel_indices
        results["bright_sar_present_channels"] = self.sar_channel_indices
        results["bright_present_channels"] = (
            self.opt_channel_indices
            + tuple(self.output_channels[0] + index
                    for index in self.sar_channel_indices))

        if "seg_map_path" in results:
            label = _read_raster(results["seg_map_path"])[0]
            results["gt_seg_map"] = np.where(label > 0, 1, 0).astype(np.uint8)
            results.setdefault("seg_fields", []).append("gt_seg_map")

        return results


__all__ = ["BRIGHTLoadRasterio"]
