"""BRIGHT optical-SAR change detection dataset."""

from __future__ import annotations

from .._registry import DATASETS


_IMPORT_ERROR = None

try:
    import os.path as osp
    from pathlib import PurePath

    import mmengine
    from mmengine import fileio
    from opencd.datasets.basecddataset import _BaseCDDataset
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    _BaseCDDataset = object


def _missing_dependency_message() -> str:
    return (
        "BRIGHTDataset requires Open-CD and MMEngine to be installed and "
        f"importable. The current import error was: {_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @DATASETS.register_module()
    class BRIGHTDataset(_BaseCDDataset):
        """Placeholder used when Open-CD is unavailable."""

        METAINFO = dict(
            classes=("unchanged", "changed"),
            palette=[[0, 0, 0], [255, 255, 255]],
        )

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    def _read_split_basenames(path, backend_args=None):
        lines = mmengine.list_from_file(path, backend_args=backend_args)
        return tuple(line.strip() for line in lines if line.strip())


    def _stem(path):
        return PurePath(path).stem


    @DATASETS.register_module()
    class BRIGHTDataset(_BaseCDDataset):
        """BRIGHT binary optical-SAR change detection dataset.

        Split files list base scene names. A sliced sample belongs to a split
        when the pre-event optical TIFF stem contains one of those base names.
        """

        METAINFO = dict(
            classes=("unchanged", "changed"),
            palette=[[0, 0, 0], [255, 255, 255]],
        )

        def __init__(self,
                     img_suffix=".tif",
                     seg_map_suffix=".tif",
                     format_seg_map=None,
                     **kwargs):
            super().__init__(
                img_suffix=img_suffix,
                seg_map_suffix=seg_map_suffix,
                format_seg_map=format_seg_map,
                **kwargs)

        def load_data_list(self):
            """Load optical/SAR/target triplets from the current split folder."""
            data_list = []
            opt_dir = self.data_prefix.get("img_path_from", None)
            sar_dir = self.data_prefix.get("img_path_to", None)
            ann_dir = self.data_prefix.get("seg_map_path", None)
            if opt_dir is None or sar_dir is None or ann_dir is None:
                raise ValueError(
                    "BRIGHTDataset requires data_prefix keys: img_path_from, "
                    "img_path_to, and seg_map_path.")

            if self.ann_file:
                if not osp.isfile(self.ann_file):
                    raise ValueError(
                        "BRIGHTDataset ann_file must point to a split txt.")
                split_basenames = _read_split_basenames(
                    self.ann_file, backend_args=self.backend_args)
                if not split_basenames:
                    raise ValueError(f"Empty BRIGHT split file: {self.ann_file}")

                def name_filter(stem):
                    return any(base_name in stem
                               for base_name in split_basenames)

            else:

                def name_filter(stem):
                    return True

            sar_files = self._list_files(sar_dir)
            ann_files = self._list_files(ann_dir)
            sar_by_name = {name: name for name in sar_files}
            ann_by_name = {name: name for name in ann_files}

            for opt_name in self._list_files(opt_dir):
                stem = _stem(opt_name)
                if not name_filter(stem):
                    continue

                sar_name = self._match_counterpart(
                    opt_name, sar_by_name, sar_files, "post-event SAR")
                ann_name = self._match_counterpart(
                    opt_name, ann_by_name, ann_files, "target")
                data_info = dict(
                    img_path=[
                        osp.join(opt_dir, opt_name),
                        osp.join(sar_dir, sar_name),
                    ],
                    seg_map_path=osp.join(ann_dir, ann_name),
                    label_map=self.label_map,
                    format_seg_map=self.format_seg_map,
                    reduce_zero_label=self.reduce_zero_label,
                    seg_fields=[],
                )
                data_list.append(data_info)

            return sorted(data_list, key=lambda item: item["img_path"][0])

        def _list_files(self, directory):
            return sorted(
                fileio.list_dir_or_file(
                    dir_path=directory,
                    list_dir=False,
                    suffix=self.img_suffix,
                    recursive=True,
                    backend_args=self.backend_args))

        def _match_counterpart(self, opt_name, exact_map, candidates, role):
            if opt_name in exact_map:
                return exact_map[opt_name]

            opt_stem = _stem(opt_name)
            matches = [
                candidate for candidate in candidates
                if _stem(candidate) == opt_stem
                or opt_stem in _stem(candidate)
                or _stem(candidate) in opt_stem
            ]
            if len(matches) == 1:
                return matches[0]
            if not matches:
                raise FileNotFoundError(
                    f"Cannot find BRIGHT {role} counterpart for {opt_name}.")
            raise ValueError(
                f"Found multiple BRIGHT {role} counterparts for {opt_name}: "
                f"{matches}")


__all__ = ["BRIGHTDataset"]
