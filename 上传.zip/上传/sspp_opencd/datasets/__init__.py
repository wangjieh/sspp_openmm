"""Datasets for the SkySense++ Open-CD plugin."""

from .levir_cd_dataset import LEVIRCDDataset

__all__ = ["LEVIRCDDataset"]
