"""DIOR-R dataset wrapper for SkySense++ rotated detection experiments."""

from __future__ import annotations

from .._registry import DATASETS


_IMPORT_ERROR = None

try:
    from mmrotate.datasets.dota import DOTADataset
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    DOTADataset = object


DIORR_CLASSES = (
    "airplane",
    "airport",
    "baseballfield",
    "basketballcourt",
    "bridge",
    "chimney",
    "dam",
    "Expressway-Service-area",
    "Expressway-toll-station",
    "golffield",
    "groundtrackfield",
    "harbor",
    "overpass",
    "ship",
    "stadium",
    "storagetank",
    "tenniscourt",
    "trainstation",
    "vehicle",
    "windmill",
)


def _make_palette(num_classes: int):
    return [
        ((37 * i) % 255, (17 * i + 89) % 255, (29 * i + 151) % 255)
        for i in range(num_classes)
    ]


def _missing_dependency_message() -> str:
    return (
        "DIORRDataset requires MMRotate to be installed and importable. "
        f"The current import error was: {_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @DATASETS.register_module()
    class DIORRDataset(DOTADataset):
        """Placeholder used when MMRotate is unavailable."""

        METAINFO = dict(
            classes=DIORR_CLASSES,
            palette=_make_palette(len(DIORR_CLASSES)),
        )

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    @DATASETS.register_module()
    class DIORRDataset(DOTADataset):
        """DIOR-R dataset in DOTA rotated-box txt format."""

        METAINFO = dict(
            classes=DIORR_CLASSES,
            palette=_make_palette(len(DIORR_CLASSES)),
        )

        def __init__(self, diff_thr=100, img_suffix="jpg", **kwargs):
            super().__init__(
                diff_thr=diff_thr,
                img_suffix=img_suffix,
                **kwargs,
            )


__all__ = ["DIORRDataset", "DIORR_CLASSES"]
