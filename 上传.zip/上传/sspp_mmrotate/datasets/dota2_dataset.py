"""DOTA2.0 dataset wrapper for SkySense++ rotated detection experiments."""

from __future__ import annotations

from .._registry import DATASETS


_IMPORT_ERROR = None

try:
    from mmrotate.datasets.dota import DOTADataset
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    DOTADataset = object


DOTA2_CLASSES = (
    "airport",
    "baseball-diamond",
    "basketball-court",
    "bridge",
    "container-crane",
    "ground-track-field",
    "harbor",
    "helicopter",
    "helipad",
    "large-vehicle",
    "plane",
    "roundabout",
    "ship",
    "small-vehicle",
    "soccer-ball-field",
    "storage-tank",
    "swimming-pool",
    "tennis-court",
)


def _make_palette(num_classes: int):
    return [
        ((37 * i) % 255, (17 * i + 89) % 255, (29 * i + 151) % 255)
        for i in range(num_classes)
    ]


def _missing_dependency_message() -> str:
    return (
        "DOTA2Dataset requires MMRotate to be installed and importable. "
        f"The current import error was: {_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @DATASETS.register_module()
    class DOTA2Dataset(DOTADataset):
        """Placeholder used when MMRotate is unavailable."""

        METAINFO = dict(
            classes=DOTA2_CLASSES,
            palette=_make_palette(len(DOTA2_CLASSES)),
        )

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    @DATASETS.register_module()
    class DOTA2Dataset(DOTADataset):
        """DOTA2.0 dataset in DOTA rotated-box txt format."""

        METAINFO = dict(
            classes=DOTA2_CLASSES,
            palette=_make_palette(len(DOTA2_CLASSES)),
        )

        def __init__(self, diff_thr=100, img_suffix="png", **kwargs):
            super().__init__(
                diff_thr=diff_thr,
                img_suffix=img_suffix,
                **kwargs,
            )


__all__ = ["DOTA2Dataset", "DOTA2_CLASSES"]
