"""Datasets and transforms for the SkySense++ MMRotate plugin."""

from .dior_r_dataset import DIORRDataset
from .dota2_dataset import DOTA2Dataset
from .transforms import *  # noqa: F401,F403

__all__ = ["DIORRDataset", "DOTA2Dataset"]
