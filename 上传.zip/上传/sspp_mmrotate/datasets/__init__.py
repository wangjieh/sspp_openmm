"""Datasets and transforms for the SkySense++ MMRotate plugin."""

from .dior_r_dataset import DIORRDataset
from .transforms import *  # noqa: F401,F403

__all__ = ["DIORRDataset"]
