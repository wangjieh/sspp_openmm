# Dataset Extensions

Place MMRotate dataset classes, transforms, and dataset-specific config
fragments here when a downstream dataset needs custom loading logic.

