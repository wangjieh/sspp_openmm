"""Detector registrations for SkySense++ MMRotate."""

from .rhino import RHINO
from .rotated_deformable_detr import RotatedDeformableDETR

__all__ = ["RotatedDeformableDETR", "RHINO"]
