"""Layer registrations for SkySense++ MMRotate."""

from .transformer import *  # noqa: F401,F403
