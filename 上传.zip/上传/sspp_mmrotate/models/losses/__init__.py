"""Loss registrations for SkySense++ MMRotate."""

from .gaussian_dist_loss import GDLoss

__all__ = ["GDLoss"]
