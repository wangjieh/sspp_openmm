"""Task-module registrations for SkySense++ MMRotate."""

from .assigners import *  # noqa: F401,F403
