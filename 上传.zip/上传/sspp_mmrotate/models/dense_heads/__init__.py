"""Dense head registrations for SkySense++ MMRotate."""

from .rhino_head import RHINOHead
from .rhino_ph_head import RHINOPositiveHungarianHead
from .rhino_phc_head import RHINOPositiveHungarianClassificationHead
from .rotated_deformable_detr_head import RotatedDeformableDETRHead
from .rotated_detr_head import RotatedDETRHead

__all__ = [
    "RotatedDETRHead",
    "RotatedDeformableDETRHead",
    "RHINOHead",
    "RHINOPositiveHungarianHead",
    "RHINOPositiveHungarianClassificationHead",
]
