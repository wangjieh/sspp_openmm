"""Test-dev inference config for SkySense++ HR Oriented R-CNN on DOTA2.0."""

import os.path as osp
import sys

_base_ = "./dota2_hr_oriented_rcnn_20e_800x800.py"

repo_root = osp.abspath(osp.join(osp.dirname(__file__), "../../.."))
if repo_root not in sys.path:
    sys.path.insert(0, repo_root)

data_root = osp.join(repo_root, "data-root")
work_dir = osp.join(
    repo_root, "work_dirs", "dota2_hr_oriented_rcnn_20e_800x800_testdev")
submission_prefix = osp.join(work_dir, "Task1")

backend_args = None
input_size = (800, 800)
dataset_type = "DOTA2Dataset"
pretrained = None
model = dict(backbone=dict(init_cfg=None))

test_pipeline = [
    dict(type="mmdet.LoadImageFromFile", backend_args=backend_args),
    dict(type="mmdet.Resize", scale=input_size, keep_ratio=True),
    dict(
        type="mmdet.PackDetInputs",
        meta_keys=("img_id", "img_path", "ori_shape", "img_shape",
                   "scale_factor"),
    ),
]

test_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    drop_last=False,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file="",
        data_prefix=dict(img_path=""),
        test_mode=True,
        pipeline=test_pipeline,
    ),
)

test_evaluator = dict(
    type="DOTAMetric",
    format_only=True,
    merge_patches=True,
    predict_box_type="rbox",
    outfile_prefix=submission_prefix,
)

test_cfg = dict(type="TestLoop")
load_from = None
resume = False
