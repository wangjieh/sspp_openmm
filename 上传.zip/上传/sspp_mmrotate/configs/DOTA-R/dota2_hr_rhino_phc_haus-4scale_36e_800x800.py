"""SkySense++ HR RHINO-PHC config for DOTA2.0 rotated detection."""

default_scope = "mmrotate"
custom_imports = dict(imports=["sspp_mmrotate"], allow_failed_imports=False)

data_root = "data/DOTA2.0"
pretrained = "pretrain/skysensepp_release_hr.pth"
dataset_type = "DOTA2Dataset"
backend_args = None

input_size = (800, 800)
num_classes = 18
batch_size = 2
max_epochs = 36
base_lr = 1e-4
angle_cfg = dict(width_longer=True, start_angle=0)

hr_channels = [352, 704, 1408, 2816]
rhino_channels = 256

model_wrapper_cfg = dict(
    type="MMDistributedDataParallel",
    find_unused_parameters=True,
)
find_unused_parameters = True

costs = [
    dict(type="mmdet.FocalLossCost", weight=2.0),
    dict(type="HausdorffCost", weight=5.0, box_format="xywha"),
    dict(
        type="GDCost",
        loss_type="kld",
        fun="log1p",
        tau=1,
        sqrt=False,
        weight=5.0,
    ),
]

model = dict(
    type="RHINO",
    version="v2",
    num_queries=900,
    with_box_refine=True,
    as_two_stage=True,
    data_preprocessor=dict(
        type="mmdet.DetDataPreprocessor",
        mean=[123.675, 116.28, 103.53],
        std=[58.395, 57.12, 57.375],
        bgr_to_rgb=True,
        pad_size_divisor=1,
        boxtype2tensor=False,
        batch_augments=None,
    ),
    backbone=dict(
        type="SkySensePPHR",
        in_channels=3,
        patch_size=4,
        window_size=8,
        drop_path_rate=0.3,
        out_indices=(0, 1, 2, 3),
        init_cfg=dict(type="Pretrained", checkpoint=pretrained),
    ),
    neck=dict(
        type="mmdet.ChannelMapper",
        in_channels=hr_channels,
        kernel_size=1,
        out_channels=rhino_channels,
        act_cfg=None,
        norm_cfg=dict(type="GN", num_groups=32),
        num_outs=4,
    ),
    encoder=dict(
        num_layers=6,
        layer_cfg=dict(
            self_attn_cfg=dict(
                embed_dims=rhino_channels,
                num_levels=4,
                dropout=0.0,
            ),
            ffn_cfg=dict(
                embed_dims=rhino_channels,
                feedforward_channels=2048,
                ffn_drop=0.0,
            ),
        ),
    ),
    decoder=dict(
        num_layers=6,
        return_intermediate=True,
        layer_cfg=dict(
            self_attn_cfg=dict(
                embed_dims=rhino_channels,
                num_heads=8,
                dropout=0.0,
            ),
            cross_attn_cfg=dict(
                embed_dims=rhino_channels,
                num_levels=4,
                dropout=0.0,
            ),
            ffn_cfg=dict(
                embed_dims=rhino_channels,
                feedforward_channels=2048,
                ffn_drop=0.0,
            ),
        ),
        post_norm_cfg=None,
    ),
    positional_encoding=dict(
        num_feats=128,
        normalize=True,
        offset=0.0,
        temperature=20,
    ),
    bbox_head=dict(
        type="RHINOPositiveHungarianClassificationHead",
        num_classes=num_classes,
        angle_cfg=angle_cfg,
        sync_cls_avg_factor=True,
        loss_cls=dict(
            type="mmdet.FocalLoss",
            use_sigmoid=True,
            gamma=2.0,
            alpha=0.25,
            loss_weight=1.0,
        ),
        loss_bbox=dict(type="mmdet.L1Loss", loss_weight=5.0),
        loss_iou=dict(
            type="GDLoss",
            loss_type="kld",
            fun="log1p",
            tau=1,
            sqrt=False,
            loss_weight=5.0,
        ),
    ),
    dn_cfg=dict(
        label_noise_scale=0.5,
        box_noise_scale=1.0,
        group_cfg=dict(
            dynamic=True,
            num_groups=None,
            num_dn_queries=100,
            max_num_groups=30,
        ),
    ),
    train_cfg=dict(
        assigner=dict(
            type="mmdet.HungarianAssigner",
            match_costs=costs,
        ),
        dn_assigner=dict(
            type="DNGroupHungarianAssigner",
            match_costs=costs,
        ),
    ),
    test_cfg=dict(max_per_img=500),
)

train_pipeline = [
    dict(type="mmdet.LoadImageFromFile", backend_args=backend_args),
    dict(type="mmdet.LoadAnnotations", with_bbox=True, box_type="qbox"),
    dict(type="ConvertBoxType", box_type_mapping=dict(gt_bboxes="rbox")),
    dict(type="mmdet.Resize", scale=input_size, keep_ratio=True),
    dict(
        type="mmdet.RandomFlip",
        prob=0.75,
        direction=["horizontal", "vertical", "diagonal"],
    ),
    dict(type="FilterSmallRotatedBoxes", min_size=1.0, log_interval=50),
    dict(type="mmdet.PackDetInputs"),
]

val_pipeline = [
    dict(type="mmdet.LoadImageFromFile", backend_args=backend_args),
    dict(type="mmdet.Resize", scale=input_size, keep_ratio=True),
    dict(type="mmdet.LoadAnnotations", with_bbox=True, box_type="qbox"),
    dict(type="ConvertBoxType", box_type_mapping=dict(gt_bboxes="rbox")),
    dict(type="FilterSmallRotatedBoxes", min_size=1.0, log_interval=200),
    dict(
        type="mmdet.PackDetInputs",
        meta_keys=("img_id", "img_path", "ori_shape", "img_shape",
                   "scale_factor"),
    ),
]

test_pipeline = val_pipeline

train_dataloader = dict(
    batch_size=batch_size,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=True),
    batch_sampler=None,
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file="trainval/labelTxt_obb",
        data_prefix=dict(img_path="trainval/images"),
        filter_cfg=dict(filter_empty_gt=True),
        pipeline=train_pipeline,
    ),
)

val_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    drop_last=False,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file="val/labelTxt_obb",
        data_prefix=dict(img_path="val/images"),
        test_mode=True,
        pipeline=val_pipeline,
    ),
)

test_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    drop_last=False,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file="val/labelTxt_obb",
        data_prefix=dict(img_path="val/images"),
        test_mode=True,
        pipeline=test_pipeline,
    ),
)

val_evaluator = dict(type="DOTAMetric", metric="mAP")
test_evaluator = val_evaluator

optim_wrapper = dict(
    type="OptimWrapper",
    constructor="SwinV2LayerDecayOptimizerConstructor",
    optimizer=dict(
        type="AdamW",
        lr=base_lr,
        betas=(0.9, 0.999),
        weight_decay=0.05,
    ),
    paramwise_cfg=dict(
        num_layers=24,
        layer_decay_rate=0.9,
        depths=(2, 2, 18, 2),
        custom_keys=dict(
            bias=dict(decay_multi=0.0),
            absolute_pos_embed=dict(decay_mult=0.0),
            norm=dict(decay_mult=0.0),
        ),
    ),
    clip_grad=dict(max_norm=35, norm_type=2),
)

param_scheduler = [
    dict(
        type="LinearLR",
        start_factor=1e-3,
        by_epoch=False,
        begin=0,
        end=1000,
    ),
    dict(
        type="MultiStepLR",
        begin=0,
        end=max_epochs,
        by_epoch=True,
        milestones=[27, 33],
        gamma=0.1,
    ),
]

train_cfg = dict(type="EpochBasedTrainLoop", max_epochs=max_epochs,
                 val_interval=6)
val_cfg = dict(type="ValLoop")
test_cfg = dict(type="TestLoop")

default_hooks = dict(
    timer=dict(type="IterTimerHook"),
    logger=dict(type="LoggerHook", interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type="ParamSchedulerHook"),
    checkpoint=dict(
        type="CheckpointHook",
        interval=1,
        by_epoch=True,
        max_keep_ckpts=3,
        save_best="dota/mAP",
        rule="greater",
    ),
    sampler_seed=dict(type="DistSamplerSeedHook"),
    visualization=dict(type="mmdet.DetVisualizationHook"),
)

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method="fork", opencv_num_threads=0),
    dist_cfg=dict(backend="nccl"),
)

vis_backends = [dict(type="LocalVisBackend")]
visualizer = dict(
    type="RotLocalVisualizer",
    vis_backends=vis_backends,
    name="visualizer",
)

log_processor = dict(type="LogProcessor", window_size=50, by_epoch=True)
log_level = "INFO"
load_from = None
resume = False
randomness = dict(seed=0, deterministic=False)

auto_scale_lr = dict(enable=False, base_batch_size=batch_size)
