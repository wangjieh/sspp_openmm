"""DIOR horizontal-box dataset for SkySense++ detection experiments.

The annotation files are usually stored in ``hbb_dota_cleaned`` and follow
a DOTA-like HBB txt format:
``xmin ymin xmax ymax class difficulty``.
"""

from __future__ import annotations

import glob
import os.path as osp

from .._registry import DATASETS


_IMPORT_ERROR = None

try:
    from mmdet.datasets import BaseDetDataset
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    BaseDetDataset = object


DIOR_CLASSES = (
    "airplane",
    "airport",
    "baseballfield",
    "basketballcourt",
    "bridge",
    "chimney",
    "dam",
    "Expressway-Service-area",
    "Expressway-toll-station",
    "golffield",
    "groundtrackfield",
    "harbor",
    "overpass",
    "ship",
    "stadium",
    "storagetank",
    "tenniscourt",
    "trainstation",
    "vehicle",
    "windmill",
)


def _make_palette(num_classes: int):
    return [
        ((37 * i) % 255, (17 * i + 89) % 255, (29 * i + 151) % 255)
        for i in range(num_classes)
    ]


def _missing_dependency_message() -> str:
    return (
        "DIORHBBDetectionDataset requires MMDetection to be installed and "
        f"importable. The current import error was: {_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @DATASETS.register_module()
    class DIORHBBDetectionDataset(BaseDetDataset):
        """Placeholder used when MMDetection is unavailable."""

        METAINFO = dict(
            classes=DIOR_CLASSES,
            palette=_make_palette(len(DIOR_CLASSES)),
            dataset_type="DIOR",
        )

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    @DATASETS.register_module()
    class DIORHBBDetectionDataset(BaseDetDataset):
        """DIOR dataset in DOTA-like horizontal-box txt format."""

        METAINFO = dict(
            classes=DIOR_CLASSES,
            palette=_make_palette(len(DIOR_CLASSES)),
            dataset_type="DIOR",
        )

        def __init__(self, diff_thr=100, img_suffix="jpg", **kwargs):
            self.diff_thr = int(diff_thr)
            self.img_suffix = img_suffix.lstrip(".")
            super().__init__(**kwargs)

        def load_data_list(self):
            ann_dir = self._resolve_path(self.ann_file)
            img_dir = self._resolve_path(self.data_prefix.get("img_path", ""))

            if ann_dir and osp.isdir(ann_dir):
                ann_files = sorted(glob.glob(osp.join(ann_dir, "*.txt")))
                return [
                    self._load_one_annotation(ann_file, img_dir)
                    for ann_file in ann_files
                ]

            image_pattern = osp.join(img_dir, f"*.{self.img_suffix}")
            return [
                self._empty_image_info(img_path)
                for img_path in sorted(glob.glob(image_pattern))
            ]

        def _load_one_annotation(self, ann_file, img_dir):
            img_id = osp.splitext(osp.basename(ann_file))[0]
            img_path = osp.join(img_dir, f"{img_id}.{self.img_suffix}")
            instances = []
            label_map = {
                class_name: index
                for index, class_name in enumerate(self.metainfo["classes"])
            }

            with open(ann_file, "r", encoding="utf-8") as file:
                for line_number, line in enumerate(file, start=1):
                    line = line.strip()
                    if not line:
                        continue
                    instances.append(
                        self._parse_txt_line(line, line_number, ann_file,
                                             label_map))

            return dict(
                img_id=img_id,
                img_path=img_path,
                instances=instances,
            )

        def _parse_txt_line(self, line, line_number, ann_file, label_map):
            parts = line.split()
            if len(parts) != 6:
                raise ValueError(
                    f"{ann_file}:{line_number} expects 6 fields "
                    "'xmin ymin xmax ymax class difficulty', "
                    f"but got {len(parts)}: {line!r}")

            xmin, ymin, xmax, ymax = (float(value) for value in parts[:4])
            class_name = parts[4]
            if class_name not in label_map:
                raise KeyError(
                    f"{ann_file}:{line_number} unknown DIOR class "
                    f"{class_name!r}.")

            difficulty = int(float(parts[5]))
            return dict(
                bbox=[xmin, ymin, xmax, ymax],
                bbox_label=label_map[class_name],
                ignore_flag=1 if difficulty > self.diff_thr else 0,
            )

        def _empty_image_info(self, img_path):
            img_id = osp.splitext(osp.basename(img_path))[0]
            return dict(
                img_id=img_id,
                img_path=img_path,
                instances=[],
            )

        def _resolve_path(self, path):
            if not path or osp.isabs(path):
                return path
            data_root = self.data_root or ""
            if not data_root:
                return path
            norm_path = osp.normpath(path)
            norm_root = osp.normpath(data_root)
            if norm_path == norm_root or norm_path.startswith(norm_root + osp.sep):
                return path
            return osp.join(data_root, path)

        def filter_data(self):
            if self.test_mode:
                return self.data_list
            filter_cfg = self.filter_cfg or {}
            filter_empty_gt = filter_cfg.get("filter_empty_gt", False)
            if not filter_empty_gt:
                return self.data_list
            return [
                data_info for data_info in self.data_list
                if any(not item.get("ignore_flag", 0)
                       for item in data_info.get("instances", []))
            ]


__all__ = ["DIORHBBDetectionDataset", "DIOR_CLASSES"]
