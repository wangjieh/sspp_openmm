"""Pazhou competition COCO-format horizontal bbox dataset."""

from __future__ import annotations

import glob
import os.path as osp

from .._registry import DATASETS

try:
    from mmdet.datasets import CocoDataset
except ImportError:  # pragma: no cover - local machines may lack MMDetection.
    CocoDataset = object


@DATASETS.register_module()
class PazhouCocoDataset(CocoDataset):
    """COCO HBB dataset for the Pazhou road-junction competition."""

    METAINFO = {
        "classes": (
            "Four-way junction",
            "Three-way junction",
            "Roundabout",
        ),
        "palette": [
            (220, 20, 60),
            (0, 128, 255),
            (0, 180, 120),
        ],
        "dataset_type": "pazhou_competition",
    }

    def __init__(self, img_suffix="png", **kwargs):
        self.img_suffix = img_suffix.lstrip(".")
        super().__init__(**kwargs)

    def load_data_list(self):
        ann_file = getattr(self, "ann_file", "")
        if ann_file:
            resolved_ann = self._resolve_path(ann_file)
            if resolved_ann and osp.isfile(resolved_ann):
                original_ann = self.ann_file
                self.ann_file = resolved_ann
                try:
                    return super().load_data_list()
                finally:
                    self.ann_file = original_ann

        img_dir = self._resolve_path(self.data_prefix.get("img", ""))
        if not img_dir:
            raise ValueError(
                "PazhouCocoDataset requires data_prefix['img'] when "
                "ann_file is empty.")
        pattern = osp.join(img_dir, f"*.{self.img_suffix}")
        data_list = []
        for img_path in sorted(glob.glob(pattern)):
            img_id = osp.splitext(osp.basename(img_path))[0]
            data_list.append(
                dict(img_id=img_id, img_path=img_path, instances=[]))
        return data_list

    def filter_data(self):
        if getattr(self, "test_mode", False):
            return self.data_list
        filter_cfg = self.filter_cfg or {}
        if not filter_cfg.get("filter_empty_gt", False):
            return self.data_list
        return super().filter_data()

    def _resolve_path(self, path):
        if not path:
            return path
        if osp.isabs(path):
            return path
        data_root = getattr(self, "data_root", None)
        if data_root:
            return osp.join(data_root, path)
        return path


__all__ = ["PazhouCocoDataset"]
