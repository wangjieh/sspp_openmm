"""Filter invalid horizontal boxes after geometric augmentation."""

from __future__ import annotations

import logging
from collections import Counter

import numpy as np

from ..._registry import TRANSFORMS


LOGGER = logging.getLogger(__name__)

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Small fallback that mimics the transform call protocol."""

        def __call__(self, results):
            return self.transform(results)


try:
    from mmengine.logging import print_log
except ImportError:  # pragma: no cover - local machines may lack MMEngine.
    print_log = None


@TRANSFORMS.register_module()
class FilterInvalidHorizontalBoxes(BaseTransform):
    """Remove invalid HBB annotations without dropping the whole image.

    A box is invalid when its width or height is smaller than ``min_size`` or
    any coordinate falls outside the image after augmentation.
    """

    def __init__(self, min_size=1.0, log_interval=50):
        self.min_size = float(min_size)
        self.log_interval = int(log_interval)
        self.num_calls = 0
        self.total_seen = 0
        self.total_filtered = 0
        self.reason_counts = Counter()

    def transform(self, results):
        if "gt_bboxes" not in results:
            return results

        bboxes = results["gt_bboxes"]
        num_boxes = len(bboxes)
        if num_boxes == 0:
            return results

        box_array = self._to_numpy(bboxes)
        valid_mask, reason_counts = self._find_valid_boxes(
            box_array, results["img_shape"])
        filtered_count = int(num_boxes - valid_mask.sum())

        if filtered_count:
            self._filter_instance_fields(results, valid_mask)

        self._update_and_log(results, num_boxes, filtered_count, reason_counts)
        return results

    def _find_valid_boxes(self, box_array, img_shape):
        if box_array.shape[-1] != 4:
            raise ValueError(
                "FilterInvalidHorizontalBoxes expects gt_bboxes with 4 "
                f"values per box, got shape {box_array.shape}.")

        img_h, img_w = img_shape[:2]
        x1, y1, x2, y2 = box_array.T
        widths = x2 - x1
        heights = y2 - y1

        too_small = (widths < self.min_size) | (heights < self.min_size)
        out_of_bounds = (
            (x1 < 0)
            | (y1 < 0)
            | (x2 > img_w)
            | (y2 > img_h)
        )
        reason_counts = Counter(
            too_small=int(too_small.sum()),
            out_of_bounds=int(out_of_bounds.sum()),
        )
        valid_mask = ~(too_small | out_of_bounds)
        return valid_mask, reason_counts

    @staticmethod
    def _to_numpy(bboxes):
        data = getattr(bboxes, "tensor", bboxes)
        if hasattr(data, "detach"):
            data = data.detach().cpu().numpy()
        return np.asarray(data, dtype=np.float32)

    @staticmethod
    def _slice_like(value, valid_mask):
        if isinstance(value, list):
            keep_indices = np.nonzero(valid_mask)[0]
            return [value[index] for index in keep_indices]
        if hasattr(value, "tensor") and hasattr(value.tensor, "new_tensor"):
            mask = value.tensor.new_tensor(valid_mask).bool()
            return value[mask]
        return value[valid_mask]

    def _filter_instance_fields(self, results, valid_mask):
        results["gt_bboxes"] = self._slice_like(results["gt_bboxes"], valid_mask)
        for key in ("gt_bboxes_labels", "gt_ignore_flags", "gt_masks"):
            if key not in results:
                continue
            try:
                if len(results[key]) == len(valid_mask):
                    results[key] = self._slice_like(results[key], valid_mask)
            except TypeError:
                continue

    def _update_and_log(self, results, num_boxes, filtered_count, reason_counts):
        self.num_calls += 1
        self.total_seen += int(num_boxes)
        self.total_filtered += int(filtered_count)
        self.reason_counts.update(reason_counts)

        if not filtered_count:
            return
        should_log = (
            self.log_interval > 0 and self.num_calls % self.log_interval == 0)
        should_log = should_log or filtered_count == num_boxes
        if not should_log:
            return

        message = (
            "FilterInvalidHorizontalBoxes: "
            f"filtered={filtered_count}/{num_boxes}, "
            f"total_filtered={self.total_filtered}/{self.total_seen}, "
            f"too_small={self.reason_counts['too_small']}, "
            f"out_of_bounds={self.reason_counts['out_of_bounds']}, "
            f"img_path={results.get('img_path', '<unknown>')}")
        LOGGER.info(message)
        if print_log is not None:
            print_log(message, logger="current", level=logging.INFO)

    def __repr__(self):
        return (
            f"{self.__class__.__name__}(min_size={self.min_size}, "
            f"log_interval={self.log_interval})")


@TRANSFORMS.register_module()
class FilterSmallHorizontalBoxes(FilterInvalidHorizontalBoxes):
    """Remove too-small HBB annotations without checking image bounds."""

    def _find_valid_boxes(self, box_array, img_shape=None):
        if box_array.shape[-1] != 4:
            raise ValueError(
                "FilterSmallHorizontalBoxes expects gt_bboxes with 4 "
                f"values per box, got shape {box_array.shape}.")

        x1, y1, x2, y2 = box_array.T
        widths = x2 - x1
        heights = y2 - y1

        too_small = (widths < self.min_size) | (heights < self.min_size)
        reason_counts = Counter(
            too_small=int(too_small.sum()),
            out_of_bounds=0,
        )
        valid_mask = ~too_small
        return valid_mask, reason_counts


__all__ = ["FilterInvalidHorizontalBoxes", "FilterSmallHorizontalBoxes"]
