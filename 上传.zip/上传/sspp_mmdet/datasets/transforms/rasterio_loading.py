"""Rasterio image loading transforms for MMDetection datasets."""

from __future__ import annotations

import numpy as np

from ..._registry import TRANSFORMS

try:
    from mmcv.transforms import BaseTransform
except ImportError:  # pragma: no cover - local machines may lack MMCV.

    class BaseTransform:
        """Small fallback that mimics the transform call protocol."""

        def __call__(self, results):
            return self.transform(results)


try:
    import rasterio
except ImportError:  # pragma: no cover - rasterio is only required at runtime.
    rasterio = None


@TRANSFORMS.register_module()
class LoadImageFromRasterio(BaseTransform):
    """Load an image with rasterio and return an HWC array.

    This loader only reads pixel values and ignores geospatial metadata.
    """

    def __init__(self, to_float32=False, selected_channels=None):
        self.to_float32 = bool(to_float32)
        self.selected_channels = selected_channels

    def transform(self, results):
        if rasterio is None:
            raise ImportError(
                "LoadImageFromRasterio requires rasterio to be installed.")

        img_path = results["img_path"]
        with rasterio.open(img_path) as dataset:
            if self.selected_channels is None:
                data = dataset.read()
            else:
                data = dataset.read(self.selected_channels)

        img = self._to_hwc(data)
        if self.to_float32:
            img = img.astype(np.float32)

        results["img"] = np.ascontiguousarray(img)
        results["img_shape"] = img.shape[:2]
        results["ori_shape"] = img.shape[:2]
        return results

    @staticmethod
    def _to_hwc(data):
        data = np.asarray(data)
        if data.ndim == 2:
            return data
        if data.ndim != 3:
            raise ValueError(
                "LoadImageFromRasterio expects a 2D or 3D image array, "
                f"got shape {data.shape}.")
        if data.shape[0] == 1:
            return data[0]
        return np.transpose(data, (1, 2, 0))

    def __repr__(self):
        return (
            f"{self.__class__.__name__}(to_float32={self.to_float32}, "
            f"selected_channels={self.selected_channels})")


__all__ = ["LoadImageFromRasterio"]
