"""SkySense++ layer-wise learning-rate decay for OpenMMLab."""

from __future__ import annotations

from collections import OrderedDict

from ..._registry import OPTIM_WRAPPER_CONSTRUCTORS


_IMPORT_ERROR = None

try:
    from mmengine.optim import DefaultOptimWrapperConstructor
except ImportError as exc:  # pragma: no cover - local machines may lack OpenMMLab.
    _IMPORT_ERROR = exc


DEPTHS = {
    "tiny": [2, 2, 6, 2],
    "small": [2, 2, 18, 2],
    "base": [2, 2, 18, 2],
    "large": [2, 2, 18, 2],
    "huge": [2, 2, 18, 2],
    "giant": [2, 2, 42, 4],
}


def _strip_backbone_prefix(name: str) -> str:
    for prefix in ("module.", "backbone."):
        if name.startswith(prefix):
            name = name[len(prefix):]
    return name


def get_vit_layer_id(name: str, num_layers: int) -> int:
    name = _strip_backbone_prefix(name)
    if name in ("cls_token", "mask_token", "pos_embed"):
        return 0
    if name.startswith("patch_embed"):
        return 0
    if name.startswith("layers."):
        return int(name.split(".")[1]) + 1
    return num_layers + 1


def get_swin_layer_id(name: str, depths: list[int]) -> int:
    name = _strip_backbone_prefix(name)
    if name in ("mask_token", "pos_embed"):
        return 0
    if name.startswith("patch_embed"):
        return 0
    if name.startswith("stages."):
        stage_id = int(name.split(".")[1])
        if ".blocks." in name:
            block_id = int(name.split(".")[3])
        else:
            block_id = depths[stage_id] - 1
        return sum(depths[:stage_id]) + block_id + 1
    return sum(depths) + 1


def get_swin_v2_layer_id(name: str,
                         num_max_layer: int,
                         depths: list[int],
                         layer_sep=None) -> int:
    """Match the original SkySense SwinV2 layer-id assignment.

    ``num_max_layer`` follows SkySense's convention and is usually
    ``num_layers + 2``. Parameters outside the backbone are placed in the last
    layer so they keep the base learning rate.
    """
    del layer_sep
    if name.startswith("module."):
        name = name[len("module."):]
    if name.startswith("backbone."):
        name = name[len("backbone."):]

    if name == "absolute_pos_embed":
        return 0
    if name.startswith("patch_embed"):
        return 0
    if name.startswith("stages.") and ".blocks." in name:
        stage_id = int(name.split(".")[1])
        block_id = int(name.split(".")[3])
        layer_id = sum(depths[:stage_id]) + block_id if stage_id > 0 else block_id
        return layer_id + 1
    if name.startswith("stages.") and ".downsample" in name:
        stage_id = int(name.split(".")[1])
        layer_id = sum(depths[:stage_id])
        return layer_id + 1
    return num_max_layer - 1


def get_layer_id(name: str, net_type: str, num_layers: int,
                 depths: list[int]) -> int:
    if net_type == "vit":
        return get_vit_layer_id(name, num_layers)
    if net_type == "swin":
        return get_swin_layer_id(name, depths)
    raise ValueError(f"Unsupported SkySense++ net_type: {net_type}")


def should_skip_weight_decay(name: str, param) -> bool:
    no_decay_keywords = (
        "absolute_pos_embed",
        "relative_position_bias_table",
        "relative_coords_table",
        "pos_embed",
        "norm",
        "bias",
    )
    return param.ndim == 1 or any(keyword in name for keyword in no_decay_keywords)


if _IMPORT_ERROR is not None:

    @OPTIM_WRAPPER_CONSTRUCTORS.register_module()
    class SkySensePPLayerDecayOptimWrapperConstructor:
        """Placeholder used when MMEngine is unavailable."""

        def __init__(self, *args, **kwargs):
            raise ImportError(
                "SkySensePPLayerDecayOptimWrapperConstructor requires "
                f"MMEngine. The current import error was: {_IMPORT_ERROR!r}")

    @OPTIM_WRAPPER_CONSTRUCTORS.register_module()
    class SwinV2LayerDecayOptimizerConstructor:
        """Placeholder used when MMEngine is unavailable."""

        def __init__(self, *args, **kwargs):
            raise ImportError(
                "SwinV2LayerDecayOptimizerConstructor requires "
                f"MMEngine. The current import error was: {_IMPORT_ERROR!r}")

else:

    @OPTIM_WRAPPER_CONSTRUCTORS.register_module()
    class SkySensePPLayerDecayOptimWrapperConstructor(
            DefaultOptimWrapperConstructor):
        """OpenMMLab optimizer constructor matching SkySense++ pretraining."""

        def __init__(self, optim_wrapper_cfg, paramwise_cfg=None):
            super().__init__(optim_wrapper_cfg, paramwise_cfg)
            paramwise_cfg = paramwise_cfg or {}
            self.net_type = paramwise_cfg.get(
                "net_type", paramwise_cfg.get("backbone_type", "vit")).lower()
            self.arch = paramwise_cfg.get("arch", "huge").lower()
            self.num_layers = int(paramwise_cfg.get("num_layers", 24))
            self.layer_decay_rate = float(
                paramwise_cfg.get(
                    "layer_decay_rate",
                    paramwise_cfg.get("layer_decay",
                                      paramwise_cfg.get("decay_rate", 1.0))))
            self.frozen_blocks = int(paramwise_cfg.get("frozen_blocks", 0))
            if not 0 < self.layer_decay_rate <= 1:
                raise ValueError("layer_decay_rate must be in (0, 1].")
            if self.net_type not in ("vit", "swin"):
                raise ValueError("net_type must be either 'vit' or 'swin'.")
            if self.arch not in DEPTHS:
                raise ValueError(f"Unsupported SkySense++ arch: {self.arch}.")

            self.depths = DEPTHS[self.arch]
            effective_layers = (
                self.num_layers if self.net_type == "vit" else sum(self.depths))
            self.layer_scales = [
                self.layer_decay_rate**(effective_layers + 1 - i)
                for i in range(effective_layers + 2)
            ]

        def add_params(self, params, module, **kwargs):
            groups = OrderedDict()
            base_weight_decay = self.base_wd

            for name, param in module.named_parameters():
                stripped_name = _strip_backbone_prefix(name)
                if not param.requires_grad:
                    continue
                if self._should_freeze(stripped_name):
                    param.requires_grad = False
                    continue

                layer_id = (
                    get_layer_id(stripped_name, self.net_type, self.num_layers,
                                 self.depths)
                    if self.layer_decay_rate < 1 else 0)
                scale = self.layer_scales[layer_id]
                decay_type = "no_decay" if should_skip_weight_decay(
                    stripped_name, param) else "decay"
                weight_decay = 0. if decay_type == "no_decay" else base_weight_decay
                group_name = f"layer_{layer_id}_{decay_type}"

                if group_name not in groups:
                    groups[group_name] = {
                        "params": [],
                        "param_names": [],
                        "group_name": group_name,
                        "lr_scale": scale,
                        "lr": scale * self.base_lr,
                        "weight_decay": weight_decay,
                    }
                groups[group_name]["params"].append(param)
                groups[group_name]["param_names"].append(name)

            params.extend(groups.values())

        def _should_freeze(self, name: str) -> bool:
            if self.frozen_blocks < 1:
                return False
            if name.startswith("patch_embed"):
                return True
            if self.net_type == "vit" and name.startswith("layers."):
                return get_vit_layer_id(name, self.num_layers) <= self.frozen_blocks
            if self.net_type == "swin" and name.startswith("stages."):
                return get_swin_layer_id(name, self.depths) <= self.frozen_blocks
            return False


    @OPTIM_WRAPPER_CONSTRUCTORS.register_module()
    class SwinV2LayerDecayOptimizerConstructor(DefaultOptimWrapperConstructor):
        """SkySense SwinV2 layer-wise LR decay constructor for MMEngine.

        This mirrors SkySense's MMDetection 2.x
        ``SwinV2LayerDecayOptimizerConstructor`` while using the MMEngine
        optimizer-wrapper constructor API. It is intentionally implemented
        inside ``sspp_mmdet`` so MMDetection changes do not affect other
        downstream plugins.
        """

        def __init__(self, optim_wrapper_cfg, paramwise_cfg=None):
            super().__init__(optim_wrapper_cfg, paramwise_cfg)
            paramwise_cfg = paramwise_cfg or {}
            self.num_max_layer = int(paramwise_cfg.get("num_layers", 24)) + 2
            depths = paramwise_cfg.get(
                "depths",
                DEPTHS[paramwise_cfg.get("arch", "huge").lower()],
            )
            self.depths = tuple(int(depth) for depth in depths)
            self.layer_sep = paramwise_cfg.get("layer_sep", None)
            self.layer_decay_rate = float(
                paramwise_cfg.get("layer_decay_rate", 1.0))
            self.custom_keys = paramwise_cfg.get("custom_keys", {})
            if not 0 < self.layer_decay_rate <= 1:
                raise ValueError("layer_decay_rate must be in (0, 1].")

        def add_params(self, params, module, **kwargs):
            groups = OrderedDict()
            custom_keys = sorted(self.custom_keys.keys())

            for name, param in module.named_parameters():
                if not param.requires_grad:
                    continue

                decay_type = (
                    "no_decay"
                    if self._is_no_decay(name, param) else "decay")
                weight_decay = 0. if decay_type == "no_decay" else self.base_wd
                layer_id = get_swin_v2_layer_id(
                    name, self.num_max_layer, self.depths, self.layer_sep)
                lr_mult = 1.0
                group_name = f"layer_{layer_id}_{decay_type}"

                for key in custom_keys:
                    if key in name:
                        key_cfg = self.custom_keys[key]
                        lr_mult = key_cfg.get("lr_mult", lr_mult)
                        if "decay_mult" in key_cfg:
                            weight_decay = self.base_wd * key_cfg["decay_mult"]
                        elif "decay_multi" in key_cfg:
                            weight_decay = self.base_wd * key_cfg["decay_multi"]
                        group_name = f"{group_name}_{key}"
                        break

                if group_name not in groups:
                    scale = self.layer_decay_rate**(
                        self.num_max_layer - layer_id - 1)
                    groups[group_name] = {
                        "params": [],
                        "param_names": [],
                        "group_name": group_name,
                        "lr_scale": scale,
                        "lr": scale * self.base_lr * lr_mult,
                        "weight_decay": weight_decay,
                    }
                groups[group_name]["params"].append(param)
                groups[group_name]["param_names"].append(name)

            params.extend(groups.values())

        @staticmethod
        def _is_no_decay(name, param) -> bool:
            return (
                param.ndim == 1
                or name.endswith(".bias")
                or "pos_embed" in name
                or "cls_token" in name)


__all__ = [
    "SkySensePPLayerDecayOptimWrapperConstructor",
    "SwinV2LayerDecayOptimizerConstructor",
    "get_layer_id",
    "get_vit_layer_id",
    "get_swin_layer_id",
    "get_swin_v2_layer_id",
]
