"""SkySense++ HR Faster R-CNN config with SwinV2 layer decay for DIOR."""

default_scope = "mmdet"
custom_imports = dict(imports=["sspp_mmdet"], allow_failed_imports=False)

data_root = "data/DIOR"
pretrained = "pretrain/skysensepp_release_hr.pth"
dataset_type = "DIORHBBDetectionDataset"
backend_args = None

input_size = (800, 800)
num_classes = 20
batch_size = 4
max_epochs = 20
base_lr = 1e-4

classes = (
    "airplane",
    "airport",
    "baseballfield",
    "basketballcourt",
    "bridge",
    "chimney",
    "dam",
    "Expressway-Service-area",
    "Expressway-toll-station",
    "golffield",
    "groundtrackfield",
    "harbor",
    "overpass",
    "ship",
    "stadium",
    "storagetank",
    "tenniscourt",
    "trainstation",
    "vehicle",
    "windmill",
)
palette = [
    ((37 * i) % 255, (17 * i + 89) % 255, (29 * i + 151) % 255)
    for i in range(num_classes)
]
metainfo = dict(classes=classes, palette=palette, dataset_type="DIOR")

hr_channels = [352, 704, 1408, 2816]
fpn_channels = 256

model_wrapper_cfg = dict(
    type="MMDistributedDataParallel",
    find_unused_parameters=True,
)
find_unused_parameters = True

model = dict(
    type="mmdet.FasterRCNN",
    data_preprocessor=dict(
        type="mmdet.DetDataPreprocessor",
        mean=[123.675, 116.28, 103.53],
        std=[58.395, 57.12, 57.375],
        bgr_to_rgb=True,
        pad_size_divisor=32,
        batch_augments=None,
    ),
    backbone=dict(
        type="SkySensePPHR",
        in_channels=3,
        patch_size=4,
        window_size=8,
        drop_path_rate=0.3,
        out_indices=(0, 1, 2, 3),
        init_cfg=dict(type="Pretrained", checkpoint=pretrained),
    ),
    neck=dict(
        type="mmdet.FPN",
        in_channels=hr_channels,
        out_channels=fpn_channels,
        num_outs=5,
    ),
    rpn_head=dict(
        type="mmdet.RPNHead",
        in_channels=fpn_channels,
        feat_channels=fpn_channels,
        anchor_generator=dict(
            type="mmdet.AnchorGenerator",
            scales=[8],
            ratios=[0.5, 1.0, 2.0],
            strides=[4, 8, 16, 32, 64],
        ),
        bbox_coder=dict(
            type="mmdet.DeltaXYWHBBoxCoder",
            target_means=[0.0, 0.0, 0.0, 0.0],
            target_stds=[1.0, 1.0, 1.0, 1.0],
        ),
        loss_cls=dict(
            type="mmdet.CrossEntropyLoss",
            use_sigmoid=True,
            loss_weight=1.0,
        ),
        loss_bbox=dict(
            type="mmdet.SmoothL1Loss",
            beta=0.1111111111111111,
            loss_weight=1.0,
        ),
    ),
    roi_head=dict(
        type="mmdet.StandardRoIHead",
        bbox_roi_extractor=dict(
            type="mmdet.SingleRoIExtractor",
            roi_layer=dict(type="RoIAlign", output_size=7, sampling_ratio=0),
            out_channels=fpn_channels,
            featmap_strides=[4, 8, 16, 32],
        ),
        bbox_head=dict(
            type="mmdet.Shared2FCBBoxHead",
            in_channels=fpn_channels,
            fc_out_channels=1024,
            roi_feat_size=7,
            num_classes=num_classes,
            bbox_coder=dict(
                type="mmdet.DeltaXYWHBBoxCoder",
                target_means=[0.0, 0.0, 0.0, 0.0],
                target_stds=[0.1, 0.1, 0.2, 0.2],
            ),
            reg_class_agnostic=False,
            loss_cls=dict(
                type="mmdet.CrossEntropyLoss",
                use_sigmoid=False,
                loss_weight=1.0,
            ),
            loss_bbox=dict(
                type="mmdet.SmoothL1Loss",
                beta=1.0,
                loss_weight=1.0,
            ),
        ),
    ),
    train_cfg=dict(
        rpn=dict(
            assigner=dict(
                type="mmdet.MaxIoUAssigner",
                pos_iou_thr=0.7,
                neg_iou_thr=0.3,
                min_pos_iou=0.3,
                match_low_quality=True,
                ignore_iof_thr=-1,
            ),
            sampler=dict(
                type="mmdet.RandomSampler",
                num=256,
                pos_fraction=0.5,
                neg_pos_ub=-1,
                add_gt_as_proposals=False,
            ),
            allowed_border=-1,
            pos_weight=-1,
            debug=False,
        ),
        rpn_proposal=dict(
            nms_pre=2000,
            max_per_img=1000,
            nms=dict(type="nms", iou_threshold=0.7),
            min_bbox_size=0,
        ),
        rcnn=dict(
            assigner=dict(
                type="mmdet.MaxIoUAssigner",
                pos_iou_thr=0.5,
                neg_iou_thr=0.5,
                min_pos_iou=0.5,
                match_low_quality=False,
                ignore_iof_thr=-1,
            ),
            sampler=dict(
                type="mmdet.RandomSampler",
                num=512,
                pos_fraction=0.25,
                neg_pos_ub=-1,
                add_gt_as_proposals=True,
            ),
            pos_weight=-1,
            debug=False,
        ),
    ),
    test_cfg=dict(
        rpn=dict(
            nms_pre=1000,
            max_per_img=1000,
            nms=dict(type="nms", iou_threshold=0.7),
            min_bbox_size=0,
        ),
        rcnn=dict(
            score_thr=0.05,
            nms=dict(type="nms", iou_threshold=0.5),
            max_per_img=100,
        ),
    ),
)

train_pipeline = [
    dict(type="mmdet.LoadImageFromFile", backend_args=backend_args),
    dict(type="mmdet.LoadAnnotations", with_bbox=True),
    dict(type="mmdet.Resize", scale=input_size, keep_ratio=True),
    dict(type="mmdet.RandomFlip", prob=0.5, direction="horizontal"),
    dict(type="FilterInvalidHorizontalBoxes", min_size=1.0, log_interval=50),
    dict(type="mmdet.PackDetInputs"),
]

val_pipeline = [
    dict(type="mmdet.LoadImageFromFile", backend_args=backend_args),
    dict(type="mmdet.Resize", scale=input_size, keep_ratio=True),
    dict(type="mmdet.LoadAnnotations", with_bbox=True),
    dict(type="FilterInvalidHorizontalBoxes", min_size=1.0, log_interval=200),
    dict(
        type="mmdet.PackDetInputs",
        meta_keys=("img_id", "img_path", "ori_shape", "img_shape",
                   "scale_factor"),
    ),
]

test_pipeline = val_pipeline

train_dataloader = dict(
    batch_size=batch_size,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=True),
    batch_sampler=None,
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file="trainval/hbb_dota_cleaned",
        data_prefix=dict(img_path="trainval/images"),
        metainfo=metainfo,
        filter_cfg=dict(filter_empty_gt=True),
        pipeline=train_pipeline,
    ),
)

val_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    drop_last=False,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file="test/hbb_dota_cleaned",
        data_prefix=dict(img_path="test/images"),
        metainfo=metainfo,
        test_mode=True,
        pipeline=val_pipeline,
    ),
)

test_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    drop_last=False,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        ann_file="test/hbb_dota_cleaned",
        data_prefix=dict(img_path="test/images"),
        metainfo=metainfo,
        test_mode=True,
        pipeline=test_pipeline,
    ),
)

val_evaluator = dict(
    type="mmdet.VOCMetric",
    metric="mAP",
    iou_thrs=0.5,
    eval_mode="11points",
    prefix="dior",
)
test_evaluator = val_evaluator

optim_wrapper = dict(
    type="OptimWrapper",
    constructor="SwinV2LayerDecayOptimizerConstructor",
    optimizer=dict(
        type="AdamW",
        lr=base_lr,
        betas=(0.9, 0.999),
        weight_decay=0.05,
    ),
    paramwise_cfg=dict(
        num_layers=24,
        layer_decay_rate=0.9,
        depths=(2, 2, 18, 2),
        custom_keys=dict(
            bias=dict(decay_multi=0.0),
            absolute_pos_embed=dict(decay_mult=0.0),
            norm=dict(decay_mult=0.0),
        ),
    ),
    clip_grad=dict(max_norm=35, norm_type=2),
)

param_scheduler = [
    dict(
        type="LinearLR",
        start_factor=1e-3,
        by_epoch=False,
        begin=0,
        end=1000,
    ),
    dict(
        type="MultiStepLR",
        begin=0,
        end=max_epochs,
        by_epoch=True,
        milestones=[12, 16],
        gamma=0.1,
    ),
]

train_cfg = dict(type="EpochBasedTrainLoop", max_epochs=max_epochs, val_interval=1)
val_cfg = dict(type="ValLoop")
test_cfg = dict(type="TestLoop")

default_hooks = dict(
    timer=dict(type="IterTimerHook"),
    logger=dict(type="LoggerHook", interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type="ParamSchedulerHook"),
    checkpoint=dict(
        type="CheckpointHook",
        interval=1,
        by_epoch=True,
        max_keep_ckpts=3,
        save_best="dior/mAP",
        rule="greater",
    ),
    sampler_seed=dict(type="DistSamplerSeedHook"),
    visualization=dict(type="mmdet.DetVisualizationHook"),
)

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method="fork", opencv_num_threads=0),
    dist_cfg=dict(backend="nccl"),
)

vis_backends = [dict(type="LocalVisBackend")]
visualizer = dict(
    type="mmdet.DetLocalVisualizer",
    vis_backends=vis_backends,
    name="visualizer",
)

log_processor = dict(type="LogProcessor", window_size=50, by_epoch=True)
log_level = "INFO"
load_from = None
resume = False
randomness = dict(seed=0, deterministic=False)

auto_scale_lr = dict(enable=False, base_batch_size=batch_size)
