custom_imports = dict(imports=["sspp_mmdet"], allow_failed_imports=False)

model = dict(
    backbone=dict(
        type="SkySensePPS2",
        init_cfg=dict(
            type="Pretrained",
            checkpoint="pretrain/skysensepp_release_s2.pth",
        ),
        out_indices=(-1, ),
    ),
)

optim_wrapper = dict(
    constructor="SkySensePPLayerDecayOptimWrapperConstructor",
    optimizer=dict(type="AdamW", lr=1e-4, weight_decay=0.05),
    paramwise_cfg=dict(
        net_type="vit",
        arch="large",
        num_layers=24,
        layer_decay_rate=0.85,
        frozen_blocks=0,
    ),
)

