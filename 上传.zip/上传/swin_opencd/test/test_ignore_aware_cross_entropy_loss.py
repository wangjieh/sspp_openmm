"""Tests for CAU_FLOOD's ignore-aware weighted cross-entropy plugin."""

from __future__ import annotations

import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TUNE03_CONFIG = (
    ROOT / "configs" / "CAU_FLOOD_finetune_configs" /
    "cau_flood_dual_swin_huge_upernet_tune03_input_norm_classweight_50e_256x256.py"
)

try:
    import torch
    import torch.nn.functional as F

    from swin_opencd.models.losses import IgnoreAwareCrossEntropyLoss
except ImportError:
    torch = None
    F = None
    IgnoreAwareCrossEntropyLoss = None


class TestIgnoreAwareCrossEntropyStatic(unittest.TestCase):

    def test_tune03_uses_ignore_aware_weighted_ce(self):
        text = TUNE03_CONFIG.read_text(encoding="utf-8")
        self.assertIn('type="IgnoreAwareCrossEntropyLoss"', text)
        self.assertIn("class_weight=[1.0, 1.25]", text)
        self.assertIn("ignore_index=255", text)

    def test_loss_is_exported_by_models_package(self):
        exports = (ROOT / "models" / "__init__.py").read_text(encoding="utf-8")
        loss_exports = (
            ROOT / "models" / "losses" / "__init__.py").read_text(encoding="utf-8")
        self.assertIn("from .losses import *", exports)
        self.assertIn("IgnoreAwareCrossEntropyLoss", loss_exports)


@unittest.skipIf(torch is None, "PyTorch is unavailable in this environment.")
class TestIgnoreAwareCrossEntropyRuntime(unittest.TestCase):

    def test_matches_native_weighted_ce_after_ignore_masking(self):
        logits = torch.tensor(
            [[[[2.0, -1.0], [0.2, 0.3]], [[-1.0, 2.0], [0.1, 0.6]]]],
            requires_grad=True,
        )
        labels = torch.tensor([[[0, 1], [255, 1]]])
        criterion = IgnoreAwareCrossEntropyLoss(
            class_weight=[1.0, 1.25], ignore_index=255)

        actual = criterion(logits, labels)
        valid = labels != 255
        expected = F.cross_entropy(
            logits.movedim(1, -1)[valid],
            labels[valid],
            weight=torch.tensor([1.0, 1.25]),
        )

        self.assertTrue(torch.allclose(actual, expected))
        actual.backward()
        self.assertTrue(torch.isfinite(logits.grad).all())

    def test_all_ignore_pixels_produce_a_differentiable_zero(self):
        logits = torch.randn(1, 2, 2, 2, requires_grad=True)
        labels = torch.full((1, 2, 2), 255, dtype=torch.long)
        loss = IgnoreAwareCrossEntropyLoss(
            class_weight=[1.0, 1.25], ignore_index=255)(logits, labels)

        self.assertEqual(loss.item(), 0.0)
        loss.backward()
        self.assertTrue(torch.equal(logits.grad, torch.zeros_like(logits.grad)))

    def test_non_ignore_label_outside_class_range_is_rejected(self):
        logits = torch.randn(1, 2, 1, 1)
        labels = torch.tensor([[[2]]])
        criterion = IgnoreAwareCrossEntropyLoss(
            class_weight=[1.0, 1.25], ignore_index=255)

        with self.assertRaisesRegex(ValueError, "outside"):
            criterion(logits, labels)


if __name__ == "__main__":
    unittest.main()
