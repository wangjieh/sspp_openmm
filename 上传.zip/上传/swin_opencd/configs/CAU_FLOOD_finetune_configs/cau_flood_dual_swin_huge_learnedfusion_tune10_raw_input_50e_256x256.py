"""T10: learnable optical--SAR feature fusion, based on the T01 baseline.

Only the four-scale feature fusion is changed.  The raw input, dual Swin-Huge
backbones, UPerHead, CE loss, optimizer, schedule, seed, checkpoint policy,
and mFscore early stopping are inherited from T01 unchanged.
"""

_base_ = [
    "./cau_flood_dual_swin_huge_upernet_tune01_mfscore_earlystop_50e_256x256.py"
]

# Import this new model directly.  The original absolute-difference model and
# all T01--T09 configurations remain untouched.
custom_imports = dict(
    imports=[
        "swin_opencd",
        "swin_opencd.hooks.save_raw_pred_hook",
        "swin_opencd.models.change_detectors.dual_swin_learnedfusion_upernet",
    ],
    allow_failed_imports=False,
)

work_dir = (
    "/mnt/htzzb2/EO_test/wj1/swin_work_dirs/cau_flood_finetune/"
    "cau_flood_dual_swin_huge_learnedfusion_tune10_raw_input_50e_256x256"
)

model = dict(
    type="DualSwinLearnedFusionUPerNet",
    # Keep the four output widths required by the inherited UPerHead.
    fusion_in_channels=[352, 704, 1408, 2816],
    # Compress each modality before concatenating optical, SAR, abs-diff, and
    # common-response features.  This avoids a prohibitively large 4C -> C
    # projection on the 2,816-channel final Swin stage.
    fusion_channels=256,
)

custom_hooks = [
    dict(
        type="SaveRawPredHook",
        output_dir=work_dir + "_infer",
        scale255=False,
    ),
]
