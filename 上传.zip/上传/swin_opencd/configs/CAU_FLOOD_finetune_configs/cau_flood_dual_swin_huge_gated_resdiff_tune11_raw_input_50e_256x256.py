"""T11: lightweight gated residual-difference fusion, based on T01.

The T01 absolute-difference pyramid remains the main feature path.  At each
Swin scale, a low-rank optical--SAR gate learns only a small residual
correction.  All training settings are inherited from T01 unchanged.
"""

_base_ = [
    "./cau_flood_dual_swin_huge_upernet_tune01_mfscore_earlystop_50e_256x256.py"
]

# Direct import registers only this new model.  Existing T01--T10 files are
# not changed and can continue to use their original registered modules.
custom_imports = dict(
    imports=[
        "swin_opencd",
        "swin_opencd.hooks.save_raw_pred_hooks",
        "swin_opencd.models.change_detectors.dual_swin_gated_resdiff_upernet",
    ],
    allow_failed_imports=False,
)

work_dir = (
    "/mnt/htzzb2/EO_test/wj1/swin_work_dirs/cau_flood_finetune/"
    "cau_flood_dual_swin_huge_gated_resdiff_tune11_raw_input_50e_256x256"
)

model = dict(
    type="DualSwinGatedResDiffUPerNet",
    residual_in_channels=[352, 704, 1408, 2816],
    # 128 creates about 2.2M new parameters, substantially fewer than the
    # previous 256-channel concatenation fusion experiment.
    residual_channels=128,
    # Near-baseline initialization with non-zero gradients for the new path.
    residual_scale_init=1e-3,
)

custom_hooks = [
    dict(
        type="SaveRawPredHook",
        output_dir=work_dir + "_infer",
        scale255=False,
    ),
]
