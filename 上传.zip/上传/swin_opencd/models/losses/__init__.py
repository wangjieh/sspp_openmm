"""Loss registrations for the Swin Open-CD plugin."""

try:
    from .ignore_aware_cross_entropy_loss import IgnoreAwareCrossEntropyLoss
except ModuleNotFoundError as exc:
    # Keep the root plugin importable for static checks on machines without
    # PyTorch. Training environments import and register the loss normally.
    if exc.name != "torch":
        raise
    __all__ = []
else:
    __all__ = ["IgnoreAwareCrossEntropyLoss"]
