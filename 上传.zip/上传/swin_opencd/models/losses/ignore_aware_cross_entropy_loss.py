"""Cross-entropy loss that safely ignores invalid segmentation pixels."""

from __future__ import annotations

from typing import Iterable, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..._registry import MODELS


@MODELS.register_module()
class IgnoreAwareCrossEntropyLoss(nn.Module):
    """Weighted cross-entropy that masks ``ignore_index`` before weighting.

    MMSegmentation 1.2.2 indexes class weights with every label while
    calculating its weighted-loss average. CAU_FLOOD uses ``255`` as the
    invalid-pixel label, so this module removes ignored labels before calling
    PyTorch's native weighted cross entropy.
    """

    def __init__(
        self,
        class_weight: Optional[Iterable[float]] = None,
        loss_weight: float = 1.0,
        ignore_index: int = 255,
        reduction: str = "mean",
        loss_name: str = "loss_ignore_aware_ce",
    ) -> None:
        super().__init__()
        if reduction not in {"none", "mean", "sum"}:
            raise ValueError(
                "reduction must be one of 'none', 'mean', or 'sum', "
                f"got {reduction!r}.")
        if class_weight is None:
            self.register_buffer("class_weight", None, persistent=False)
        else:
            class_weight_tensor = torch.as_tensor(
                list(class_weight), dtype=torch.float32)
            if class_weight_tensor.ndim != 1 or class_weight_tensor.numel() == 0:
                raise ValueError("class_weight must be a non-empty 1D sequence.")
            self.register_buffer(
                "class_weight", class_weight_tensor, persistent=False)
        self.loss_weight = float(loss_weight)
        self.ignore_index = int(ignore_index)
        self.reduction = reduction
        self._loss_name = str(loss_name)

    def forward(
        self,
        cls_score: torch.Tensor,
        label: torch.Tensor,
        weight: Optional[torch.Tensor] = None,
        avg_factor: Optional[float] = None,
        reduction_override: Optional[str] = None,
        ignore_index: Optional[int] = None,
        **kwargs,
    ) -> torch.Tensor:
        """Compute the loss using only labels in ``[0, num_classes)``."""
        del kwargs
        if cls_score.ndim < 2:
            raise ValueError(
                "cls_score must have shape (N, C, ...), "
                f"got {tuple(cls_score.shape)}.")
        if label.shape != (cls_score.shape[0], *cls_score.shape[2:]):
            raise ValueError(
                "label must have shape (N, ...) matching cls_score spatial "
                f"dimensions, got cls_score={tuple(cls_score.shape)} and "
                f"label={tuple(label.shape)}.")

        reduction = reduction_override or self.reduction
        if reduction not in {"none", "mean", "sum"}:
            raise ValueError(
                "reduction_override must be one of 'none', 'mean', or 'sum', "
                f"got {reduction!r}.")
        if weight is not None and weight.shape != label.shape:
            raise ValueError(
                "weight must have the same shape as label when provided, "
                f"got weight={tuple(weight.shape)} and label={tuple(label.shape)}.")

        active_ignore_index = (
            self.ignore_index if ignore_index is None else int(ignore_index))
        num_classes = cls_score.shape[1]
        if self.class_weight is not None and self.class_weight.numel() != num_classes:
            raise ValueError(
                "class_weight length must equal the logits class dimension, "
                f"got {self.class_weight.numel()} weights for {num_classes} classes.")

        label = label.long()
        valid_mask = label != active_ignore_index
        invalid_mask = valid_mask & ((label < 0) | (label >= num_classes))
        if bool(invalid_mask.any()):
            invalid_label = int(label[invalid_mask][0].item())
            raise ValueError(
                f"Found label {invalid_label} outside [0, {num_classes}) and "
                f"not equal to ignore_index={active_ignore_index}.")

        if not bool(valid_mask.any()):
            # Keep this rank in the DDP autograd graph when a batch is all nodata.
            return cls_score.sum() * 0.0

        valid_scores = cls_score.movedim(1, -1)[valid_mask]
        valid_labels = label[valid_mask]
        class_weight = (
            None if self.class_weight is None else self.class_weight.to(
                device=cls_score.device, dtype=cls_score.dtype))
        per_pixel_loss = F.cross_entropy(
            valid_scores,
            valid_labels,
            weight=class_weight,
            reduction="none",
        )
        if weight is not None:
            per_pixel_loss = per_pixel_loss * weight[valid_mask].to(
                device=per_pixel_loss.device, dtype=per_pixel_loss.dtype)

        if reduction == "none":
            loss = per_pixel_loss
        elif reduction == "sum":
            loss = per_pixel_loss.sum()
        elif avg_factor is not None:
            if avg_factor <= 0:
                raise ValueError(f"avg_factor must be positive, got {avg_factor}.")
            loss = per_pixel_loss.sum() / float(avg_factor)
        elif class_weight is None:
            loss = per_pixel_loss.mean()
        else:
            normalizer = class_weight[valid_labels].sum().clamp_min(
                torch.finfo(per_pixel_loss.dtype).eps)
            loss = per_pixel_loss.sum() / normalizer
        return self.loss_weight * loss

    @property
    def loss_name(self) -> str:
        """Return the loss key used by OpenMMLab's loss parser."""
        return self._loss_name
