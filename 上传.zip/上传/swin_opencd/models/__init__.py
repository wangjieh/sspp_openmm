"""Model registrations for the Swin Open-CD plugin."""

from .change_detectors import *  # noqa: F401,F403
from .losses import *  # noqa: F401,F403
