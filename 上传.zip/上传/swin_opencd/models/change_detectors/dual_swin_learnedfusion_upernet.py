"""Dual-Swin UPerNet with learnable optical--SAR feature fusion.

This module is deliberately separate from ``dual_swin_absdiff_upernet.py`` so
existing absolute-difference experiments and checkpoints remain unchanged.
"""

from __future__ import annotations

from ..._registry import MODELS
from .dual_swin_absdiff_upernet import DualSwinAbsDiffUPerNet

_IMPORT_ERROR = None

try:
    import torch
    from torch import nn
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    nn = None


def _missing_dependency_message() -> str:
    return (
        "DualSwinLearnedFusionUPerNet requires PyTorch and Open-CD to be "
        "installed and importable. The current import error was: "
        f"{_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @MODELS.register_module()
    class DualSwinLearnedFusionUPerNet(DualSwinAbsDiffUPerNet):
        """Placeholder used when PyTorch dependencies are unavailable."""

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    class _LearnedFusionBlock(nn.Module):
        """Fuse one optical/SAR feature pair while preserving output width."""

        def __init__(self, in_channels: int, fusion_channels: int):
            super().__init__()
            self.opt_projection = self._make_projection(
                in_channels, fusion_channels)
            self.sar_projection = self._make_projection(
                in_channels, fusion_channels)
            self.fuse_projection = nn.Sequential(
                nn.Conv2d(fusion_channels * 4, in_channels, 1, bias=False),
                nn.SyncBatchNorm(in_channels),
                nn.GELU(),
            )

        @staticmethod
        def _make_projection(in_channels: int, out_channels: int):
            return nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 1, bias=False),
                nn.SyncBatchNorm(out_channels),
                nn.GELU(),
            )

        def forward(self, opt_feat, sar_feat):
            opt_proj = self.opt_projection(opt_feat)
            sar_proj = self.sar_projection(sar_feat)
            abs_diff = torch.abs(sar_proj - opt_proj)
            common_response = sar_proj * opt_proj
            fusion_input = torch.cat(
                (opt_proj, sar_proj, abs_diff, common_response), dim=1)
            return self.fuse_projection(fusion_input)


    @MODELS.register_module()
    class DualSwinLearnedFusionUPerNet(DualSwinAbsDiffUPerNet):
        """Dual Swin branches fused by learned modality-aware projections.

        Each backbone feature pair is first compressed independently. Their
        projected optical, projected SAR, absolute-difference, and common
        response features are then fused back to the original channel count.
        The unchanged output channel counts keep the existing UPerHead intact.
        """

        def __init__(self,
                     fusion_in_channels,
                     fusion_channels=256,
                     **kwargs):
            super().__init__(**kwargs)
            self.fusion_in_channels = tuple(
                int(channels) for channels in fusion_in_channels)
            self.fusion_channels = int(fusion_channels)
            if not self.fusion_in_channels:
                raise ValueError("fusion_in_channels must not be empty.")
            if self.fusion_channels <= 0:
                raise ValueError("fusion_channels must be a positive integer.")
            self.fusion_blocks = nn.ModuleList(
                _LearnedFusionBlock(channels, self.fusion_channels)
                for channels in self.fusion_in_channels)

        def extract_feat(self, inputs):
            """Extract and learnably fuse aligned RGB/VV feature pyramids."""
            opt_channels, sar_channels = self.input_split
            expected_channels = opt_channels + sar_channels
            if inputs.shape[1] != expected_channels:
                raise ValueError(
                    f"Expected {expected_channels} input channels, got "
                    f"{inputs.shape[1]}.")

            opt_x = inputs[:, :opt_channels, :, :]
            sar_x = inputs[:, opt_channels:, :, :].repeat(1, 3, 1, 1)
            opt_feats = self.backbone(opt_x)
            sar_feats = self.sar_backbone(sar_x)
            if len(opt_feats) != len(sar_feats):
                raise ValueError(
                    "OPT and SAR backbones must return the same number of "
                    f"feature maps, got {len(opt_feats)} and "
                    f"{len(sar_feats)}.")
            if len(opt_feats) != len(self.fusion_blocks):
                raise ValueError(
                    "fusion_in_channels must contain one entry for every "
                    f"backbone feature map, got {len(self.fusion_blocks)} "
                    f"entries for {len(opt_feats)} maps.")

            fused_feats = []
            for level, (opt_feat, sar_feat, fusion_block,
                        expected_channels) in enumerate(
                            zip(opt_feats, sar_feats, self.fusion_blocks,
                                self.fusion_in_channels)):
                if opt_feat.shape != sar_feat.shape:
                    raise ValueError(
                        "OPT and SAR feature maps must have identical shapes, "
                        f"got {tuple(opt_feat.shape)} and "
                        f"{tuple(sar_feat.shape)} at level {level}.")
                if opt_feat.shape[1] != expected_channels:
                    raise ValueError(
                        f"Expected {expected_channels} channels at level "
                        f"{level}, got {opt_feat.shape[1]}.")
                fused_feats.append(fusion_block(opt_feat, sar_feat))

            fused_feats = tuple(fused_feats)
            if self.with_neck:
                return self.neck(fused_feats)
            return fused_feats


__all__ = ["DualSwinLearnedFusionUPerNet"]
