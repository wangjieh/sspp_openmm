"""Dual-Swin UPerNet with lightweight gated residual-difference fusion.

This module keeps the baseline absolute-difference pyramid as its main path.
It only adds a low-rank, gated residual correction at each Swin stage, making
it substantially smaller than concatenating multi-modal full-width features.
"""

from __future__ import annotations

from ..._registry import MODELS
from .dual_swin_absdiff_upernet import DualSwinAbsDiffUPerNet

_IMPORT_ERROR = None

try:
    import torch
    from torch import nn
except ImportError as exc:  # pragma: no cover - local machines may lack deps.
    _IMPORT_ERROR = exc
    nn = None


def _missing_dependency_message() -> str:
    return (
        "DualSwinGatedResDiffUPerNet requires PyTorch and Open-CD to be "
        "installed and importable. The current import error was: "
        f"{_IMPORT_ERROR!r}")


if _IMPORT_ERROR is not None:

    @MODELS.register_module()
    class DualSwinGatedResDiffUPerNet(DualSwinAbsDiffUPerNet):
        """Placeholder used when PyTorch dependencies are unavailable."""

        def __init__(self, *args, **kwargs):
            raise ImportError(_missing_dependency_message())

else:

    class _GatedResidualDifferenceBlock(nn.Module):
        """Apply a low-rank, optical--SAR gated correction to abs-difference."""

        def __init__(self,
                     in_channels: int,
                     residual_channels: int,
                     residual_scale_init: float):
            super().__init__()
            self.opt_projection = self._make_projection(
                in_channels, residual_channels)
            self.sar_projection = self._make_projection(
                in_channels, residual_channels)
            self.gate = nn.Sequential(
                nn.Conv2d(residual_channels * 3,
                          residual_channels,
                          kernel_size=1,
                          bias=False),
                nn.SyncBatchNorm(residual_channels),
                nn.Sigmoid(),
            )
            self.restore = nn.Sequential(
                nn.Conv2d(residual_channels,
                          in_channels,
                          kernel_size=1,
                          bias=False),
                nn.SyncBatchNorm(in_channels),
            )
            # A small non-zero value keeps the initial output close to T01
            # while allowing all residual-path parameters to receive gradients.
            self.residual_scale = nn.Parameter(
                torch.tensor(float(residual_scale_init)))

        @staticmethod
        def _make_projection(in_channels: int, out_channels: int):
            return nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1,
                          bias=False),
                nn.SyncBatchNorm(out_channels),
                nn.GELU(),
            )

        def forward(self, opt_feat, sar_feat):
            baseline_diff = torch.abs(sar_feat - opt_feat)
            opt_low = self.opt_projection(opt_feat)
            sar_low = self.sar_projection(sar_feat)
            low_diff = sar_low - opt_low
            gate_input = torch.cat(
                (opt_low, sar_low, torch.abs(low_diff)), dim=1)
            residual = self.restore(self.gate(gate_input) * low_diff)
            return baseline_diff + self.residual_scale * residual


    @MODELS.register_module()
    class DualSwinGatedResDiffUPerNet(DualSwinAbsDiffUPerNet):
        """Dual Swin branches with a gated low-rank residual-difference path.

        The four outputs retain their baseline channel widths, so the existing
        UPerHead, loss, optimizer schedule, and metric setup can be reused.
        """

        def __init__(self,
                     residual_in_channels,
                     residual_channels=128,
                     residual_scale_init=1e-3,
                     **kwargs):
            super().__init__(**kwargs)
            self.residual_in_channels = tuple(
                int(channels) for channels in residual_in_channels)
            self.residual_channels = int(residual_channels)
            self.residual_scale_init = float(residual_scale_init)
            if not self.residual_in_channels:
                raise ValueError("residual_in_channels must not be empty.")
            if self.residual_channels <= 0:
                raise ValueError(
                    "residual_channels must be a positive integer.")
            self.residual_blocks = nn.ModuleList(
                _GatedResidualDifferenceBlock(
                    in_channels=channels,
                    residual_channels=min(self.residual_channels, channels),
                    residual_scale_init=self.residual_scale_init)
                for channels in self.residual_in_channels)

        def extract_feat(self, inputs):
            """Extract RGB/VV pyramids and apply gated residual differences."""
            opt_channels, sar_channels = self.input_split
            expected_input_channels = opt_channels + sar_channels
            if inputs.shape[1] != expected_input_channels:
                raise ValueError(
                    f"Expected {expected_input_channels} input channels, got "
                    f"{inputs.shape[1]}.")

            opt_x = inputs[:, :opt_channels, :, :]
            sar_x = inputs[:, opt_channels:, :, :].repeat(1, 3, 1, 1)
            opt_feats = self.backbone(opt_x)
            sar_feats = self.sar_backbone(sar_x)
            if len(opt_feats) != len(sar_feats):
                raise ValueError(
                    "OPT and SAR backbones must return the same number of "
                    f"feature maps, got {len(opt_feats)} and "
                    f"{len(sar_feats)}.")
            if len(opt_feats) != len(self.residual_blocks):
                raise ValueError(
                    "residual_in_channels must contain one entry for every "
                    f"backbone feature map, got {len(self.residual_blocks)} "
                    f"entries for {len(opt_feats)} maps.")

            fused_feats = []
            for level, (opt_feat, sar_feat, residual_block,
                        expected_channels) in enumerate(
                            zip(opt_feats, sar_feats, self.residual_blocks,
                                self.residual_in_channels)):
                if opt_feat.shape != sar_feat.shape:
                    raise ValueError(
                        "OPT and SAR feature maps must have identical shapes, "
                        f"got {tuple(opt_feat.shape)} and "
                        f"{tuple(sar_feat.shape)} at level {level}.")
                if opt_feat.shape[1] != expected_channels:
                    raise ValueError(
                        f"Expected {expected_channels} channels at level "
                        f"{level}, got {opt_feat.shape[1]}.")
                fused_feats.append(residual_block(opt_feat, sar_feat))

            fused_feats = tuple(fused_feats)
            if self.with_neck:
                return self.neck(fused_feats)
            return fused_feats


__all__ = ["DualSwinGatedResDiffUPerNet"]
