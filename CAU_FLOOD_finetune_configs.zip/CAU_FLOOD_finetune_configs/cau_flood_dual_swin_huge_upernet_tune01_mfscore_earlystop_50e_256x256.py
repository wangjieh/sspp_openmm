evaluation = dict(tmpdir="/mnt/htzzb2/EO_test/wj1/tmp")

default_scope = "opencd"
custom_imports = dict(
    imports=["swin_opencd", "swin_opencd.hooks.save_raw_pred_hook"],
    allow_failed_imports=False,
)

data_root = "/mnt/htzzb2/EO_test/datasets/CAU-Flood"
swin_huge_checkpoint = "/mnt/htzzb2/EO_test/wj1/swin_self_developed_weights/swin_huge_openmm_style.pth"
work_dir = "/mnt/htzzb2/EO_test/wj1/swin_work_dirs/cau_flood_dual_swin_huge_upernet_tune01_mfscore_earlystop_50e_256x256"

input_size = (256, 256)
num_classes = 2
batch_size = 8
max_epochs = 50
base_lr = 1e-4
weight_decay = 0.01
ignore_index = 255
in_channels = 4
feature_channels = [352, 704, 1408, 2816]
norm_cfg = dict(type="SyncBN", requires_grad=True)

model_wrapper_cfg = dict(
    type="MMDistributedDataParallel",
    find_unused_parameters=False,
)
find_unused_parameters = False

data_preprocessor = dict(
    type="DualInputSegDataPreProcessor",
    mean=[0.0] * in_channels,
    std=[1.0] * in_channels,
    bgr_to_rgb=False,
    size=input_size,
    pad_val=0,
    seg_pad_val=ignore_index,
    test_cfg=dict(size=input_size),
)

swin_huge_backbone = dict(
    type="mmseg.SwinTransformer",
    pretrain_img_size=256,
    in_channels=3,
    embed_dims=352,
    patch_size=4,
    window_size=8,
    mlp_ratio=4,
    depths=(2, 2, 18, 2),
    num_heads=(8, 16, 32, 64),
    strides=(4, 2, 2, 2),
    out_indices=(0, 1, 2, 3),
    qkv_bias=True,
    patch_norm=True,
    drop_rate=0.0,
    attn_drop_rate=0.0,
    drop_path_rate=0.2,
    use_abs_pos_embed=False,
    norm_cfg=dict(type="LN"),
    with_cp=False,
    frozen_stages=-1,
    init_cfg=dict(type="Pretrained", checkpoint=swin_huge_checkpoint),
)

model = dict(
    type="DualSwinAbsDiffUPerNet",
    data_preprocessor=data_preprocessor,
    opt_backbone=swin_huge_backbone,
    sar_backbone=swin_huge_backbone,
    input_split=(3, 1),
    freeze_backbones=False,
    decode_head=dict(
        type="mmseg.UPerHead",
        in_channels=feature_channels,
        in_index=[0, 1, 2, 3],
        pool_scales=(1, 2, 3, 6),
        channels=512,
        dropout_ratio=0.1,
        num_classes=num_classes,
        norm_cfg=norm_cfg,
        align_corners=False,
        ignore_index=ignore_index,
        loss_decode=dict(
            type="mmseg.CrossEntropyLoss",
            use_sigmoid=False,
            loss_weight=1.0,
        ),
    ),
    train_cfg=dict(),
    test_cfg=dict(mode="whole"),
)

dataset_type = "CAUFLOODDataset"

pack_meta_keys = (
    "img_path",
    "seg_map_path",
    "ori_shape",
    "img_shape",
    "pad_shape",
    "scale_factor",
    "flip",
    "flip_direction",
)

load_cau_flood = dict(
    type="CAUFLOODLoadRasterio",
    ignore_index=ignore_index,
    opt_channels=(0, 1, 2),
    use_opt_all_zero_as_nodata=True,
)

train_pipeline = [
    load_cau_flood,
    dict(type="MultiImgRandomFlip", prob=0.5, direction="horizontal"),
    dict(type="MultiImgRandomFlip", prob=0.5, direction="vertical"),
    dict(type="MultiImgPackSegInputs", meta_keys=pack_meta_keys),
]

test_pipeline = [
    load_cau_flood,
    dict(type="MultiImgPackSegInputs", meta_keys=pack_meta_keys),
]

train_dataloader = dict(
    batch_size=batch_size,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=True),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(
            img_path_from="train/opt",
            img_path_to="train/vv",
            seg_map_path="train/flood_vv",
        ),
        pipeline=train_pipeline,
    ),
)

val_dataloader = dict(
    batch_size=1,
    num_workers=4,
    persistent_workers=True,
    sampler=dict(type="DefaultSampler", shuffle=False),
    dataset=dict(
        type=dataset_type,
        data_root=data_root,
        data_prefix=dict(
            img_path_from="test/opt",
            img_path_to="test/vv",
            seg_map_path="test/flood_vv",
        ),
        pipeline=test_pipeline,
        test_mode=True,
    ),
)

test_dataloader = val_dataloader

val_evaluator = dict(type="mmseg.IoUMetric", iou_metrics=["mIoU", "mFscore"])
test_evaluator = val_evaluator

optim_wrapper = dict(
    type="OptimWrapper",
    optimizer=dict(
        type="AdamW",
        lr=base_lr,
        betas=(0.9, 0.999),
        weight_decay=weight_decay,
    ),
    paramwise_cfg=dict(
        custom_keys={
            "backbone": dict(lr_mult=0.1),
            "sar_backbone": dict(lr_mult=0.1),
        }),
    clip_grad=dict(max_norm=1.0, norm_type=2),
)

param_scheduler = [
    dict(
        type="LinearLR",
        start_factor=1e-6,
        by_epoch=False,
        begin=0,
        end=1500,
    ),
    dict(
        type="PolyLR",
        eta_min=0.0,
        power=1.0,
        begin=0,
        end=max_epochs,
        by_epoch=True,
    ),
]

train_cfg = dict(
    type="EpochBasedTrainLoop",
    max_epochs=max_epochs,
    val_interval=1,
)
val_cfg = dict(type="ValLoop")
test_cfg = dict(type="TestLoop")

default_hooks = dict(
    timer=dict(type="IterTimerHook"),
    logger=dict(type="LoggerHook", interval=50, log_metric_by_epoch=True),
    param_scheduler=dict(type="ParamSchedulerHook"),
    checkpoint=dict(
        type="CheckpointHook",
        by_epoch=True,
        interval=1,
        max_keep_ckpts=3,
        save_best="mFscore",
        rule="greater",
    ),
    early_stopping=dict(
        type="EarlyStoppingHook",
        monitor="mFscore",
        rule="greater",
        min_delta=0.0,
        patience=10,
        strict=True,
        check_finite=True,
    ),
    sampler_seed=dict(type="DistSamplerSeedHook"),
    visualization=dict(type="CDVisualizationHook", draw=False, interval=1),
)

env_cfg = dict(
    cudnn_benchmark=True,
    mp_cfg=dict(mp_start_method="fork", opencv_num_threads=0),
    dist_cfg=dict(backend="nccl"),
)

vis_backends = [dict(type="LocalVisBackend")]
visualizer = dict(
    type="CDLocalVisualizer",
    vis_backends=vis_backends,
    name="visualizer",
)

log_processor = dict(window_size=50, by_epoch=True)
log_level = "INFO"
load_from = None
resume = False

randomness = dict(seed=0, deterministic=False)
auto_scale_lr = dict(enable=False, base_batch_size=batch_size)

custom_hooks = [
    dict(
        type="SaveRawPredHook",
        output_dir=work_dir + "_infer",
        scale255=False,
    ),
]
