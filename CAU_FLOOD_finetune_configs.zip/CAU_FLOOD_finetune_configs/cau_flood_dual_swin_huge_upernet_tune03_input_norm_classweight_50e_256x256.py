_base_ = ["./cau_flood_dual_swin_huge_upernet_tune01_mfscore_earlystop_50e_256x256.py"]

work_dir = "/mnt/htzzb2/EO_test/wj1/swin_work_dirs/cau_flood_dual_swin_huge_upernet_tune03_input_norm_classweight_50e_256x256"

mean = [49.78984182128746, 79.62260561538505, 69.0808852459157, 158.02073291645573]
std = [46.17953300539482, 46.36725283300035, 45.23390891984123, 68.08039319156036]

data_preprocessor = dict(
    mean=mean,
    std=std,
)

model = dict(
    decode_head=dict(
        loss_decode=dict(
            class_weight=[1.0, 1.25],
        ),
    ),
)

custom_hooks = [
    dict(
        type="SaveRawPredHook",
        output_dir=work_dir + "_infer",
        scale255=False,
    ),
]
