# RFR adaptation for CSIG Track 1

This patch adds Track 1 scripts without changing the original IRSatVideo-LEO scripts. It reads the existing layout directly:

```text
G:\\数据文件\\track1\\
├── train\\<sequence>\\img\\<frame>.bmp
├── train\\<sequence>\\mask\\<frame>.png
├── val\\<sequence>\\img\\<frame>.bmp
└── val\\<sequence>\\mask\\<frame>.png
```

The model is trained as a binary mask predictor. At inference, the predicted mask is converted to connected components and each component centroid is emitted as a Track 1 detection-only record (`frame_id target_count 0 x y ...`). Object IDs are always `0`, as required for the detection-only task.

## One-time setup

Install the original RFR environment and compile its DCN extension from `codes/model/dcn`. The original project requires CUDA and a PyTorch/CUDA combination compatible with that extension.

## Train: one GPU

From the `codes` directory, run:

```powershell
python train_track1.py --data-root "G:\\数据文件\\track1" --output-dir ".\\track1_runs\\resunet_rfr" --model-name ResUNet_RFR --seq-len 8 --patch-size 128 --batch-size 2 --epochs 20
```

The script calculates normalization statistics only from `train`, writes checkpoints to the output directory, and keeps the best checkpoint by a centroid-level local F1 proxy on `val`.

## Train: multiple GPUs

Use PyTorch DDP through `torchrun`. `--batch-size` is **per GPU**, so two GPUs with `--batch-size 2` produce a global batch size of 4.

The original RFR DCN extension is Linux-oriented (`make.sh`), so Linux/WSL with NCCL is recommended. On native Windows the scripts automatically select Gloo; use `--dist-backend gloo` explicitly if needed.

```powershell
torchrun --standalone --nproc_per_node=2 train_track1.py --data-root "G:\\数据文件\\track1" --output-dir ".\\track1_runs\\resunet_rfr_ddp" --model-name ResUNet_RFR --seq-len 8 --patch-size 128 --batch-size 2 --epochs 20
```

Training data is distributed across GPUs. Validation remains on rank 0 because RFR must preserve the recurrent frame order within every sequence; all other ranks wait for validation to finish before the next epoch.

## Validate or export TXT files

```powershell
python infer_track1.py --data-root "G:\\数据文件\\track1" --split val --checkpoint ".\\track1_runs\\resunet_rfr\\best_f1.pth.tar" --output-dir ".\\track1_submission_val" --threshold 0.5 --min-area 1 --zip-path ".\\track1_submission_val.zip"
```

The ZIP contains TXT files at its root and no subdirectory. Tune `--threshold`, `--min-area`, and `--match-distance` against validation results before exporting the final submission.

## Multi-GPU inference and submission export

Inference can use multiple GPUs too. Complete sequences are distributed by rank, each GPU writes a distinct set of TXT files, then rank 0 waits for all ranks and creates one ZIP.

```powershell
torchrun --standalone --nproc_per_node=2 infer_track1.py --data-root "G:\\数据文件\\track1" --split val --checkpoint ".\\track1_runs\\resunet_rfr_ddp\\best_f1.pth.tar" --output-dir ".\\track1_submission_val" --threshold 0.5 --min-area 1 --zip-path ".\\track1_submission_val.zip"
```

`f1_proxy` is an internal point-match validation measure. Its `--match-distance` default of 3 pixels is not a replacement for the official scorer; update it if the official evaluation package specifies a different matching radius.
