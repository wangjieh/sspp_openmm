"""Validate an RFR checkpoint or export Track 1 detection-only submissions.

Run with ``torchrun`` to distribute complete video sequences across multiple GPUs.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from typing import Dict, Iterable, Optional, Sequence

import torch
from torch.utils.data import DataLoader

from centroid_metrics import f1_from_counts, mask_to_centroids, match_centroids, submission_line
from dataset_track1 import Track1SequenceDataset, discover_sequences
from distributed_utils import barrier, cleanup_distributed, is_main_process, reduce_counts, setup_distributed
from net import Net


def parse_args():
    parser = argparse.ArgumentParser(description="Run RFR on the CSIG Track 1 data layout.")
    parser.add_argument("--data-root", type=Path, required=True, help="Directory containing train/ and val/.")
    parser.add_argument("--split", default="val", help="Split directory to process, e.g. val or test.")
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--model-name", default=None, help="Defaults to the model_name saved in the checkpoint.")
    parser.add_argument("--output-dir", type=Path, required=True, help="Directory receiving one TXT file per sequence.")
    parser.add_argument("--threshold", type=float, default=None, help="Mask threshold; defaults to the checkpoint value or 0.5.")
    parser.add_argument("--min-area", type=int, default=1, help="Discard predicted connected components smaller than this area.")
    parser.add_argument("--match-distance", type=float, default=3.0, help="Centroid radius for the local validation F1 proxy.")
    parser.add_argument("--zip-path", type=Path, default=None, help="Optional zip path; files are placed at the zip root.")
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--dist-backend", choices=["auto", "nccl", "gloo"], default="auto",
                        help="DDP communication backend; auto selects NCCL on Linux and Gloo on Windows.")
    return parser.parse_args()


def load_checkpoint(path: Path, device: torch.device):
    checkpoint = torch.load(path, map_location=device)
    required = {"state_dict", "norm_cfg"}
    missing = required - set(checkpoint)
    if missing:
        raise KeyError(f"Checkpoint lacks Track 1 metadata: {sorted(missing)}")
    return checkpoint


def _result_dict(tp: int, fp: int, fn: int, has_masks: bool) -> Dict[str, float]:
    results: Dict[str, float] = {"tp": tp, "fp": fp, "fn": fn}
    if has_masks:
        results["f1_proxy"] = f1_from_counts(tp, fp, fn)
        results["precision_proxy"] = 0.0 if tp + fp == 0 else tp / (tp + fp)
        results["recall_proxy"] = 0.0 if tp + fn == 0 else tp / (tp + fn)
    return results


def run_inference(model: Net, split_root: Path, norm_cfg: Dict[str, float], threshold: float, min_area: int,
                  match_distance: float, output_dir: Path, device: torch.device, num_workers: int = 0,
                  require_masks: bool = True, sequences=None, sequence_names: Optional[Iterable[str]] = None) -> Dict[str, float]:
    sequences = sequences or discover_sequences(split_root, require_masks=require_masks)
    names = list(sequence_names) if sequence_names is not None else list(sequences)
    output_dir.mkdir(parents=True, exist_ok=True)
    total_tp = total_fp = total_fn = 0
    model.eval()

    with torch.no_grad():
        for sequence_name in names:
            dataset = Track1SequenceDataset(split_root, sequence_name, norm_cfg, require_masks=require_masks, sequences=sequences)
            loader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=num_workers)
            lines = []
            feature_propagation = None
            for batch in loader:
                image = batch["image"].to(device, non_blocking=True)
                prediction, feature_propagation = model.forward_test(image, feature_propagation)
                height = int(batch["size"][0].item())
                width = int(batch["size"][1].item())
                mask = prediction[0, 0, :height, :width].detach().cpu().numpy() >= threshold
                predicted_centroids = mask_to_centroids(mask, min_area=min_area)
                lines.append(submission_line(batch["frame_id"][0], predicted_centroids))

                if require_masks:
                    target_mask = batch["mask"][0, 0, :height, :width].numpy() > 0
                    target_centroids = mask_to_centroids(target_mask, min_area=1)
                    tp, fp, fn = match_centroids(predicted_centroids, target_centroids, match_distance)
                    total_tp += tp
                    total_fp += fp
                    total_fn += fn
            (output_dir / f"{sequence_name}.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return _result_dict(total_tp, total_fp, total_fn, require_masks)


def main():
    args = parse_args()
    device, rank, world_size, _, distributed = setup_distributed(args.device, args.dist_backend)
    try:
        checkpoint = load_checkpoint(args.checkpoint, device)
        model_name = args.model_name or checkpoint.get("model_name", "ResUNet_RFR")
        threshold = args.threshold if args.threshold is not None else checkpoint.get("threshold", 0.5)
        split_root = args.data_root / args.split
        sequences = discover_sequences(split_root, require_masks=False)
        has_masks = all(mask_path is not None for frames in sequences.values() for _, _, mask_path in frames)
        assigned_sequences = [name for index, name in enumerate(sequences) if index % world_size == rank]

        model = Net(model_name=model_name).to(device)
        model.load_state_dict(checkpoint["state_dict"])
        local_results = run_inference(model, split_root, checkpoint["norm_cfg"], threshold, args.min_area, args.match_distance,
                                      args.output_dir, device, args.num_workers, require_masks=has_masks, sequences=sequences,
                                      sequence_names=assigned_sequences)
        tp, fp, fn = reduce_counts([local_results["tp"], local_results["fp"], local_results["fn"]], device, distributed)
        barrier(distributed)
        if is_main_process(rank):
            print(json.dumps(_result_dict(tp, fp, fn, has_masks), ensure_ascii=False, indent=2))
            if args.zip_path:
                args.zip_path.parent.mkdir(parents=True, exist_ok=True)
                archive_base = args.zip_path.with_suffix("")
                archive = Path(shutil.make_archive(str(archive_base), "zip", root_dir=args.output_dir))
                if archive != args.zip_path:
                    archive.replace(args.zip_path)
                print(f"Wrote submission zip: {args.zip_path}")
        barrier(distributed)
    finally:
        cleanup_distributed(distributed)


if __name__ == "__main__":
    main()
