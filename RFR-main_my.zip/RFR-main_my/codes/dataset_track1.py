"""Dataset utilities for the CSIG Track 1 directory layout.

Expected layout::

    <data_root>/train/<sequence>/img/<frame>.bmp
    <data_root>/train/<sequence>/mask/<frame>.png
    <data_root>/val/<sequence>/img/<frame>.bmp
    <data_root>/val/<sequence>/mask/<frame>.png
"""

from __future__ import annotations

import bisect
import random
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset


IMAGE_SUFFIXES = {".bmp", ".png", ".jpg", ".jpeg"}


def _frame_sort_key(frame_id: str):
    try:
        return (0, int(frame_id))
    except ValueError:
        return (1, frame_id)


def discover_sequences(split_root: str | Path, require_masks: bool = True) -> Dict[str, List[Tuple[str, Path, Optional[Path]]]]:
    """Return paired frames for each sequence, sorted by frame stem.

    Pairing is performed by filename stem so image and mask suffixes may differ.
    """
    split_root = Path(split_root)
    if not split_root.is_dir():
        raise FileNotFoundError(f"Split directory does not exist: {split_root}")

    sequences: Dict[str, List[Tuple[str, Path, Optional[Path]]]] = {}
    for sequence_dir in sorted((p for p in split_root.iterdir() if p.is_dir()), key=lambda p: p.name):
        image_dir = sequence_dir / "img"
        mask_dir = sequence_dir / "mask"
        if not image_dir.is_dir():
            continue
        images = {path.stem: path for path in image_dir.iterdir() if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES}
        if not images:
            continue
        masks = {}
        if mask_dir.is_dir():
            masks = {path.stem: path for path in mask_dir.iterdir() if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES}
        if require_masks and not mask_dir.is_dir():
            raise FileNotFoundError(f"Missing mask directory: {mask_dir}")

        missing_masks = sorted(set(images) - set(masks), key=_frame_sort_key)
        if require_masks and missing_masks:
            preview = ", ".join(missing_masks[:5])
            raise FileNotFoundError(f"{sequence_dir.name} has images without matching masks: {preview}")

        frame_ids = sorted(images, key=_frame_sort_key)
        sequences[sequence_dir.name] = [(frame_id, images[frame_id], masks.get(frame_id)) for frame_id in frame_ids]

    if not sequences:
        raise RuntimeError(f"No image sequences found under: {split_root}")
    return sequences


def load_grayscale(path: Path) -> np.ndarray:
    with Image.open(path) as image:
        return np.asarray(image.convert("I"), dtype=np.float32)


def load_mask(path: Path) -> np.ndarray:
    with Image.open(path) as image:
        array = np.asarray(image)
    if array.ndim == 3:
        array = array.max(axis=2)
    return (array > 0).astype(np.float32)


def compute_normalization(sequences: Dict[str, List[Tuple[str, Path, Optional[Path]]]], max_images: int = 2048, seed: int = 42) -> Dict[str, float]:
    """Estimate normalization statistics from training images only."""
    paths = [image_path for frames in sequences.values() for _, image_path, _ in frames]
    rng = random.Random(seed)
    if len(paths) > max_images:
        paths = rng.sample(paths, max_images)

    pixel_sum = 0.0
    pixel_square_sum = 0.0
    pixel_count = 0
    for path in paths:
        image = load_grayscale(path).astype(np.float64, copy=False)
        pixel_sum += float(image.sum())
        pixel_square_sum += float(np.square(image).sum())
        pixel_count += image.size
    mean = pixel_sum / pixel_count
    variance = max(pixel_square_sum / pixel_count - mean * mean, 1e-12)
    return {"mean": float(mean), "std": float(np.sqrt(variance))}


def pad_to_shape(array: np.ndarray, height: int, width: int) -> np.ndarray:
    pad_h = height - array.shape[-2]
    pad_w = width - array.shape[-1]
    if pad_h < 0 or pad_w < 0:
        raise ValueError("Target padding shape is smaller than the input.")
    return np.pad(array, ((0, pad_h), (0, pad_w)), mode="constant")


def pad_to_multiple(array: np.ndarray, multiple: int = 32) -> np.ndarray:
    height, width = array.shape[-2:]
    target_h = ((height + multiple - 1) // multiple) * multiple
    target_w = ((width + multiple - 1) // multiple) * multiple
    return pad_to_shape(array, target_h, target_w)


def crop_sequence(images: np.ndarray, masks: np.ndarray, patch_size: int, positive_probability: float) -> Tuple[np.ndarray, np.ndarray]:
    """Apply one spatial crop consistently to all frames in a sequence."""
    _, height, width = images.shape
    target_h = max(height, patch_size)
    target_w = max(width, patch_size)
    if (target_h, target_w) != (height, width):
        images = np.stack([pad_to_shape(frame, target_h, target_w) for frame in images])
        masks = np.stack([pad_to_shape(frame, target_h, target_w) for frame in masks])
        height, width = target_h, target_w

    use_positive = masks.any() and random.random() < positive_probability
    if use_positive:
        _, ys, xs = np.where(masks > 0)
        choice = random.randrange(len(ys))
        y = int(ys[choice])
        x = int(xs[choice])
        y0 = random.randint(max(0, y - patch_size + 1), min(y, height - patch_size))
        x0 = random.randint(max(0, x - patch_size + 1), min(x, width - patch_size))
    else:
        y0 = random.randint(0, height - patch_size)
        x0 = random.randint(0, width - patch_size)
    return images[:, y0 : y0 + patch_size, x0 : x0 + patch_size], masks[:, y0 : y0 + patch_size, x0 : x0 + patch_size]


def augment_sequence(images: np.ndarray, masks: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    if random.random() < 0.5:
        images, masks = images[:, ::-1, :], masks[:, ::-1, :]
    if random.random() < 0.5:
        images, masks = images[:, :, ::-1], masks[:, :, ::-1]
    if random.random() < 0.5:
        images, masks = images.transpose(0, 2, 1), masks.transpose(0, 2, 1)
    return images, masks


class Track1TrainDataset(Dataset):
    def __init__(self, split_root: str | Path, seq_len: int = 8, patch_size: int = 128, sample_rate: int = 5,
                 positive_probability: float = 0.9, norm_cfg: Optional[Dict[str, float]] = None):
        self.sequences = discover_sequences(split_root, require_masks=True)
        self.sequence_names = list(self.sequences)
        self.sequence_lengths = [len(self.sequences[name]) for name in self.sequence_names]
        self.cumulative_lengths = np.cumsum(self.sequence_lengths).tolist()
        self.seq_len = seq_len
        self.patch_size = patch_size
        self.sample_rate = max(1, sample_rate)
        self.positive_probability = positive_probability
        self.norm_cfg = norm_cfg or compute_normalization(self.sequences)
        self.num_samples = max(1, sum(self.sequence_lengths) // self.sample_rate)

    def __len__(self) -> int:
        return self.num_samples

    def _sample_sequence(self) -> List[Tuple[str, Path, Optional[Path]]]:
        index = random.randrange(self.cumulative_lengths[-1])
        sequence_index = bisect.bisect_right(self.cumulative_lengths, index)
        return self.sequences[self.sequence_names[sequence_index]]

    def __getitem__(self, _: int):
        frames = self._sample_sequence()
        start = random.randrange(len(frames))
        selected = [frames[min(start + offset, len(frames) - 1)] for offset in range(self.seq_len)]
        images = [load_grayscale(image_path) for _, image_path, _ in selected]
        masks = [load_mask(mask_path) for _, _, mask_path in selected]

        height = max(frame.shape[0] for frame in images)
        width = max(frame.shape[1] for frame in images)
        images = np.stack([pad_to_shape(frame, height, width) for frame in images])
        masks = np.stack([pad_to_shape(frame, height, width) for frame in masks])
        images = (images - self.norm_cfg["mean"]) / self.norm_cfg["std"]
        images, masks = crop_sequence(images, masks, self.patch_size, self.positive_probability)
        images, masks = augment_sequence(images, masks)
        return torch.from_numpy(np.ascontiguousarray(images[:, None], dtype=np.float32)), torch.from_numpy(np.ascontiguousarray(masks[:, None], dtype=np.float32))


class Track1SequenceDataset(Dataset):
    """A full sequence for recurrent validation or submission inference."""
    def __init__(self, split_root: str | Path, sequence_name: str, norm_cfg: Dict[str, float], require_masks: bool = True,
                 sequences: Optional[Dict[str, List[Tuple[str, Path, Optional[Path]]]]] = None):
        sequences = sequences or discover_sequences(split_root, require_masks=require_masks)
        if sequence_name not in sequences:
            raise KeyError(f"Unknown sequence: {sequence_name}")
        self.frames = sequences[sequence_name]
        self.norm_cfg = norm_cfg
        self.require_masks = require_masks

    def __len__(self) -> int:
        return len(self.frames)

    def __getitem__(self, index: int):
        frame_id, image_path, mask_path = self.frames[index]
        image = load_grayscale(image_path)
        original_height, original_width = image.shape
        image = (image - self.norm_cfg["mean"]) / self.norm_cfg["std"]
        image = pad_to_multiple(image, 32)
        output = {"image": torch.from_numpy(np.ascontiguousarray(image[None], dtype=np.float32)),
                  "size": (original_height, original_width), "frame_id": frame_id}
        if self.require_masks:
            mask = pad_to_multiple(load_mask(mask_path), 32)
            output["mask"] = torch.from_numpy(np.ascontiguousarray(mask[None], dtype=np.float32))
        return output
