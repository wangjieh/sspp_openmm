"""Centroid extraction and a local F1 proxy for Track 1 validation."""

from __future__ import annotations

from typing import Iterable, List, Sequence, Tuple

import numpy as np
from scipy import ndimage
from scipy.optimize import linear_sum_assignment


Point = Tuple[float, float]


def mask_to_centroids(mask: np.ndarray, min_area: int = 1) -> List[Point]:
    labels, count = ndimage.label(mask.astype(bool), structure=np.ones((3, 3), dtype=np.uint8))
    centroids: List[Point] = []
    for label_id in range(1, count + 1):
        ys, xs = np.where(labels == label_id)
        if len(xs) < min_area:
            continue
        centroids.append((float(xs.mean()), float(ys.mean())))
    return centroids


def match_centroids(predictions: Sequence[Point], targets: Sequence[Point], distance_threshold: float) -> Tuple[int, int, int]:
    """Return true positives, false positives, and false negatives."""
    if not predictions:
        return 0, 0, len(targets)
    if not targets:
        return 0, len(predictions), 0
    prediction_array = np.asarray(predictions, dtype=np.float32)
    target_array = np.asarray(targets, dtype=np.float32)
    distances = np.linalg.norm(prediction_array[:, None, :] - target_array[None, :, :], axis=2)
    invalid_cost = distance_threshold * 1000.0 + distances.max(initial=0.0)
    costs = np.where(distances <= distance_threshold, distances, invalid_cost)
    rows, cols = linear_sum_assignment(costs)
    true_positives = int(np.count_nonzero(distances[rows, cols] <= distance_threshold))
    return true_positives, len(predictions) - true_positives, len(targets) - true_positives


def f1_from_counts(true_positives: int, false_positives: int, false_negatives: int) -> float:
    denominator = 2 * true_positives + false_positives + false_negatives
    return 0.0 if denominator == 0 else 2 * true_positives / denominator


def submission_line(frame_id: str, centroids: Iterable[Point]) -> str:
    values = list(centroids)
    try:
        formatted_frame_id = str(int(frame_id))
    except ValueError:
        formatted_frame_id = frame_id
    fields = [formatted_frame_id, str(len(values))]
    for x, y in values:
        fields.extend(["0", f"{x:.3f}", f"{y:.3f}"])
    return " ".join(fields)
