"""Small helpers shared by the Track 1 DDP training and inference scripts."""

from __future__ import annotations

import os

import torch
import torch.distributed as dist


def setup_distributed(device_argument: str, backend: str = "auto"):
    """Initialize DDP when launched with torchrun; otherwise return single-GPU state."""
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    rank = int(os.environ.get("RANK", "0"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    distributed = world_size > 1
    if device_argument.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA is required by the RFR deformable-convolution extension, but no CUDA device is available.")
    if distributed:
        if not device_argument.startswith("cuda"):
            raise ValueError("Multi-GPU execution requires --device cuda.")
        torch.cuda.set_device(local_rank)
        if backend == "auto":
            backend = "gloo" if os.name == "nt" else "nccl"
        dist.init_process_group(backend=backend, init_method="env://")
        return torch.device(f"cuda:{local_rank}"), rank, world_size, local_rank, True
    return torch.device(device_argument), rank, world_size, local_rank, False


def is_main_process(rank: int) -> bool:
    return rank == 0


def barrier(distributed: bool):
    if distributed:
        dist.barrier()


def cleanup_distributed(distributed: bool):
    if distributed and dist.is_initialized():
        dist.destroy_process_group()


def unwrap_model(model):
    return model.module if hasattr(model, "module") else model


def reduce_counts(values, device: torch.device, distributed: bool):
    """Sum TP/FP/FN-like integer counts across all ranks."""
    tensor = torch.tensor(values, dtype=torch.long, device=device)
    if distributed:
        dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
    return [int(value) for value in tensor.cpu().tolist()]
