"""Single-GPU and DDP training for RFR on the CSIG Track 1 mask sequences.

Use ``python`` for one GPU and ``torchrun --nproc_per_node=N`` for N GPUs.
"""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel
from torch.optim import Adam
from torch.optim.lr_scheduler import MultiStepLR
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler

from dataset_track1 import Track1TrainDataset, compute_normalization
from distributed_utils import barrier, cleanup_distributed, is_main_process, setup_distributed, unwrap_model
from infer_track1 import run_inference
from net import Net


def parse_args():
    parser = argparse.ArgumentParser(description="Train RFR using G:/.../track1/train and val.")
    parser.add_argument("--data-root", type=Path, required=True, help="Directory containing train/ and val/.")
    parser.add_argument("--output-dir", type=Path, default=Path("./track1_runs/resunet_rfr"))
    parser.add_argument("--model-name", default="ResUNet_RFR", choices=["ACM_RFR", "ALCNet_RFR", "DNANet_RFR", "ISTUDNet_RFR", "ResUNet_RFR"])
    parser.add_argument("--seq-len", type=int, default=8)
    parser.add_argument("--patch-size", type=int, default=128)
    parser.add_argument("--batch-size", type=int, default=2, help="Per-GPU batch size when using torchrun.")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--learning-rate", type=float, default=5e-4, help="Per-process learning rate; it is not auto-scaled by GPU count.")
    parser.add_argument("--milestones", default="5,10,15", help="Comma-separated epochs for LR decay.")
    parser.add_argument("--gamma", type=float, default=0.5)
    parser.add_argument("--sample-rate", type=int, default=5, help="Use roughly total_frames/sample_rate samples per epoch before DDP sharding.")
    parser.add_argument("--positive-probability", type=float, default=0.9)
    parser.add_argument("--norm-samples", type=int, default=2048)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--min-area", type=int, default=1)
    parser.add_argument("--match-distance", type=float, default=3.0)
    parser.add_argument("--val-every", type=int, default=1)
    parser.add_argument("--num-workers", type=int, default=0, help="Workers per GPU process.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--resume", type=Path, default=None)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--dist-backend", choices=["auto", "nccl", "gloo"], default="auto",
                        help="DDP communication backend; auto selects NCCL on Linux and Gloo on Windows.")
    return parser.parse_args()


def seed_everything(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def save_checkpoint(path: Path, model, optimizer: Adam, scheduler: MultiStepLR, epoch: int, best_f1: float, norm_cfg, args):
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "epoch": epoch,
        "state_dict": unwrap_model(model).state_dict(),
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict(),
        "best_f1": best_f1,
        "norm_cfg": norm_cfg,
        "model_name": args.model_name,
        "threshold": args.threshold,
        "min_area": args.min_area,
        "match_distance": args.match_distance,
    }, path)


def global_mean_loss(losses, device: torch.device, distributed: bool) -> float:
    local_sum = float(sum(losses))
    local_count = len(losses)
    summary = torch.tensor([local_sum, local_count], dtype=torch.float64, device=device)
    if distributed:
        dist.all_reduce(summary, op=dist.ReduceOp.SUM)
    return float(summary[0].item() / max(summary[1].item(), 1.0))


def main():
    args = parse_args()
    if not 0.0 <= args.positive_probability <= 1.0:
        raise ValueError("--positive-probability must be between 0 and 1.")
    device, rank, world_size, local_rank, distributed = setup_distributed(args.device, args.dist_backend)
    try:
        # Keep data sampling different by rank while normalization stays deterministic.
        seed_everything(args.seed + rank)
        if is_main_process(rank):
            args.output_dir.mkdir(parents=True, exist_ok=True)
        barrier(distributed)

        train_dataset = Track1TrainDataset(args.data_root / "train", seq_len=args.seq_len, patch_size=args.patch_size,
                                           sample_rate=args.sample_rate, positive_probability=args.positive_probability)
        if args.norm_samples != 2048:
            train_dataset.norm_cfg = compute_normalization(train_dataset.sequences, args.norm_samples, args.seed)
        if is_main_process(rank):
            (args.output_dir / "normalization.json").write_text(json.dumps(train_dataset.norm_cfg, indent=2), encoding="utf-8")
        barrier(distributed)

        sampler = DistributedSampler(train_dataset, num_replicas=world_size, rank=rank, shuffle=True, seed=args.seed) if distributed else None
        train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=sampler is None, sampler=sampler,
                                  num_workers=args.num_workers, pin_memory=device.type == "cuda", drop_last=False)
        model = Net(model_name=args.model_name).to(device)
        if distributed:
            model = DistributedDataParallel(model, device_ids=[local_rank], output_device=local_rank, broadcast_buffers=False)
        optimizer = Adam(model.parameters(), lr=args.learning_rate)
        milestones = [int(value) for value in args.milestones.split(",") if value.strip()]
        scheduler = MultiStepLR(optimizer, milestones=milestones, gamma=args.gamma)

        start_epoch, best_f1 = 0, -1.0
        if args.resume:
            checkpoint = torch.load(args.resume, map_location=device)
            unwrap_model(model).load_state_dict(checkpoint["state_dict"])
            optimizer.load_state_dict(checkpoint["optimizer"])
            scheduler.load_state_dict(checkpoint["scheduler"])
            start_epoch = int(checkpoint["epoch"])
            best_f1 = float(checkpoint.get("best_f1", -1.0))
            if checkpoint["norm_cfg"] != train_dataset.norm_cfg:
                raise ValueError("The resume checkpoint uses different image normalization statistics.")

        history_path = args.output_dir / "history.jsonl"
        for epoch in range(start_epoch, args.epochs):
            if sampler is not None:
                sampler.set_epoch(epoch)
            model.train()
            losses = []
            for images, masks in train_loader:
                images = images.to(device, non_blocking=True)
                masks = masks.to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                # Go through DDP.forward so backward hooks synchronize gradients across GPUs.
                loss = model(images, masks)
                loss.backward()
                optimizer.step()
                losses.append(float(loss.detach().cpu()))
            scheduler.step()
            record = {"epoch": epoch + 1, "loss": global_mean_loss(losses, device, distributed),
                      "learning_rate": optimizer.param_groups[0]["lr"], "world_size": world_size,
                      "global_batch_size": args.batch_size * world_size}

            # Validation is intentionally rank-0 only: it is sequence-recurrent and must retain frame order.
            barrier(distributed)
            if is_main_process(rank) and (epoch + 1) % args.val_every == 0:
                metrics = run_inference(unwrap_model(model), args.data_root / "val", train_dataset.norm_cfg, args.threshold,
                                        args.min_area, args.match_distance, args.output_dir / "validation_txt", device,
                                        args.num_workers, require_masks=True)
                record.update(metrics)
                if metrics["f1_proxy"] > best_f1:
                    best_f1 = metrics["f1_proxy"]
                    save_checkpoint(args.output_dir / "best_f1.pth.tar", model, optimizer, scheduler, epoch + 1,
                                    best_f1, train_dataset.norm_cfg, args)
            barrier(distributed)
            if is_main_process(rank):
                save_checkpoint(args.output_dir / "last.pth.tar", model, optimizer, scheduler, epoch + 1, best_f1,
                                train_dataset.norm_cfg, args)
                with history_path.open("a", encoding="utf-8") as history_file:
                    history_file.write(json.dumps(record) + "\n")
                print(json.dumps(record, ensure_ascii=False))
            barrier(distributed)
    finally:
        cleanup_distributed(distributed)


if __name__ == "__main__":
    main()
