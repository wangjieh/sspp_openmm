"""LightFormer decoder registered as an MMSegmentation decode head.

The implementation adapts the decoder in the local LightFormer source tree
for the four feature maps emitted by ``DINOv3BackboneMmseg``.  It intentionally
does not own a backbone: inputs must be ordered from shallow to deep and have
strides 4, 8, 16, and 32 respectively.
"""

from __future__ import annotations

from typing import Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import build_norm_layer
from mmseg.models.decode_heads.decode_head import BaseDecodeHead
from mmseg.registry import MODELS


def _build_norm(norm_cfg: dict | None, num_features: int) -> nn.Module:
    """Build a normalization layer while allowing an explicit no-norm option."""
    if norm_cfg is None:
        return nn.Identity()
    return build_norm_layer(norm_cfg, num_features)[1]


class _ConvNormAct(nn.Sequential):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        *,
        norm_cfg: dict | None,
        dilation: int = 1,
        stride: int = 1,
        bias: bool = False,
    ) -> None:
        padding = ((stride - 1) + dilation * (kernel_size - 1)) // 2
        super().__init__(
            nn.Conv2d(
                in_channels,
                out_channels,
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                bias=bias,
            ),
            _build_norm(norm_cfg, out_channels),
            nn.ReLU6(inplace=True),
        )


class _ConvNorm(nn.Sequential):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        *,
        norm_cfg: dict | None,
        dilation: int = 1,
        stride: int = 1,
        bias: bool = False,
    ) -> None:
        padding = ((stride - 1) + dilation * (kernel_size - 1)) // 2
        super().__init__(
            nn.Conv2d(
                in_channels,
                out_channels,
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                bias=bias,
            ),
            _build_norm(norm_cfg, out_channels),
        )


class _SeparableConvNormAct(nn.Sequential):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        *,
        norm_cfg: dict | None,
        dilation: int = 1,
        stride: int = 1,
    ) -> None:
        padding = ((stride - 1) + dilation * (kernel_size - 1)) // 2
        super().__init__(
            nn.Conv2d(
                in_channels,
                in_channels,
                kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                groups=in_channels,
                bias=False,
            ),
            _build_norm(norm_cfg, in_channels),
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False),
            nn.ReLU6(inplace=True),
        )


class _SeparableConvNorm(nn.Sequential):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        *,
        norm_cfg: dict | None,
        dilation: int = 1,
        stride: int = 1,
    ) -> None:
        padding = ((stride - 1) + dilation * (kernel_size - 1)) // 2
        super().__init__(
            nn.Conv2d(
                in_channels,
                in_channels,
                kernel_size,
                stride=stride,
                padding=padding,
                dilation=dilation,
                groups=in_channels,
                bias=False,
            ),
            _build_norm(norm_cfg, in_channels),
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False),
        )


class _SeparableConv(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__(
            nn.Conv2d(
                in_channels,
                in_channels,
                kernel_size=3,
                padding=1,
                groups=in_channels,
                bias=False,
            ),
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False),
        )


class _ECAAttention(nn.Module):
    """Efficient channel attention used by the original LightFormer decoder."""

    def __init__(self, kernel_size: int = 3) -> None:
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(
            1,
            1,
            kernel_size=kernel_size,
            padding=(kernel_size - 1) // 2,
            bias=False,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        attention = self.pool(x)
        attention = self.conv(
            attention.squeeze(-1).transpose(-1, -2)
        ).transpose(-1, -2).unsqueeze(-1)
        return x * attention.sigmoid().expand_as(x)


class _WeightFusion(nn.Module):
    """Learnably fuse an upsampled feature with its lateral feature map."""

    def __init__(
        self,
        in_channels: int,
        channels: int,
        *,
        norm_cfg: dict | None,
    ) -> None:
        super().__init__()
        self.pre_conv = nn.Conv2d(in_channels, channels, kernel_size=1, bias=False)
        self.weights = nn.Parameter(torch.ones(2, dtype=torch.float32))
        self.post_conv = _ConvNormAct(
            channels, channels, norm_cfg=norm_cfg, kernel_size=3
        )
        self.eca = _ECAAttention()

    def forward(self, x: torch.Tensor, lateral: torch.Tensor) -> torch.Tensor:
        x = F.interpolate(x, size=lateral.shape[-2:], mode="bilinear", align_corners=False)
        weights = F.relu(self.weights)
        weights = weights / (weights.sum() + 1e-8)
        x = weights[0] * self.pre_conv(lateral) + weights[1] * x
        x = self.post_conv(x)
        return self.eca(x) + x


class _SpatialSelectModel(nn.Module):
    """LightFormer's final shallow-feature refinement module."""

    def __init__(
        self, in_channels: int, channels: int, *, norm_cfg: dict | None
    ) -> None:
        super().__init__()
        if channels % 2:
            raise ValueError("LightFormer channels must be even.")

        self.conv0 = nn.Conv2d(channels, channels, kernel_size=5, padding=2, groups=channels)
        self.conv_spatial = nn.Conv2d(
            channels,
            channels,
            kernel_size=7,
            padding=9,
            dilation=3,
            groups=channels,
        )
        self.conv1 = nn.Conv2d(channels, channels // 2, kernel_size=1)
        self.conv2 = nn.Conv2d(channels, channels // 2, kernel_size=1)
        self.conv_squeeze = nn.Conv2d(2, 2, kernel_size=7, padding=3)
        self.conv = nn.Conv2d(channels // 2, channels, kernel_size=1)

        self.fuse_weights = nn.Parameter(torch.ones(2, dtype=torch.float32))
        self.branch_weights = nn.Parameter(torch.ones(2, dtype=torch.float32))
        self.pre_conv = _ConvNormAct(
            in_channels, channels, kernel_size=1, norm_cfg=norm_cfg
        )
        self.star_conv = _SeparableConvNormAct(
            channels, channels, kernel_size=1, norm_cfg=norm_cfg
        )
        self.small_conv = _SeparableConvNorm(
            channels, channels, norm_cfg=norm_cfg
        )

    def forward(self, x: torch.Tensor, lateral: torch.Tensor) -> torch.Tensor:
        x = F.interpolate(x, size=lateral.shape[-2:], mode="bilinear", align_corners=False)
        weights = F.softmax(self.fuse_weights, dim=0)
        x = weights[0] * x + weights[1] * self.pre_conv(lateral)

        x = self.star_conv(x)
        identity = x
        small = self.small_conv(x)

        attention_near = self.conv1(self.conv0(x))
        attention_far = self.conv2(self.conv_spatial(self.conv0(x)))
        attention = torch.cat([attention_near, attention_far], dim=1)
        spatial_weight = self.conv_squeeze(
            torch.cat(
                [
                    attention.mean(dim=1, keepdim=True),
                    attention.max(dim=1, keepdim=True).values,
                ],
                dim=1,
            )
        ).sigmoid()
        attention = (
            attention_near * spatial_weight[:, :1]
            + attention_far * spatial_weight[:, 1:]
        )
        attention = x * self.conv(attention)
        branch_weights = F.softmax(self.branch_weights, dim=0)
        return identity + branch_weights[0] * attention + branch_weights[1] * small


def _channel_shuffle(x: torch.Tensor, groups: int) -> torch.Tensor:
    batch, channels, height, width = x.shape
    x = x.reshape(batch, channels // groups, groups, height, width)
    x = x.transpose(1, 2).contiguous()
    return x.reshape(batch, channels, height, width)


class _GlobalLocalAttention(nn.Module):
    """Window attention plus axis-wise context aggregation from LightFormer."""

    def __init__(self, dim: int, num_heads: int, window_size: int) -> None:
        super().__init__()
        if dim % num_heads:
            raise ValueError("The attention dimension must be divisible by num_heads.")

        self.num_heads = num_heads
        self.window_size = window_size
        self.head_dim = dim // num_heads
        self.scale = self.head_dim**-0.5
        self.qkv = nn.Conv2d(dim, 3 * dim, kernel_size=1, bias=False)

        table_size = (2 * window_size - 1) ** 2
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros(table_size, num_heads)
        )
        coords = torch.stack(
            torch.meshgrid(
                torch.arange(window_size), torch.arange(window_size), indexing="ij"
            )
        )
        coords = coords.flatten(1)
        relative_coords = coords[:, :, None] - coords[:, None, :]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()
        relative_coords[:, :, 0] += window_size - 1
        relative_coords[:, :, 1] += window_size - 1
        relative_coords[:, :, 0] *= 2 * window_size - 1
        self.register_buffer("relative_position_index", relative_coords.sum(-1))
        nn.init.trunc_normal_(self.relative_position_bias_table, std=0.02)

    def _pad_to_window(self, x: torch.Tensor) -> tuple[torch.Tensor, int, int]:
        _, _, height, width = x.shape
        pad_h = (-height) % self.window_size
        pad_w = (-width) % self.window_size
        if pad_h or pad_w:
            x = F.pad(x, (0, pad_w, 0, pad_h), mode="reflect")
        return x, height, width

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x, height, width = self._pad_to_window(x)
        batch, channels, padded_height, padded_width = x.shape
        window = self.window_size
        num_h = padded_height // window
        num_w = padded_width // window

        qkv = self.qkv(x).reshape(
            batch,
            3,
            self.num_heads,
            self.head_dim,
            num_h,
            window,
            num_w,
            window,
        )
        qkv = qkv.permute(1, 0, 4, 6, 2, 5, 7, 3).reshape(
            3,
            batch * num_h * num_w,
            self.num_heads,
            window * window,
            self.head_dim,
        )
        query, key, value = qkv.unbind(0)
        attention = (query @ key.transpose(-2, -1)) * self.scale
        relative_bias = self.relative_position_bias_table[
            self.relative_position_index.reshape(-1)
        ].reshape(window * window, window * window, self.num_heads)
        attention = attention + relative_bias.permute(2, 0, 1).unsqueeze(0)
        attention = attention.softmax(dim=-1)

        x = attention @ value
        x = x.reshape(
            batch,
            num_h,
            num_w,
            self.num_heads,
            window,
            window,
            self.head_dim,
        ).permute(0, 3, 6, 1, 4, 2, 5).reshape(
            batch, channels, padded_height, padded_width
        )
        x = x[:, :, :height, :width]

        # The original module augments window attention with horizontal and
        # vertical moving-average context at the same resolution.
        context_x = F.avg_pool2d(
            F.pad(x, (0, 0, 0, 1), mode="reflect"),
            kernel_size=(window, 1),
            stride=1,
            padding=(window // 2 - 1, 0),
        )
        context_y = F.avg_pool2d(
            F.pad(x, (0, 1, 0, 0), mode="reflect"),
            kernel_size=(1, window),
            stride=1,
            padding=(0, window // 2 - 1),
        )
        return context_x + context_y


class _DepthwisePointwise(nn.Module):
    def __init__(self, channels: int, *, groups: int) -> None:
        super().__init__()
        self.depthwise = nn.Conv2d(
            channels, channels, kernel_size=3, padding=1, groups=channels, bias=False
        )
        self.pointwise = nn.Conv2d(channels, channels, kernel_size=1, bias=False)
        self.norm1 = nn.GroupNorm(groups, channels)
        self.norm2 = nn.GroupNorm(groups, channels)
        self.activation = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.norm1(self.depthwise(x))
        return self.activation(self.norm2(self.pointwise(x)))


class _LCRM(nn.Module):
    """Local Context Refinement Module from the LightFormer decoder."""

    def __init__(self, channels: int, num_heads: int, window_size: int) -> None:
        super().__init__()
        if channels % 2 or (channels // 2) % num_heads:
            raise ValueError("channels / 2 must be divisible by num_heads.")
        if channels % 8:
            raise ValueError("LightFormer channels must be divisible by 8 for GroupNorm.")

        half_channels = channels // 2
        self.global_attention = _GlobalLocalAttention(
            half_channels, num_heads=num_heads, window_size=window_size
        )
        self.local = _ConvNorm(
            half_channels,
            half_channels,
            kernel_size=1,
            norm_cfg=dict(type="GN", num_groups=8, requires_grad=True),
        )
        self.gate1 = _ConvNormAct(
            half_channels,
            half_channels * 2,
            kernel_size=1,
            norm_cfg=dict(type="GN", num_groups=8, requires_grad=True),
        )
        self.gate2 = _ConvNorm(
            half_channels * 2,
            half_channels,
            kernel_size=1,
            norm_cfg=dict(type="GN", num_groups=8, requires_grad=True),
        )
        self.depthwise = _DepthwisePointwise(half_channels, groups=8)
        self.post_conv = _ConvNorm(
            half_channels * 3,
            channels,
            kernel_size=1,
            norm_cfg=dict(type="GN", num_groups=8, requires_grad=True),
        )
        self.eca = _ECAAttention()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        global_x, local_x = torch.chunk(x, 2, dim=1)
        global_x = self.global_attention(global_x)
        local_x = self.local(local_x)
        depthwise_x = self.depthwise(local_x)
        gated_x = self.gate2(self.gate1(local_x)).sigmoid() * local_x
        x = torch.cat([global_x, depthwise_x, gated_x], dim=1)
        x = self.post_conv(x)
        return self.eca(_channel_shuffle(x, groups=4)) + x


@MODELS.register_module()
class LightFormerHead(BaseDecodeHead):
    """MMSegmentation head implementing the LightFormer decoder.

    Args:
        in_channels: Channels of the four backbone feature maps in shallow to
            deep order.  For the project DINOv3 ViT-L adapter this is
            ``[1024, 1024, 1024, 1024]``.
        channels: Shared decoder width.  The original LightFormer uses 64.
        num_heads: Attention heads in each LCRM.
        window_size: Local attention window size in each LCRM.
    """

    def __init__(
        self,
        in_channels: Sequence[int],
        channels: int = 64,
        num_heads: int = 8,
        window_size: int = 8,
        in_index: Sequence[int] = (0, 1, 2, 3),
        norm_cfg: dict | None = dict(type="SyncBN", requires_grad=True),
        **kwargs,
    ) -> None:
        if len(in_channels) != 4:
            raise ValueError("LightFormerHead requires exactly four input feature maps.")
        if len(in_index) != 4:
            raise ValueError("LightFormerHead requires exactly four input indices.")

        super().__init__(
            in_channels=list(in_channels),
            channels=channels,
            in_index=tuple(in_index),
            input_transform="multiple_select",
            norm_cfg=norm_cfg,
            **kwargs,
        )
        self.window_size = window_size
        self.stem = _ConvNormAct(
            in_channels[-1], channels, kernel_size=1, norm_cfg=norm_cfg
        )
        self.block1 = _LCRM(channels, num_heads=num_heads, window_size=window_size)
        self.wf1 = _WeightFusion(in_channels[-2], channels, norm_cfg=norm_cfg)
        self.block2 = _LCRM(channels, num_heads=num_heads, window_size=window_size)
        self.wf2 = _WeightFusion(in_channels[-3], channels, norm_cfg=norm_cfg)
        self.block3 = _LCRM(channels, num_heads=num_heads, window_size=window_size)
        self.spatial_select = _SpatialSelectModel(
            in_channels[0], channels, norm_cfg=norm_cfg
        )
        self.seg_pre = _SeparableConv(channels, channels)

    def forward(self, inputs: Sequence[torch.Tensor]) -> torch.Tensor:
        shallow, mid_low, mid_high, deep = self._transform_inputs(inputs)

        x = self.stem(deep)
        x = self.block1(x)
        x = self.wf1(x, mid_high)
        x = self.block2(x)
        x = self.wf2(x, mid_low)
        x = self.block3(x)
        x = self.spatial_select(x, shallow)
        x = self.seg_pre(x)
        logits = self.cls_seg(x)

        # DINOv3_Adapter's first output is stride 4, matching the original
        # LightFormer decoder's final feature resolution.
        return F.interpolate(
            logits,
            scale_factor=4,
            mode="bilinear",
            align_corners=self.align_corners,
        )
