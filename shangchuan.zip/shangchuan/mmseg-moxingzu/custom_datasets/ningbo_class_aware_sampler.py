"""Distributed class-aware sampler for the fixed-size Ningbo2m tiles.

The sampler changes only how often a training tile is selected.  It does not
modify images, masks, geospatial metadata, or the segmentation loss.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import rasterio
import torch
import torch.distributed as dist
from mmengine.dist import get_dist_info
from torch.utils.data import Sampler

from mmseg.registry import DATA_SAMPLERS


@DATA_SAMPLERS.register_module()
class NingboClassAwareDistributedSampler(Sampler[int]):
    """Sample Ningbo2m training tiles with class-aware distributed weights.

    A rank-0 process builds a compact JSON cache containing valid-pixel counts
    for every training tile.  A white RGB pixel is treated as ignore, matching
    :class:`LoadNingbo2mRaster`.  At every epoch, all ranks deterministically
    generate the same weighted global index list and then take disjoint
    rank-strided subsets from it.  This keeps DDP step counts synchronized.

    Args:
        dataset: The built training dataset.  It must expose ``data_list`` with
            ``img_path`` and ``seg_map_path`` fields.
        stats_path: JSON cache path for per-tile class statistics.
        class_presence_thresholds: Minimum valid-pixel ratio for each semantic
            class before that class contributes its sampling bonus.
        class_bonus: Additive sampling bonus for each semantic class.
        base_weight: Weight assigned to an ordinary tile.
        max_weight: Upper bound on a tile's final weight.
        ignore_index: Ignore label used by the dataset.
        num_classes: Number of semantic classes.
        seed: Base random seed. ``set_epoch`` adds the epoch number.
        round_up: Match the standard distributed sampler behavior by padding
            the global index count to a multiple of world size.
    """

    _CACHE_VERSION = 1

    def __init__(
        self,
        dataset: Any,
        stats_path: str,
        class_presence_thresholds: Sequence[float],
        class_bonus: Sequence[float],
        base_weight: float = 1.0,
        max_weight: float = 3.0,
        ignore_index: int = 255,
        num_classes: int = 8,
        seed: int = 0,
        round_up: bool = True,
    ) -> None:
        if hasattr(dataset, 'full_init'):
            dataset.full_init()
        if not getattr(dataset, 'data_list', None):
            raise ValueError('The class-aware sampler received an empty dataset.')

        self.dataset = dataset
        self.stats_path = Path(stats_path)
        self.num_classes = int(num_classes)
        self.ignore_index = int(ignore_index)
        self.base_weight = float(base_weight)
        self.max_weight = float(max_weight)
        self.seed = int(seed)
        self.round_up = bool(round_up)
        self.epoch = 0
        self.rank, self.world_size = get_dist_info()

        if self.num_classes <= 0:
            raise ValueError(f'num_classes must be positive, got {num_classes}.')
        if self.base_weight <= 0:
            raise ValueError('base_weight must be positive.')
        if self.max_weight < self.base_weight:
            raise ValueError('max_weight must be at least base_weight.')
        if len(class_presence_thresholds) != self.num_classes:
            raise ValueError(
                'class_presence_thresholds must have num_classes entries, '
                f'got {len(class_presence_thresholds)} and {self.num_classes}.')
        if len(class_bonus) != self.num_classes:
            raise ValueError(
                'class_bonus must have num_classes entries, '
                f'got {len(class_bonus)} and {self.num_classes}.')

        self.class_presence_thresholds = np.asarray(
            class_presence_thresholds, dtype=np.float64)
        self.class_bonus = np.asarray(class_bonus, dtype=np.float64)
        if np.any(self.class_presence_thresholds < 0):
            raise ValueError('class_presence_thresholds must be non-negative.')
        if np.any(self.class_bonus < 0):
            raise ValueError('class_bonus must be non-negative.')

        dataset_size = len(self.dataset)
        if self.round_up:
            self.num_samples = int(np.ceil(dataset_size / self.world_size))
            self.total_size = self.num_samples * self.world_size
        else:
            self.num_samples = int(np.ceil((dataset_size - self.rank) /
                                           self.world_size))
            self.total_size = dataset_size

        counts = self._load_or_build_counts()
        self.weights = self._counts_to_weights(counts)

    def _distributed_barrier(self) -> None:
        if dist.is_available() and dist.is_initialized():
            dist.barrier()

    def _cache_matches_dataset(self, cache: dict[str, Any]) -> bool:
        if cache.get('version') != self._CACHE_VERSION:
            return False
        if cache.get('num_classes') != self.num_classes:
            return False
        if cache.get('ignore_index') != self.ignore_index:
            return False

        samples = cache.get('samples')
        data_list = self.dataset.data_list
        if not isinstance(samples, list) or len(samples) != len(data_list):
            return False

        for cached, data_info in zip(samples, data_list):
            if (cached.get('img_path') != data_info['img_path'] or
                    cached.get('seg_map_path') != data_info['seg_map_path']):
                return False
            counts = cached.get('class_counts')
            if not isinstance(counts, list) or len(counts) != self.num_classes:
                return False
        return True

    def _read_cache(self) -> dict[str, Any] | None:
        if not self.stats_path.is_file():
            return None
        try:
            with self.stats_path.open('r', encoding='utf-8') as file:
                cache = json.load(file)
        except (OSError, json.JSONDecodeError):
            return None
        return cache if self._cache_matches_dataset(cache) else None

    def _build_cache(self) -> dict[str, Any]:
        samples = []
        for data_info in self.dataset.data_list:
            img_path = data_info['img_path']
            seg_map_path = data_info['seg_map_path']
            class_counts, valid_pixels = self._read_tile_statistics(
                img_path, seg_map_path)
            samples.append(dict(
                img_path=img_path,
                seg_map_path=seg_map_path,
                class_counts=class_counts.tolist(),
                valid_pixels=valid_pixels,
            ))

        return dict(
            version=self._CACHE_VERSION,
            num_classes=self.num_classes,
            ignore_index=self.ignore_index,
            samples=samples,
        )

    def _write_cache_atomically(self, cache: dict[str, Any]) -> None:
        self.stats_path.parent.mkdir(parents=True, exist_ok=True)
        temporary_path = self.stats_path.with_name(
            f'{self.stats_path.name}.tmp.{os.getpid()}')
        try:
            with temporary_path.open('w', encoding='utf-8') as file:
                json.dump(cache, file, ensure_ascii=False, separators=(',', ':'))
            os.replace(temporary_path, self.stats_path)
        finally:
            if temporary_path.exists():
                temporary_path.unlink()

    def _load_or_build_counts(self) -> np.ndarray:
        cache = self._read_cache()
        if cache is None and self.rank == 0:
            cache = self._build_cache()
            self._write_cache_atomically(cache)

        self._distributed_barrier()
        if cache is None:
            cache = self._read_cache()
        if cache is None:
            raise RuntimeError(
                f'Unable to read class-aware sampling cache: {self.stats_path}')

        return np.asarray(
            [sample['class_counts'] for sample in cache['samples']],
            dtype=np.float64)

    def _read_tile_statistics(
        self, img_path: str, seg_map_path: str
    ) -> tuple[np.ndarray, int]:
        """Read raster values only; no geospatial operation is performed."""
        with rasterio.open(img_path) as source:
            if source.count < 3:
                raise ValueError(
                    f'Ningbo2m image must contain at least 3 bands: {img_path}')
            rgb = source.read((1, 2, 3))
        with rasterio.open(seg_map_path) as source:
            if source.count != 1:
                raise ValueError(
                    f'Ningbo2m mask must contain exactly 1 band: {seg_map_path}')
            label = source.read(1)

        white_pixels = np.all(rgb == 255, axis=0)
        if white_pixels.shape != label.shape:
            raise ValueError(
                f'Image and mask shapes do not match: {img_path} and '
                f'{seg_map_path}.')

        valid = (~white_pixels & (label != self.ignore_index) &
                 (label >= 0) & (label < self.num_classes))
        valid_labels = label[valid].astype(np.int64, copy=False)
        class_counts = np.bincount(
            valid_labels, minlength=self.num_classes)[:self.num_classes]
        return class_counts.astype(np.int64, copy=False), int(valid.sum())

    def _counts_to_weights(self, class_counts: np.ndarray) -> torch.Tensor:
        valid_pixels = class_counts.sum(axis=1, keepdims=True)
        class_ratios = np.divide(
            class_counts,
            valid_pixels,
            out=np.zeros_like(class_counts, dtype=np.float64),
            where=valid_pixels > 0,
        )
        class_is_present = class_ratios >= self.class_presence_thresholds
        weights = self.base_weight + class_is_present @ self.class_bonus
        weights = np.clip(weights, self.base_weight, self.max_weight)
        return torch.as_tensor(weights, dtype=torch.double)

    def __iter__(self):
        generator = torch.Generator()
        generator.manual_seed(self.seed + self.epoch)
        global_indices = torch.multinomial(
            self.weights,
            self.total_size,
            replacement=True,
            generator=generator,
        ).tolist()
        rank_indices = global_indices[self.rank:self.total_size:self.world_size]
        return iter(rank_indices)

    def __len__(self) -> int:
        return self.num_samples

    def set_epoch(self, epoch: int) -> None:
        self.epoch = int(epoch)
