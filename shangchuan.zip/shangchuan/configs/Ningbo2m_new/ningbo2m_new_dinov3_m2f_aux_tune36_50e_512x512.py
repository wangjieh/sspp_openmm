"""Tune36: tune12 plus direct pixel-level auxiliary supervision."""

_base_ = ['./ningbo2m_new_dinov3_m2f_tune12_50e_512x512.py']

work_dir = (
    '/mnt/htzzb2/EO_test/wj1/qh2_work_dirs/'
    'ningbo2m_new_dinov3_m2f_aux_tune36_50e_512x512')

# The auxiliary branch is used only for training.  Mask2Former remains the
# only inference head, so validation is directly comparable with tune12.
model = dict(
    auxiliary_head=dict(
        type='FCNHead',
        in_channels=1024,
        in_index=0,
        channels=256,
        num_convs=1,
        concat_input=False,
        dropout_ratio=0.1,
        num_classes=8,
        norm_cfg=dict(type='SyncBN', requires_grad=True),
        act_cfg=dict(type='ReLU'),
        align_corners=False,
        loss_decode=[
            dict(
                type='CrossEntropyLoss',
                use_sigmoid=False,
                loss_weight=0.4),
            dict(
                type='DiceLoss',
                use_sigmoid=False,
                activate=True,
                naive_dice=False,
                eps=1.0,
                loss_weight=0.2),
        ]))
