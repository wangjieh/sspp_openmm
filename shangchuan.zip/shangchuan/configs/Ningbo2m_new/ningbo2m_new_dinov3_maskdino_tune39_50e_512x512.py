"""Tune39: tune12 with the MaskDINO decoder replacing Mask2Former decoder."""

custom_imports = dict(
    imports=[
        'custom_models.dinov3_backbone',
        'custom_models.maskdino_head',
        'custom_datasets.ningbo2m_new',
        'custom_datasets.customPotsdam',
    ],
    allow_failed_imports=False,
)

_base_ = ['./ningbo2m_new_dinov3_m2f_tune12_50e_512x512.py']

work_dir = (
    '/mnt/htzzb2/EO_test/wj1/qh2_work_dirs/'
    'ningbo2m_new_dinov3_maskdino_tune39_50e_512x512'
)

# Preserve tune12's backbone, adapter, neck, pixel decoder, losses, queries,
# dataset, and schedule.  Only the Transformer decoder implementation changes.
model = dict(
    decode_head=dict(
        type='MaskDINOHead',
        two_stage=True,
        mask_box_init=True,
        mask_box_threshold=0.5,
        deformable_num_points=4,
        decoder_dropout=0.0,
    )
)
