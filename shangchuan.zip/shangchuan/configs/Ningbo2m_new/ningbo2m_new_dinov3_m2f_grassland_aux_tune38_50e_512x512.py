"""Tune38: tune12 plus training-only grassland binary supervision."""

custom_imports = dict(
    imports=[
        'custom_models.dinov3_backbone',
        'custom_models.mask2former_grassland_aux_head',
        'custom_datasets.ningbo2m_new',
        'custom_datasets.customPotsdam',
    ],
    allow_failed_imports=False,
)

_base_ = ['./ningbo2m_new_dinov3_m2f_tune12_50e_512x512.py']

work_dir = (
    '/mnt/htzzb2/EO_test/wj1/qh2_work_dirs/'
    'ningbo2m_new_dinov3_m2f_grassland_aux_tune38_50e_512x512'
)

# Class 1 is grassland in Ningbo2mNewDataset.  This branch contributes only
# ``loss_grassland_aux`` during training and does not alter inference output.
model = dict(
    decode_head=dict(
        type='Mask2FormerGrasslandAuxHead',
        grassland_class_index=1,
        aux_feature_index=0,
        aux_channels=256,
        aux_loss_weight=1.0,
        aux_positive_weight=1.0,
    )
)
