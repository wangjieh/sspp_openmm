"""Tune37: tune12 plus identity-initialized class-aware feature modulation."""

custom_imports = dict(
    imports=[
        'custom_models.dinov3_backbone',
        'custom_models.class_aware_modulation_neck',
        'custom_datasets.ningbo2m_new',
        'custom_datasets.customPotsdam',
    ],
    allow_failed_imports=False,
)

_base_ = ['./ningbo2m_new_dinov3_m2f_tune12_50e_512x512.py']

work_dir = (
    '/mnt/htzzb2/EO_test/wj1/qh2_work_dirs/'
    'ningbo2m_new_dinov3_m2f_class_aware_tune37_50e_512x512')

# Class indices 1 and 2 are grassland and bareland.  The zero-initialized
# residual gates make the first forward pass equivalent to tune12.
model = dict(
    neck=dict(
        type='ClassAwareFeatureModulationNeck',
        in_channels=[1024, 1024, 1024, 1024],
        focus_class_indices=[1, 2],
        residual_scale_init=0.0))
