"""UPerNet decode head enhanced with LightFormer's SISM module.

The project LightFormer implementation names SISM as
``_SpatialSelectModel``.  This head keeps UPerNet's PSP + FPN aggregation and
applies that module once to its stride-4 fused feature using the DINOv3
Adapter's shallow stride-4 feature as the lateral input.
"""

from __future__ import annotations

from typing import Optional, Sequence

from torch import Tensor

from custom_models.lightformer_head import _SpatialSelectModel
from mmseg.models.decode_heads.uper_head import UPerHead
from mmseg.registry import MODELS


@MODELS.register_module()
class UPerNetSISMHead(UPerHead):
    """UPerNet with the LightFormer Spatial Information Selection Module.

    Args:
        sism_norm_cfg: Normalization configuration for the imported LightFormer
            SISM module.  When omitted, it uses UPerNet's ``norm_cfg``.
    """

    def __init__(self, sism_norm_cfg: Optional[dict] = None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.sism = _SpatialSelectModel(
            in_channels=self.in_channels[0],
            channels=self.channels,
            norm_cfg=sism_norm_cfg if sism_norm_cfg is not None else self.norm_cfg,
        )

    def _forward_feature(self, inputs: Sequence[Tensor]) -> Tensor:
        # UPerNet fuses all levels into a stride-4 tensor.  The same selected
        # shallow DINOv3 Adapter feature is used by LightFormer's SISM as the
        # lateral spatial-detail branch.
        fused_feature = super()._forward_feature(inputs)
        shallow_feature = self._transform_inputs(inputs)[0]
        return self.sism(fused_feature, shallow_feature)
