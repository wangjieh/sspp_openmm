"""Boundary-supervised Mask2Former head for semantic segmentation.

The original Mask2Former head exposes classification, BCE-mask, and Dice
losses only.  This extension keeps its forward and inference paths unchanged,
and adds a training-only boundary loss on the final semantic prediction.
"""

from typing import Any, Dict, Sequence

import torch
import torch.nn.functional as F
from torch import Tensor

from mmseg.models.decode_heads.mask2former_head import Mask2FormerHead
from mmseg.registry import MODELS


@MODELS.register_module()
class Mask2FormerBoundaryHead(Mask2FormerHead):
    """Mask2Former with a class-boundary supervision term.

    ``loss_boundary`` compares boundaries derived from the final fused semantic
    probability map with class-transition boundaries from ``gt_sem_seg``.
    It is active only in ``loss`` and therefore leaves inference unchanged.
    """

    def __init__(
        self,
        loss_boundary_weight: float = 1.0,
        boundary_eps: float = 1e-6,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        if loss_boundary_weight < 0:
            raise ValueError('loss_boundary_weight must be non-negative.')
        self.loss_boundary_weight = float(loss_boundary_weight)
        self.boundary_eps = float(boundary_eps)

    def _semantic_probabilities(
        self, cls_scores: Tensor, mask_preds: Tensor
    ) -> Tensor:
        """Fuse query classes and masks exactly as semantic inference does."""
        cls_probs = F.softmax(cls_scores, dim=-1)[..., :-1]
        mask_probs = mask_preds.sigmoid()
        semantic_scores = torch.einsum('bqc,bqhw->bchw', cls_probs, mask_probs)
        return semantic_scores / semantic_scores.sum(dim=1, keepdim=True).clamp_min(
            self.boundary_eps
        )

    def _target_boundaries(self, labels: Tensor) -> tuple[Tensor, Tensor]:
        """Build a one-pixel class-transition target while respecting ignore labels."""
        valid = labels.ne(self.ignore_index)
        horizontal_change = (
            valid[:, :, :-1]
            & valid[:, :, 1:]
            & labels[:, :, :-1].ne(labels[:, :, 1:])
        )
        vertical_change = (
            valid[:, :-1, :]
            & valid[:, 1:, :]
            & labels[:, :-1, :].ne(labels[:, 1:, :])
        )

        horizontal = torch.logical_or(
            F.pad(horizontal_change, (0, 1, 0, 0)),
            F.pad(horizontal_change, (1, 0, 0, 0)),
        )
        vertical = torch.logical_or(
            F.pad(vertical_change, (0, 0, 0, 1)),
            F.pad(vertical_change, (0, 0, 1, 0)),
        )
        return (horizontal | vertical).unsqueeze(1).float(), valid.unsqueeze(1)

    @staticmethod
    def _prediction_boundaries(probabilities: Tensor) -> Tensor:
        """Use maximum inter-class probability variation as boundary strength."""
        horizontal_change = (probabilities[:, :, :, 1:] - probabilities[:, :, :, :-1]).abs()
        vertical_change = (probabilities[:, :, 1:, :] - probabilities[:, :, :-1, :]).abs()
        horizontal_change = horizontal_change.amax(dim=1, keepdim=True)
        vertical_change = vertical_change.amax(dim=1, keepdim=True)
        horizontal = torch.maximum(
            F.pad(horizontal_change, (0, 1, 0, 0)),
            F.pad(horizontal_change, (1, 0, 0, 0)),
        )
        vertical = torch.maximum(
            F.pad(vertical_change, (0, 0, 0, 1)),
            F.pad(vertical_change, (0, 0, 1, 0)),
        )
        return torch.maximum(horizontal, vertical)

    def _boundary_loss(
        self, cls_scores: Tensor, mask_preds: Tensor, batch_data_samples: Sequence[Any]
    ) -> Tensor:
        labels = torch.cat(
            [data_sample.gt_sem_seg.data for data_sample in batch_data_samples], dim=0
        ).long()
        probabilities = self._semantic_probabilities(cls_scores, mask_preds)
        probabilities = F.interpolate(
            probabilities,
            size=labels.shape[-2:],
            mode='bilinear',
            align_corners=False,
        )
        boundary_pred = self._prediction_boundaries(probabilities)
        boundary_target, valid = self._target_boundaries(labels)

        if not torch.any(valid):
            return boundary_pred.sum() * 0.0

        prediction = boundary_pred[valid].clamp(
            min=self.boundary_eps, max=1.0 - self.boundary_eps
        )
        target = boundary_target[valid]
        positive_count = target.sum()
        negative_count = target.numel() - positive_count
        if positive_count == 0 or negative_count == 0:
            weights = torch.ones_like(target)
        else:
            total_count = positive_count + negative_count
            weights = torch.where(
                target > 0,
                negative_count / total_count,
                positive_count / total_count,
            )
        loss = F.binary_cross_entropy(prediction, target, weight=weights, reduction='mean')
        return loss * self.loss_boundary_weight

    def loss(
        self, x: Sequence[Tensor], batch_data_samples: Sequence[Any], train_cfg: Any
    ) -> Dict[str, Tensor]:
        batch_gt_instances, batch_img_metas = self._seg_data_to_instance_data(batch_data_samples)
        all_cls_scores, all_mask_preds = self(x, batch_data_samples)
        losses = self.loss_by_feat(
            all_cls_scores, all_mask_preds, batch_gt_instances, batch_img_metas
        )
        losses['loss_boundary'] = self._boundary_loss(
            all_cls_scores[-1], all_mask_preds[-1], batch_data_samples
        )
        return losses
