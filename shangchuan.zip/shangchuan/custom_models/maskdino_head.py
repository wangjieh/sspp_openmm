"""A MaskDINO-style decoder head for the existing MMSegmentation pipeline.

This module keeps the project on MMSegmentation: it reuses the configured
Mask2Former pixel decoder and its semantic matching losses, but replaces the
masked-attention decoder with MaskDINO's core mechanics:

* two-stage query selection from multi-scale encoder features;
* deformable cross attention driven by reference boxes;
* iterative box refinement; and
* optional mask-to-box query initialization.

The head intentionally retains Mask2Former's semantic loss contract, so it
can be swapped into tune12 without changing datasets, runner, or inference.
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Sequence, Tuple

import torch
import torch.nn.functional as F
from torch import Tensor, nn

from mmcv.cnn.bricks.transformer import MultiScaleDeformableAttention
from mmseg.models.decode_heads.mask2former_head import Mask2FormerHead
from mmseg.registry import MODELS


class _MLP(nn.Module):
    """Small MLP used for reference positions and box updates."""

    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int, num_layers: int) -> None:
        super().__init__()
        widths = [hidden_dim] * (num_layers - 1)
        self.layers = nn.ModuleList(
            nn.Linear(in_dim, out_dim)
            for in_dim, out_dim in zip([input_dim] + widths, widths + [output_dim])
        )

    def forward(self, value: Tensor) -> Tensor:
        for index, layer in enumerate(self.layers):
            value = F.relu(layer(value)) if index < len(self.layers) - 1 else layer(value)
        return value


def _inverse_sigmoid(value: Tensor, eps: float = 1e-5) -> Tensor:
    value = value.clamp(min=eps, max=1.0 - eps)
    return torch.log(value / (1.0 - value))


def _reference_sine_embedding(reference_points: Tensor, num_pos_feats: int) -> Tensor:
    """DINO-style sine embedding for normalized ``(cx, cy, w, h)`` boxes."""

    scale = 2.0 * math.pi
    dim_t = torch.arange(num_pos_feats, dtype=torch.float32, device=reference_points.device)
    dim_t = 10000 ** (2 * torch.div(dim_t, 2, rounding_mode='floor') / num_pos_feats)

    encoded: List[Tensor] = []
    # DINO orders positional components as y, x, w, h.
    for component in (1, 0, 2, 3):
        value = reference_points[..., component] * scale
        value = value[..., None] / dim_t
        value = torch.stack((value[..., 0::2].sin(), value[..., 1::2].cos()), dim=-1).flatten(-2)
        encoded.append(value)
    return torch.cat(encoded, dim=-1)


class _MaskDINODeformableDecoderLayer(nn.Module):
    """One DINO decoder layer with self-attention and deformable cross-attention."""

    def __init__(
        self,
        embed_dims: int,
        num_heads: int,
        feedforward_channels: int,
        num_feature_levels: int,
        num_points: int,
        dropout: float,
    ) -> None:
        super().__init__()
        self.self_attn = nn.MultiheadAttention(
            embed_dims, num_heads, dropout=dropout, batch_first=True
        )
        self.cross_attn = MultiScaleDeformableAttention(
            embed_dims=embed_dims,
            num_heads=num_heads,
            num_levels=num_feature_levels,
            num_points=num_points,
            batch_first=True,
        )
        self.linear1 = nn.Linear(embed_dims, feedforward_channels)
        self.linear2 = nn.Linear(feedforward_channels, embed_dims)
        self.dropout = nn.Dropout(dropout)
        self.norm1 = nn.LayerNorm(embed_dims)
        self.norm2 = nn.LayerNorm(embed_dims)
        self.norm3 = nn.LayerNorm(embed_dims)

    def forward(
        self,
        query: Tensor,
        query_pos: Tensor,
        reference_points: Tensor,
        memory: Tensor,
        spatial_shapes: Tensor,
        level_start_index: Tensor,
    ) -> Tensor:
        query_with_pos = query + query_pos
        attended = self.self_attn(
            query_with_pos, query_with_pos, query, need_weights=False
        )[0]
        query = self.norm1(query + self.dropout(attended))

        # ``identity=zeros`` returns only the deformable-attention update;
        # the residual is added explicitly below, matching DINO's decoder.
        attended = self.cross_attn(
            query=query + query_pos,
            value=memory,
            identity=torch.zeros_like(query),
            query_pos=None,
            key_padding_mask=None,
            reference_points=reference_points,
            spatial_shapes=spatial_shapes,
            level_start_index=level_start_index,
        )
        query = self.norm2(query + self.dropout(attended))
        attended = self.linear2(self.dropout(F.relu(self.linear1(query))))
        return self.norm3(query + self.dropout(attended))


@MODELS.register_module()
class MaskDINOHead(Mask2FormerHead):
    """MaskDINO decoder adapted to MMSegmentation's semantic-head interface.

    The configured Mask2Former pixel decoder still produces mask features and
    multi-scale memory maps.  Only its masked-attention Transformer decoder is
    replaced.  This makes ``type='MaskDINOHead'`` a drop-in decoder replacement
    for the tune12 configuration.
    """

    def __init__(
        self,
        two_stage: bool = True,
        mask_box_init: bool = True,
        mask_box_threshold: float = 0.5,
        deformable_num_points: int = 4,
        decoder_dropout: float = 0.0,
        **kwargs: Any,
    ) -> None:
        transformer_cfg = kwargs.get('transformer_decoder')
        layer_cfg = (
            transformer_cfg.get('layer_cfg', {})
            if isinstance(transformer_cfg, dict)
            else getattr(transformer_cfg, 'layer_cfg', {})
        )
        cross_cfg = (
            layer_cfg.get('cross_attn_cfg', {})
            if isinstance(layer_cfg, dict)
            else getattr(layer_cfg, 'cross_attn_cfg', {})
        )
        ffn_cfg = (
            layer_cfg.get('ffn_cfg', {})
            if isinstance(layer_cfg, dict)
            else getattr(layer_cfg, 'ffn_cfg', {})
        )
        configured_num_heads = (
            cross_cfg.get('num_heads', 8)
            if isinstance(cross_cfg, dict)
            else getattr(cross_cfg, 'num_heads', 8)
        )
        configured_ffn_channels = (
            ffn_cfg.get('feedforward_channels', 2048)
            if isinstance(ffn_cfg, dict)
            else getattr(ffn_cfg, 'feedforward_channels', 2048)
        )
        configured_dropout = (
            ffn_cfg.get('ffn_drop', decoder_dropout)
            if isinstance(ffn_cfg, dict)
            else getattr(ffn_cfg, 'ffn_drop', decoder_dropout)
        )

        super().__init__(**kwargs)
        if not 0.0 < mask_box_threshold < 1.0:
            raise ValueError('mask_box_threshold must be in (0, 1).')

        self.two_stage = bool(two_stage)
        self.mask_box_init = bool(mask_box_init)
        self.mask_box_threshold = float(mask_box_threshold)
        self.num_feature_levels = self.num_transformer_feat_level
        self.embed_dims = self.decoder_embed_dims
        self.num_heads = int(getattr(self, 'num_heads', configured_num_heads))
        self.num_pos_feats = self.embed_dims // 2

        # The parent creates a Mask2FormerTransformerDecoder.  It is removed
        # so the parameter set and forward path contain only MaskDINO layers.
        del self.transformer_decoder

        self.encoder_output = nn.Linear(self.embed_dims, self.embed_dims)
        self.encoder_norm = nn.LayerNorm(self.embed_dims)
        self.encoder_class = nn.Linear(self.embed_dims, self.num_classes + 1)
        self.reference_pos = _MLP(self.embed_dims * 2, self.embed_dims, self.embed_dims, 2)
        self.decoder_norm = nn.LayerNorm(self.embed_dims)
        self.decoder_layers = nn.ModuleList(
            _MaskDINODeformableDecoderLayer(
                embed_dims=self.embed_dims,
                num_heads=self.num_heads,
                feedforward_channels=int(configured_ffn_channels),
                num_feature_levels=self.num_feature_levels,
                num_points=int(deformable_num_points),
                dropout=float(configured_dropout),
            )
            for _ in range(self.num_transformer_decoder_layers)
        )
        self.bbox_embed = nn.ModuleList(
            _MLP(self.embed_dims, self.embed_dims, 4, 3)
            for _ in range(self.num_transformer_decoder_layers)
        )
        self.query_feat = nn.Embedding(self.num_queries, self.embed_dims)
        self.query_refpoint = nn.Embedding(self.num_queries, 4)

    def init_weights(self) -> None:
        for projection in self.decoder_input_projs:
            if isinstance(projection, nn.Conv2d):
                nn.init.xavier_uniform_(projection.weight)
                if projection.bias is not None:
                    nn.init.constant_(projection.bias, 0)
        self.pixel_decoder.init_weights()
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
            elif isinstance(module, nn.LayerNorm):
                nn.init.constant_(module.bias, 0)
                nn.init.constant_(module.weight, 1)
            elif isinstance(module, MultiScaleDeformableAttention):
                module.init_weights()
        for predictor in self.bbox_embed:
            nn.init.constant_(predictor.layers[-1].weight, 0)
            nn.init.constant_(predictor.layers[-1].bias, 0)
        nn.init.normal_(self.query_feat.weight, std=0.02)
        nn.init.uniform_(self.query_refpoint.weight, 0.0, 1.0)

    def _flatten_memory(
        self, memory_maps: Sequence[Tensor]
    ) -> Tuple[Tensor, Tensor, Tensor]:
        flattened: List[Tensor] = []
        shapes: List[Tuple[int, int]] = []
        for level_index, feature in enumerate(memory_maps[:self.num_feature_levels]):
            feature = self.decoder_input_projs[level_index](feature)
            batch_size, _, height, width = feature.shape
            shapes.append((height, width))
            feature = feature.flatten(2).transpose(1, 2)
            feature = feature + self.level_embed.weight[level_index].view(1, 1, -1)
            flattened.append(feature)
        memory = torch.cat(flattened, dim=1)
        spatial_shapes = torch.as_tensor(shapes, dtype=torch.long, device=memory.device)
        level_start_index = torch.cat(
            (spatial_shapes.new_zeros((1,)), spatial_shapes.prod(1).cumsum(0)[:-1])
        )
        return memory, spatial_shapes, level_start_index

    @staticmethod
    def _encoder_proposals(
        batch_size: int, spatial_shapes: Tensor, device: torch.device
    ) -> Tensor:
        proposals: List[Tensor] = []
        for level_index, (height, width) in enumerate(spatial_shapes.tolist()):
            y, x = torch.meshgrid(
                torch.arange(height, dtype=torch.float32, device=device),
                torch.arange(width, dtype=torch.float32, device=device),
                indexing='ij',
            )
            center_x = (x + 0.5) / width
            center_y = (y + 0.5) / height
            box_width = torch.full_like(center_x, 0.05 * (2.0 ** level_index))
            box_height = torch.full_like(center_y, 0.05 * (2.0 ** level_index))
            proposals.append(
                torch.stack((center_x, center_y, box_width, box_height), dim=-1).reshape(-1, 4)
            )
        return torch.cat(proposals, dim=0).unsqueeze(0).repeat(batch_size, 1, 1).clamp(0.01, 0.99)

    def _prediction_heads(self, query: Tensor, mask_features: Tensor) -> Tuple[Tensor, Tensor]:
        query = self.decoder_norm(query)
        cls_scores = self.cls_embed(query)
        mask_embed = self.mask_embed(query)
        mask_preds = torch.einsum('bqc,bchw->bqhw', mask_embed, mask_features)
        return cls_scores, mask_preds

    def _masks_to_boxes(self, mask_logits: Tensor, fallback_boxes: Tensor) -> Tensor:
        """Convert predicted binary masks to normalized boxes without Python loops."""

        batch_size, num_queries, height, width = mask_logits.shape
        masks = mask_logits.sigmoid() >= self.mask_box_threshold
        valid = masks.flatten(2).any(dim=-1)
        x_coords = torch.arange(width, device=mask_logits.device).view(1, 1, 1, width)
        y_coords = torch.arange(height, device=mask_logits.device).view(1, 1, height, 1)
        x_min = x_coords.masked_fill(~masks, width).amin(dim=(-1, -2))
        x_max = x_coords.masked_fill(~masks, -1).amax(dim=(-1, -2))
        y_min = y_coords.masked_fill(~masks, height).amin(dim=(-1, -2))
        y_max = y_coords.masked_fill(~masks, -1).amax(dim=(-1, -2))
        boxes = torch.stack(
            (
                (x_min + x_max + 1.0) / (2.0 * width),
                (y_min + y_max + 1.0) / (2.0 * height),
                (x_max - x_min + 1.0) / width,
                (y_max - y_min + 1.0) / height,
            ),
            dim=-1,
        ).clamp(0.01, 0.99)
        return torch.where(valid.unsqueeze(-1), boxes, fallback_boxes)

    def _two_stage_queries(
        self, memory: Tensor, spatial_shapes: Tensor, mask_features: Tensor
    ) -> Tuple[Tensor, Tensor]:
        encoded_memory = self.encoder_norm(self.encoder_output(memory))
        encoder_scores = self.encoder_class(encoded_memory)
        foreground_scores = encoder_scores.softmax(dim=-1)[..., :-1].amax(dim=-1)
        topk = min(self.num_queries, foreground_scores.shape[1])
        topk_indices = foreground_scores.topk(topk, dim=1).indices
        query = torch.gather(
            encoded_memory, 1, topk_indices.unsqueeze(-1).expand(-1, -1, self.embed_dims)
        )
        proposals = self._encoder_proposals(memory.shape[0], spatial_shapes, memory.device)
        reference_points = torch.gather(
            proposals, 1, topk_indices.unsqueeze(-1).expand(-1, -1, 4)
        )
        if topk != self.num_queries:
            repeat_count = math.ceil(self.num_queries / topk)
            query = query.repeat(1, repeat_count, 1)[:, :self.num_queries]
            reference_points = reference_points.repeat(1, repeat_count, 1)[:, :self.num_queries]
        if self.mask_box_init:
            _, masks = self._prediction_heads(query, mask_features)
            reference_points = self._masks_to_boxes(masks.detach(), reference_points)
        return query, reference_points

    def forward(
        self, x: Sequence[Tensor], batch_data_samples: Optional[Sequence[Any]] = None
    ) -> Tuple[List[Tensor], List[Tensor]]:
        mask_features, memory_maps = self.pixel_decoder(x)
        memory, spatial_shapes, level_start_index = self._flatten_memory(memory_maps)
        batch_size = memory.shape[0]

        if self.two_stage:
            query, reference_points = self._two_stage_queries(memory, spatial_shapes, mask_features)
        else:
            query = self.query_feat.weight.unsqueeze(0).repeat(batch_size, 1, 1)
            reference_points = self.query_refpoint.weight.sigmoid().unsqueeze(0).repeat(batch_size, 1, 1)

        all_cls_scores: List[Tensor] = []
        all_mask_preds: List[Tensor] = []
        cls_scores, mask_preds = self._prediction_heads(query, mask_features)
        all_cls_scores.append(cls_scores)
        all_mask_preds.append(mask_preds)

        for layer, bbox_embed in zip(self.decoder_layers, self.bbox_embed):
            sine_embedding = _reference_sine_embedding(reference_points, self.num_pos_feats)
            query_pos = self.reference_pos(sine_embedding)
            references_for_attention = reference_points.unsqueeze(2).repeat(
                1, 1, self.num_feature_levels, 1
            )
            query = layer(
                query=query,
                query_pos=query_pos,
                reference_points=references_for_attention,
                memory=memory,
                spatial_shapes=spatial_shapes,
                level_start_index=level_start_index,
            )
            reference_points = (
                _inverse_sigmoid(reference_points) + bbox_embed(query)
            ).sigmoid()
            cls_scores, mask_preds = self._prediction_heads(query, mask_features)
            all_cls_scores.append(cls_scores)
            all_mask_preds.append(mask_preds)
            reference_points = reference_points.detach()

        return all_cls_scores, all_mask_preds
