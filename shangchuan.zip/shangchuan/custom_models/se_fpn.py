"""Feature Pyramid Network with Squeeze-and-Excitation output attention."""

from __future__ import annotations

from typing import Sequence, Tuple

from torch import Tensor, nn

from mmseg.models.necks.fpn import FPN
from mmseg.registry import MODELS


class SEBlock(nn.Module):
    """Channel attention used on one FPN output feature map.

    The block performs global average pooling followed by the standard SE
    bottleneck ``C -> C / reduction -> C``.  It preserves the input shape and
    rescales every channel independently.
    """

    def __init__(self, channels: int, reduction: int = 16) -> None:
        super().__init__()
        if channels < 1:
            raise ValueError(f'channels must be positive, got {channels}.')
        if reduction < 1:
            raise ValueError(f'reduction must be positive, got {reduction}.')

        hidden_channels = max(1, channels // reduction)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.channel_attention = nn.Sequential(
            nn.Conv2d(channels, hidden_channels, kernel_size=1, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_channels, channels, kernel_size=1, bias=True),
            nn.Sigmoid(),
        )

    def forward(self, x: Tensor) -> Tensor:
        attention = self.channel_attention(self.avg_pool(x))
        return x * attention


@MODELS.register_module()
class SEFPN(FPN):
    """Apply one SE block to every output level of a standard FPN.

    This leaves FPN's lateral projection, top-down fusion and 3x3 output
    convolutions unchanged.  Attention is applied only after each final FPN
    output, so tune49 receives four 256-channel SE-reweighted feature maps.
    """

    def __init__(
        self,
        in_channels: Sequence[int],
        out_channels: int,
        num_outs: int,
        se_reduction: int = 16,
        **kwargs,
    ) -> None:
        super().__init__(
            in_channels=in_channels,
            out_channels=out_channels,
            num_outs=num_outs,
            **kwargs,
        )
        self.se_blocks = nn.ModuleList(
            SEBlock(out_channels, reduction=se_reduction) for _ in range(num_outs))

    def forward(self, inputs: Tuple[Tensor, ...]) -> Tuple[Tensor, ...]:
        outputs = super().forward(inputs)
        if len(outputs) != len(self.se_blocks):
            raise RuntimeError(
                'The number of FPN outputs does not match the number of SE blocks: '
                f'{len(outputs)} versus {len(self.se_blocks)}.')
        return tuple(block(feature) for block, feature in zip(self.se_blocks, outputs))
