"""Grassland-focused auxiliary supervision for MMSegmentation Mask2Former.

The normal Mask2Former semantic output is left untouched.  During training a
small binary branch learns whether each pixel is grassland, which gives the
minority/important grassland class a direct dense supervision signal.  The
branch is deliberately omitted from ``predict`` so existing inference and
evaluation behaviour remains unchanged.
"""

from __future__ import annotations

from typing import Any, Dict, Sequence

import torch
import torch.nn.functional as F
from torch import Tensor, nn

from mmseg.models.decode_heads.mask2former_head import Mask2FormerHead
from mmseg.registry import MODELS


@MODELS.register_module()
class Mask2FormerGrasslandAuxHead(Mask2FormerHead):
    """Mask2Former with a training-only grassland-versus-background branch.

    Args:
        grassland_class_index: Dataset class index used for grassland.
        aux_feature_index: Feature level used by the auxiliary classifier.
            The default selects the stride-4 DINOv3 Adapter feature map.
        aux_channels: Width of the small convolutional classifier.
        aux_loss_weight: Multiplier for the binary auxiliary loss.
        aux_positive_weight: Positive-example weight for BCE.  Keep this at
            1.0 unless class statistics show grassland is under-represented.
    """

    def __init__(
        self,
        grassland_class_index: int = 1,
        aux_feature_index: int = 0,
        aux_channels: int = 256,
        aux_loss_weight: float = 1.0,
        aux_positive_weight: float = 1.0,
        **kwargs: Any,
    ) -> None:
        in_channels = tuple(int(channel) for channel in kwargs['in_channels'])
        if not 0 <= aux_feature_index < len(in_channels):
            raise ValueError(
                f'aux_feature_index must be in [0, {len(in_channels) - 1}], '
                f'got {aux_feature_index}.'
            )
        if not 0 <= grassland_class_index < int(kwargs['num_classes']):
            raise ValueError('grassland_class_index must refer to a foreground class.')
        if aux_loss_weight < 0 or aux_positive_weight <= 0:
            raise ValueError('Auxiliary loss weights must be positive.')

        super().__init__(**kwargs)
        self.grassland_class_index = int(grassland_class_index)
        self.aux_feature_index = int(aux_feature_index)
        self.aux_loss_weight = float(aux_loss_weight)
        self.aux_positive_weight = float(aux_positive_weight)

        # GroupNorm keeps the branch independent from per-GPU batch size.
        num_groups = 32 if aux_channels % 32 == 0 else 1
        self.grassland_aux_classifier = nn.Sequential(
            nn.Conv2d(in_channels[self.aux_feature_index], aux_channels, 3, padding=1, bias=False),
            nn.GroupNorm(num_groups, aux_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(aux_channels, 1, 1),
        )

    def _grassland_loss(
        self, features: Sequence[Tensor], batch_data_samples: Sequence[Any]
    ) -> Tensor:
        labels = torch.cat(
            [sample.gt_sem_seg.data for sample in batch_data_samples], dim=0
        ).long()
        logits = self.grassland_aux_classifier(features[self.aux_feature_index])
        logits = F.interpolate(logits, size=labels.shape[-2:], mode='bilinear', align_corners=False)
        logits = logits.squeeze(1)

        valid = labels.ne(self.ignore_index)
        if not torch.any(valid):
            return logits.sum() * 0.0

        target = labels.eq(self.grassland_class_index).to(dtype=logits.dtype)
        positive_weight = logits.new_tensor(self.aux_positive_weight)
        loss = F.binary_cross_entropy_with_logits(
            logits[valid], target[valid], pos_weight=positive_weight
        )
        return loss * self.aux_loss_weight

    def loss(
        self, x: Sequence[Tensor], batch_data_samples: Sequence[Any], train_cfg: Any
    ) -> Dict[str, Tensor]:
        batch_gt_instances, batch_img_metas = self._seg_data_to_instance_data(batch_data_samples)
        all_cls_scores, all_mask_preds = self(x, batch_data_samples)
        losses = self.loss_by_feat(
            all_cls_scores, all_mask_preds, batch_gt_instances, batch_img_metas
        )
        losses['loss_grassland_aux'] = self._grassland_loss(x, batch_data_samples)
        return losses
