"""A lightweight class-conditional feature modulation neck for Mask2Former."""

from __future__ import annotations

import math
from typing import Sequence, Tuple

import torch
from torch import Tensor, nn
from mmengine.model import BaseModule
from mmseg.registry import MODELS


@MODELS.register_module()
class ClassAwareFeatureModulationNeck(BaseModule):
    """Apply residual, class-conditional channel modulation to feature levels.

    Each selected semantic slot predicts a spatial gate and has a learned
    channel prototype.  The weighted prototypes modulate each feature level.
    The residual scales are initialized to zero, making this neck an exact
    identity at the beginning of training and preserving the tune12 starting
    behaviour.

    Args:
        in_channels: Channels for every incoming feature level.
        focus_class_indices: Semantic class indices to allocate modulation
            slots for.  tune37 uses grassland and bareland, the weakest
            foreground classes in tune12.
        residual_scale_init: Initial residual strength.  Keep at 0.0 for a
            stable, identity initialization.
    """

    def __init__(
        self,
        in_channels: Sequence[int],
        focus_class_indices: Sequence[int],
        residual_scale_init: float = 0.0,
        init_cfg=None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        if not in_channels:
            raise ValueError('in_channels must contain at least one feature level.')
        if not focus_class_indices:
            raise ValueError('focus_class_indices must not be empty.')

        self.in_channels = tuple(int(channels) for channels in in_channels)
        self.focus_class_indices = tuple(int(index) for index in focus_class_indices)
        self.num_focus_classes = len(self.focus_class_indices)

        self.class_gates = nn.ModuleList()
        self.class_prototypes = nn.ParameterList()
        self.residual_scales = nn.ParameterList()
        for channels in self.in_channels:
            gate = nn.Conv2d(channels, self.num_focus_classes, kernel_size=1)
            nn.init.kaiming_normal_(gate.weight, mode='fan_out', nonlinearity='relu')
            nn.init.zeros_(gate.bias)
            self.class_gates.append(gate)

            prototype = nn.Parameter(torch.empty(self.num_focus_classes, channels))
            nn.init.normal_(prototype, mean=0.0, std=0.02)
            self.class_prototypes.append(prototype)
            self.residual_scales.append(
                nn.Parameter(torch.tensor(float(residual_scale_init))))

    def forward(self, inputs: Sequence[Tensor]) -> Tuple[Tensor, ...]:
        if len(inputs) != len(self.in_channels):
            raise ValueError(
                f'Expected {len(self.in_channels)} feature levels, got {len(inputs)}.')

        outputs = []
        for feature, expected_channels, gate_layer, prototypes, residual_scale in zip(
                inputs, self.in_channels, self.class_gates, self.class_prototypes,
                self.residual_scales):
            if feature.ndim != 4 or feature.shape[1] != expected_channels:
                raise ValueError(
                    'Feature shape does not match the configured in_channels: '
                    f'expected [N, {expected_channels}, H, W], got {tuple(feature.shape)}.')

            class_gates = torch.sigmoid(gate_layer(feature))
            channel_gate = torch.einsum(
                'bkhw,kc->bchw', class_gates, prototypes)
            channel_gate = channel_gate / math.sqrt(self.num_focus_classes)
            outputs.append(feature * (1.0 + residual_scale * torch.tanh(channel_gate)))

        return tuple(outputs)
