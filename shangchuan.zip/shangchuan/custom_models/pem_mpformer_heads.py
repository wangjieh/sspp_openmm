"""PEM and MP-Former heads for MMSegmentation Mask2Former.

The original PEM and MP-Former projects are Detectron2 implementations.  This
module ports their decoder-side ideas to the MMSegmentation/MMDetection
Mask2Former interface without modifying an installed OpenMMLab package.

The three registered heads are:

* ``PEMMask2FormerHead``: PEM prototype cross-attention plus its light pixel
  decoder.
* ``MPFormerMask2FormerHead``: Mask-Piloted training on top of a Mask2Former
  decoder.  The pilot branch is active only while computing training losses.
* ``PEMMPFormerMask2FormerHead``: the PEM architecture with MP-Former
  training supervision.

All heads preserve Mask2Former's regular semantic-segmentation outputs, so
they work with ``EncoderDecoder`` and the normal MMSegmentation validation and
inference paths.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Tuple

import torch
import torch.nn.functional as F
from torch import Tensor, nn

try:
    from mmcv.cnn import build_norm_layer
except ImportError:  # pragma: no cover - the project training environment has mmcv
    build_norm_layer = None

try:
    from mmcv.ops import ModulatedDeformConv2d
except ImportError:  # pragma: no cover - allows a clear fallback for CPU-only checks
    ModulatedDeformConv2d = None

from mmseg.models.decode_heads.mask2former_head import Mask2FormerHead
from mmseg.registry import MODELS


def _cfg_get(cfg: Any, key: str, default: Any = None) -> Any:
    """Read a value from a dict or an MMEngine ConfigDict."""
    if cfg is None:
        return default
    if isinstance(cfg, dict):
        return cfg.get(key, default)
    return getattr(cfg, key, default)


def _make_norm(num_channels: int, norm_cfg: Optional[dict]) -> nn.Module:
    if norm_cfg is None:
        return nn.Identity()
    if build_norm_layer is None:
        # This path is solely for import-time robustness.  A real MMSeg run has
        # mmcv and therefore receives the configured normalization layer.
        return nn.BatchNorm2d(num_channels)
    return build_norm_layer(norm_cfg, num_channels)[1]


class _ConvNormReLU(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        stride: int = 1,
        padding: int = 1,
        norm_cfg: Optional[dict] = None,
        groups: int = 1,
    ) -> None:
        super().__init__()
        self.conv = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=kernel_size,
            stride=stride,
            padding=padding,
            groups=groups,
            bias=False,
        )
        self.norm = _make_norm(out_channels, norm_cfg)
        self.act = nn.ReLU(inplace=True)

    def forward(self, x: Tensor) -> Tensor:
        return self.act(self.norm(self.conv(x)))


class _ContextSelfModulation(nn.Module):
    """The channel-wise context modulation used by PEM's pixel decoder."""

    def __init__(self, channels: int, reduction: int, norm_cfg: Optional[dict]) -> None:
        super().__init__()
        if reduction < 1:
            raise ValueError('pem_csm_reduction must be at least one.')
        hidden_channels = max(channels // reduction, 1)
        self.gate = nn.Sequential(
            nn.Conv2d(channels, hidden_channels, 1, bias=False),
            _make_norm(hidden_channels, norm_cfg),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_channels, channels, 1, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x: Tensor) -> Tensor:
        weight = self.gate(x.mean(dim=(2, 3), keepdim=True))
        return x + x * weight


class _PEMDeformUpBlock(nn.Module):
    """Modulated deformable convolution followed by learned 2x upsampling."""

    def __init__(
        self,
        channels: int,
        deform_kernel_size: int,
        deform_groups: int,
        use_deform_conv: bool,
        upsample_kernel_size: int,
        upsample_stride: int,
        upsample_padding: int,
        norm_cfg: Optional[dict],
    ) -> None:
        super().__init__()
        if deform_kernel_size < 1 or deform_kernel_size % 2 == 0:
            raise ValueError('pem_deform_kernel_size must be a positive odd number.')
        if deform_groups < 1:
            raise ValueError('pem_deform_groups must be at least one.')
        deform_padding = deform_kernel_size // 2
        offset_channels = 3 * deform_kernel_size * deform_kernel_size * deform_groups
        self.offset_mask = nn.Conv2d(
            channels, offset_channels, kernel_size=3, padding=1
        )
        self.use_deform_conv = use_deform_conv and ModulatedDeformConv2d is not None
        if self.use_deform_conv:
            self.conv = ModulatedDeformConv2d(
                channels,
                channels,
                kernel_size=deform_kernel_size,
                padding=deform_padding,
                deform_groups=deform_groups,
                bias=False,
            )
        else:
            # MMSeg's Mask2Former itself already requires mmcv ops in this
            # project.  This fallback only keeps import/CPU smoke checks clear.
            self.conv = nn.Conv2d(
                channels,
                channels,
                kernel_size=deform_kernel_size,
                padding=deform_padding,
                bias=False,
            )
        self.conv_norm = _make_norm(channels, norm_cfg)
        self.up = nn.ConvTranspose2d(
            channels,
            channels,
            kernel_size=upsample_kernel_size,
            stride=upsample_stride,
            padding=upsample_padding,
            bias=False,
        )
        self.up_norm = _make_norm(channels, norm_cfg)
        self.act = nn.ReLU(inplace=True)

    def forward(self, x: Tensor) -> Tuple[Tensor, Tensor]:
        offset_mask = self.offset_mask(x)
        offset_x, offset_y, mask = torch.chunk(offset_mask, 3, dim=1)
        if self.use_deform_conv:
            offset = torch.cat((offset_x, offset_y), dim=1)
            y = self.conv(x, offset, mask.sigmoid())
        else:
            y = self.conv(x)
        y = self.act(self.conv_norm(y))
        y_up = self.act(self.up_norm(self.up(y)))
        return y, y_up


class PEMPyramidPixelDecoder(nn.Module):
    """PEM's lightweight four-to-three-scale pixel decoder.

    Input features must be ordered from stride 4 to stride 32.  Its output
    follows the MMDetection Mask2Former pixel-decoder contract:
    ``mask_features, multi_scale_memorys`` where memory maps are ordered from
    low to high resolution (stride 32, 16, 8).
    """

    def __init__(
        self,
        in_channels: Sequence[int],
        feat_channels: int,
        out_channels: int,
        csm_reduction: int = 2,
        deform_kernel_size: int = 3,
        deform_groups: int = 1,
        use_deform_conv: bool = True,
        upsample_kernel_size: int = 4,
        upsample_stride: int = 2,
        upsample_padding: int = 1,
        norm_cfg: Optional[dict] = None,
    ) -> None:
        super().__init__()
        if len(in_channels) != 4:
            raise ValueError('PEMPyramidPixelDecoder requires exactly four input feature maps.')
        self.in_projections = nn.ModuleList(
            [_ConvNormReLU(channels, feat_channels, kernel_size=1, padding=0, norm_cfg=norm_cfg)
             for channels in in_channels]
        )
        self.global_projection = _ConvNormReLU(
            in_channels[-1], feat_channels, kernel_size=1, padding=0, norm_cfg=norm_cfg
        )
        self.context = nn.ModuleList(
            [_ContextSelfModulation(feat_channels, csm_reduction, norm_cfg) for _ in range(4)]
        )
        self.up_blocks = nn.ModuleList(
            [
                _PEMDeformUpBlock(
                    feat_channels,
                    deform_kernel_size=deform_kernel_size,
                    deform_groups=deform_groups,
                    use_deform_conv=use_deform_conv,
                    upsample_kernel_size=upsample_kernel_size,
                    upsample_stride=upsample_stride,
                    upsample_padding=upsample_padding,
                    norm_cfg=norm_cfg,
                )
                for _ in range(3)
            ]
        )
        self.mask_projection = _ConvNormReLU(
            feat_channels, out_channels, kernel_size=1, padding=0, norm_cfg=norm_cfg
        )

    def init_weights(self) -> None:
        for module in self.modules():
            if isinstance(module, (nn.Conv2d, nn.ConvTranspose2d)):
                nn.init.kaiming_normal_(module.weight, mode='fan_out', nonlinearity='relu')
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)

    def forward(self, features: Sequence[Tensor]) -> Tuple[Tensor, List[Tensor]]:
        if len(features) != 4:
            raise ValueError('PEMPyramidPixelDecoder expects four DINOv3 Adapter feature maps.')
        projected = [projection(feature) for feature, projection in zip(features, self.in_projections)]
        global_context = self.global_projection(features[-1].mean(dim=(2, 3), keepdim=True))

        x32 = self.context[0](projected[3]) + global_context
        x32, x_up = self.up_blocks[0](x32)
        x16 = self.context[1](projected[2]) + x_up
        x16, x_up = self.up_blocks[1](x16)
        x8 = self.context[2](projected[1]) + x_up
        x8, x_up = self.up_blocks[2](x8)
        x4 = self.context[3](projected[0]) + x_up

        return self.mask_projection(x4), [x32, x16, x8]


class _LocalRepresentation(nn.Module):
    """Depth-wise local feature projection used by PEM cross-attention."""

    def __init__(self, channels: int, kernel_size: int, norm_cfg: Optional[dict]) -> None:
        super().__init__()
        if kernel_size < 1 or kernel_size % 2 == 0:
            raise ValueError('pem_local_kernel_size must be a positive odd number.')
        self.depthwise = nn.Conv2d(
            channels,
            channels,
            kernel_size,
            padding=kernel_size // 2,
            groups=channels,
        )
        self.norm = _make_norm(channels, norm_cfg)
        self.out = nn.Linear(channels, channels)

    def forward(self, x: Tensor) -> Tensor:
        batch_size, channels, height, width = x.shape
        x = self.depthwise(self.norm(x))
        x = x.reshape(batch_size, channels, height * width).transpose(1, 2)
        return self.out(x)


class _PEMCrossAttention(nn.Module):
    """Prototype-based masked cross-attention from PEM, batch-first version."""

    def __init__(
        self,
        embed_dims: int,
        num_heads: int,
        local_kernel_size: int,
        alpha_init: float,
        norm_cfg: Optional[dict],
    ) -> None:
        super().__init__()
        if embed_dims % num_heads != 0:
            raise ValueError('embed_dims must be divisible by num_heads for PEM attention.')
        self.feature_projection = _LocalRepresentation(embed_dims, local_kernel_size, norm_cfg)
        self.query_projection = nn.Sequential(nn.LayerNorm(embed_dims), nn.Linear(embed_dims, embed_dims))
        self.projection = nn.Linear(embed_dims, embed_dims)
        self.output_projection = nn.Linear(embed_dims, embed_dims)
        self.alpha = nn.Parameter(torch.full((1, 1, embed_dims), alpha_init))
        self.num_heads = num_heads

    def _most_similar_tokens(
        self, memory: Tensor, query: Tensor, attention_mask: Optional[Tensor]
    ) -> Tensor:
        batch_size, num_tokens, channels = memory.shape
        num_queries = query.shape[1]
        head_dim = channels // self.num_heads
        memory_heads = memory.view(batch_size, num_tokens, self.num_heads, head_dim).permute(0, 2, 1, 3)
        query_heads = query.view(batch_size, num_queries, self.num_heads, head_dim).permute(0, 2, 1, 3)
        similarity = torch.einsum('bhnc,bhqc->bhnq', memory_heads, query_heads)

        if attention_mask is not None:
            # Mask2Former stores the cross-attention mask as [B * heads, Q, N].
            mask = attention_mask.view(batch_size, self.num_heads, num_queries, num_tokens)
            mask = mask.permute(0, 1, 3, 2).bool()
            # Avoid an all -inf row, which would make argmax arbitrary.
            all_blocked = mask.all(dim=2, keepdim=True)
            mask = mask & ~all_blocked
            similarity = similarity.masked_fill(mask, float('-inf'))

        indices = similarity.argmax(dim=2)
        prototype = torch.gather(
            memory_heads,
            2,
            indices.unsqueeze(-1).expand(-1, -1, -1, head_dim),
        )
        return prototype.permute(0, 2, 1, 3).reshape(batch_size, num_queries, channels)

    def forward(
        self,
        query: Tensor,
        memory_map: Tensor,
        attention_mask: Optional[Tensor],
        memory_pos: Optional[Tensor],
        query_pos: Optional[Tensor],
    ) -> Tensor:
        residual = query
        if memory_pos is not None:
            batch_size, channels, height, width = memory_map.shape
            pos_map = memory_pos.transpose(1, 2).reshape(batch_size, channels, height, width)
            memory_map = memory_map + pos_map
        if query_pos is not None:
            query = query + query_pos

        memory = F.normalize(self.feature_projection(memory_map), dim=-1)
        query = F.normalize(self.query_projection(query), dim=-1)
        prototype = self._most_similar_tokens(memory, query, attention_mask)
        output = F.normalize(self.projection(prototype * query), dim=1) * self.alpha + prototype
        return residual + self.output_projection(output)


class _CustomMask2FormerLayer(nn.Module):
    """Mask2Former decoder layer with either standard or PEM cross-attention."""

    def __init__(
        self,
        embed_dims: int,
        num_heads: int,
        feedforward_channels: int,
        dropout: float,
        use_pem_attention: bool,
        pem_local_kernel_size: int,
        pem_alpha_init: float,
        pem_norm_cfg: Optional[dict],
    ) -> None:
        super().__init__()
        self.use_pem_attention = use_pem_attention
        if use_pem_attention:
            self.cross_attention = _PEMCrossAttention(
                embed_dims,
                num_heads,
                local_kernel_size=pem_local_kernel_size,
                alpha_init=pem_alpha_init,
                norm_cfg=pem_norm_cfg,
            )
        else:
            self.cross_attention = nn.MultiheadAttention(embed_dims, num_heads, dropout=dropout, batch_first=True)
        self.self_attention = nn.MultiheadAttention(embed_dims, num_heads, dropout=dropout, batch_first=True)
        self.cross_norm = nn.LayerNorm(embed_dims)
        self.self_norm = nn.LayerNorm(embed_dims)
        self.ffn_norm = nn.LayerNorm(embed_dims)
        self.ffn = nn.Sequential(
            nn.Linear(embed_dims, feedforward_channels),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(feedforward_channels, embed_dims),
        )
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        query: Tensor,
        memory: Tensor,
        memory_pos: Tensor,
        query_pos: Tensor,
        cross_attention_mask: Tensor,
        self_attention_mask: Optional[Tensor] = None,
    ) -> Tensor:
        if self.use_pem_attention:
            query = self.cross_attention(
                query, memory, cross_attention_mask, memory_pos, query_pos
            )
            query = self.cross_norm(query)
        else:
            q = query + query_pos
            k = memory + memory_pos
            cross_out = self.cross_attention(q, k, memory, attn_mask=cross_attention_mask, need_weights=False)[0]
            query = self.cross_norm(query + self.dropout(cross_out))

        q = query + query_pos
        self_out = self.self_attention(
            q, q, query, attn_mask=self_attention_mask, need_weights=False
        )[0]
        query = self.self_norm(query + self.dropout(self_out))
        query = self.ffn_norm(query + self.dropout(self.ffn(query)))
        return query


class _PEMMPFormerBase(Mask2FormerHead):
    """Shared OpenMMLab integration for the PEM and MP-Former variants."""

    use_pem: bool = False
    use_mpformer: bool = False

    def __init__(
        self,
        pem_pixel_norm_cfg: Optional[dict] = None,
        pem_attention_norm_cfg: Optional[dict] = None,
        pem_csm_reduction: int = 2,
        pem_local_kernel_size: int = 3,
        pem_alpha_init: float = 1.0,
        pem_deform_kernel_size: int = 3,
        pem_deform_groups: int = 1,
        pem_use_deform_conv: bool = True,
        pem_upsample_kernel_size: int = 4,
        pem_upsample_stride: int = 2,
        pem_upsample_padding: int = 1,
        mp_num_groups: int = 1,
        mp_mask_noise_scale: float = 0.0,
        mp_label_noise_ratio: float = 0.2,
        mp_all_layers: bool = True,
        mp_pilot_start_layer: int = 0,
        mp_pilot_end_layer: int = -1,
        mp_apply_initial_pilots: bool = True,
        mp_mask_threshold: float = 0.5,
        mp_isolate_dn_queries: bool = True,
        mp_loss_weight: float = 1.0,
        **kwargs: Any,
    ) -> None:
        in_channels = list(kwargs['in_channels'])
        transformer_cfg = kwargs.get('transformer_decoder')
        layer_cfg = _cfg_get(transformer_cfg, 'layer_cfg', {})
        cross_cfg = _cfg_get(layer_cfg, 'cross_attn_cfg', {})
        ffn_cfg = _cfg_get(layer_cfg, 'ffn_cfg', {})
        self._configured_num_heads = _cfg_get(cross_cfg, 'num_heads', 8)
        self._configured_ffn_channels = _cfg_get(ffn_cfg, 'feedforward_channels', 2048)
        self._configured_dropout = float(_cfg_get(ffn_cfg, 'ffn_drop', 0.0))

        super().__init__(**kwargs)

        embed_dims = self.decoder_embed_dims
        num_heads = getattr(self, 'num_heads', self._configured_num_heads)
        num_layers = self.num_transformer_decoder_layers
        self.output_norm = nn.LayerNorm(embed_dims)
        self.custom_decoder_layers = nn.ModuleList(
            [
                _CustomMask2FormerLayer(
                    embed_dims=embed_dims,
                    num_heads=num_heads,
                    feedforward_channels=self._configured_ffn_channels,
                    dropout=self._configured_dropout,
                    use_pem_attention=self.use_pem,
                    pem_local_kernel_size=pem_local_kernel_size,
                    pem_alpha_init=pem_alpha_init,
                    pem_norm_cfg=pem_attention_norm_cfg or dict(type='SyncBN', requires_grad=True),
                )
                for _ in range(num_layers)
            ]
        )

        if self.use_pem:
            self.pixel_decoder = PEMPyramidPixelDecoder(
                in_channels=in_channels,
                feat_channels=embed_dims,
                out_channels=self.mask_embed[-1].out_features,
                csm_reduction=pem_csm_reduction,
                deform_kernel_size=pem_deform_kernel_size,
                deform_groups=pem_deform_groups,
                use_deform_conv=pem_use_deform_conv,
                upsample_kernel_size=pem_upsample_kernel_size,
                upsample_stride=pem_upsample_stride,
                upsample_padding=pem_upsample_padding,
                norm_cfg=pem_pixel_norm_cfg or dict(type='SyncBN', requires_grad=True),
            )

        # The parent constructs its fixed Mask2FormerTransformerDecoder.  Its
        # layers cannot accept MP-Former's query-to-query visibility mask, so
        # the custom layers above replace it completely.
        del self.transformer_decoder

        self.mp_num_groups = int(mp_num_groups)
        self.mp_mask_noise_scale = float(mp_mask_noise_scale)
        self.mp_label_noise_ratio = float(mp_label_noise_ratio)
        self.mp_all_layers = bool(mp_all_layers)
        self.mp_pilot_start_layer = int(mp_pilot_start_layer)
        self.mp_pilot_end_layer = int(mp_pilot_end_layer)
        self.mp_apply_initial_pilots = bool(mp_apply_initial_pilots)
        self.mp_mask_threshold = float(mp_mask_threshold)
        self.mp_isolate_dn_queries = bool(mp_isolate_dn_queries)
        self.mp_loss_weight = float(mp_loss_weight)
        if self.use_mpformer:
            self.mp_label_embedding = nn.Embedding(self.num_classes, embed_dims)

    def init_weights(self) -> None:
        for projection in self.decoder_input_projs:
            if isinstance(projection, nn.Conv2d):
                nn.init.xavier_uniform_(projection.weight)
                if projection.bias is not None:
                    nn.init.constant_(projection.bias, 0)
        self.pixel_decoder.init_weights()
        for layer in self.custom_decoder_layers:
            for module in layer.modules():
                if isinstance(module, (nn.Linear, nn.Conv2d)):
                    nn.init.xavier_uniform_(module.weight)
                    if module.bias is not None:
                        nn.init.constant_(module.bias, 0)
                elif isinstance(module, nn.LayerNorm):
                    nn.init.constant_(module.bias, 0)
                    nn.init.constant_(module.weight, 1)
        if self.use_mpformer:
            nn.init.normal_(self.mp_label_embedding.weight, std=0.02)

    def _prepare_memories(
        self, x: Sequence[Tensor]
    ) -> Tuple[Tensor, List[Tensor], List[Tensor], List[Tensor]]:
        mask_features, memory_maps = self.pixel_decoder(x)
        decoder_inputs: List[Tensor] = []
        decoder_positions: List[Tensor] = []
        for level_idx in range(self.num_transformer_feat_level):
            memory = self.decoder_input_projs[level_idx](memory_maps[level_idx])
            batch_size, _, height, width = memory.shape
            decoder_input = memory.flatten(2).transpose(1, 2)
            decoder_input = decoder_input + self.level_embed.weight[level_idx].view(1, 1, -1)
            padding_mask = torch.zeros((batch_size, height, width), dtype=torch.bool, device=memory.device)
            position = self.decoder_positional_encoding(padding_mask).flatten(2).transpose(1, 2)
            decoder_inputs.append(decoder_input)
            decoder_positions.append(position)
        return mask_features, memory_maps, decoder_inputs, decoder_positions

    def _forward_head(
        self, query: Tensor, mask_features: Tensor, attention_size: Tuple[int, int]
    ) -> Tuple[Tensor, Tensor, Tensor]:
        decoder_output = self.output_norm(query)
        cls_pred = self.cls_embed(decoder_output)
        mask_embed = self.mask_embed(decoder_output)
        mask_pred = torch.einsum('bqc,bchw->bqhw', mask_embed, mask_features)
        attention_mask = F.interpolate(mask_pred, size=attention_size, mode='bilinear', align_corners=False)
        attention_mask = attention_mask.flatten(2).unsqueeze(1).repeat(1, self.num_heads, 1, 1)
        attention_mask = (attention_mask.flatten(0, 1).sigmoid() < 0.5).detach()
        return cls_pred, mask_pred, attention_mask

    @staticmethod
    def _clear_fully_masked(attention_mask: Tensor) -> Tensor:
        valid = (attention_mask.sum(dim=-1) != attention_mask.shape[-1]).unsqueeze(-1)
        return attention_mask & valid

    def _prepare_mp_queries(
        self, targets: Sequence[Any], base_query: Tensor, base_query_pos: Tensor
    ) -> Optional[Dict[str, Any]]:
        if self.mp_num_groups <= 0:
            return None
        object_counts = [int(target.labels.numel()) for target in targets]
        max_objects = max(object_counts, default=0)
        if max_objects == 0:
            return None

        batch_size, _, embed_dims = base_query.shape
        device = base_query.device
        groups = self.mp_num_groups
        pad_size = groups * max_objects
        mp_query = base_query.new_zeros((batch_size, pad_size, embed_dims))
        mp_query_pos = base_query.new_zeros((batch_size, pad_size, embed_dims))

        for batch_idx, target in enumerate(targets):
            labels = target.labels.to(device=device, dtype=torch.long)
            if labels.numel() == 0:
                continue
            noisy_labels = labels.clone()
            if self.mp_label_noise_ratio > 0:
                noise = torch.rand(noisy_labels.shape, device=device) < self.mp_label_noise_ratio
                replacement = torch.randint(0, self.num_classes, noisy_labels.shape, device=device)
                noisy_labels = torch.where(noise, replacement, noisy_labels)
            label_features = self.mp_label_embedding(noisy_labels)
            for group_idx in range(groups):
                begin = group_idx * max_objects
                mp_query[batch_idx, begin:begin + labels.numel()] = label_features

        total_queries = pad_size + self.num_queries
        self_attention_mask = torch.zeros((total_queries, total_queries), dtype=torch.bool, device=device)
        if self.mp_isolate_dn_queries:
            # Matching queries cannot read denoising queries.  Denoising groups
            # are mutually hidden, following MP-Former's query-isolation rule.
            self_attention_mask[pad_size:, :pad_size] = True
            for group_idx in range(groups):
                begin = group_idx * max_objects
                end = begin + max_objects
                self_attention_mask[begin:end, :begin] = True
                self_attention_mask[begin:end, end:pad_size] = True

        return dict(
            query=torch.cat((mp_query, base_query), dim=1),
            query_pos=torch.cat((mp_query_pos, base_query_pos), dim=1),
            self_attention_mask=self_attention_mask,
            pad_size=pad_size,
            max_objects=max_objects,
            groups=groups,
            targets=targets,
        )

    def _mp_cross_attention_mask(
        self, mp_data: Dict[str, Any], attention_size: Tuple[int, int]
    ) -> Tensor:
        batch_size = len(mp_data['targets'])
        height, width = attention_size
        pad_size = mp_data['pad_size']
        max_objects = mp_data['max_objects']
        groups = mp_data['groups']
        device = mp_data['query'].device
        pilot_mask = torch.ones((batch_size, pad_size, height * width), dtype=torch.bool, device=device)

        for batch_idx, target in enumerate(mp_data['targets']):
            masks = target.masks.to(device=device, dtype=torch.float32)
            if masks.numel() == 0:
                continue
            masks = F.interpolate(masks.unsqueeze(1), size=attention_size, mode='nearest').squeeze(1)
            # True means a location is invisible to attention.
            masks = (masks < self.mp_mask_threshold).flatten(1)
            if self.mp_mask_noise_scale > 0:
                foreground = (~masks).sum(dim=1, keepdim=True).float()
                probability = foreground * self.mp_mask_noise_scale / float(height * width)
                noise = torch.rand(masks.shape, device=device) < probability
                masks = torch.logical_xor(masks, noise)
            for group_idx in range(groups):
                begin = group_idx * max_objects
                pilot_mask[batch_idx, begin:begin + masks.shape[0]] = masks

        return pilot_mask.unsqueeze(1).repeat(1, self.num_heads, 1, 1).flatten(0, 1)

    def _mp_loss_for_layer(
        self, cls_scores: Tensor, mask_preds: Tensor, mp_data: Dict[str, Any]
    ) -> Dict[str, Tensor]:
        batch_size, pad_size, _ = cls_scores.shape
        max_objects = mp_data['max_objects']
        groups = mp_data['groups']
        device = cls_scores.device
        labels = torch.full(
            (batch_size, pad_size), self.num_classes, dtype=torch.long, device=device
        )
        positive_predictions: List[Tensor] = []
        positive_targets: List[Tensor] = []

        for batch_idx, target in enumerate(mp_data['targets']):
            target_labels = target.labels.to(device=device, dtype=torch.long)
            target_masks = target.masks.to(device=device, dtype=torch.float32)
            if target_labels.numel() == 0:
                continue
            target_masks = F.interpolate(
                target_masks.unsqueeze(1), size=mask_preds.shape[-2:], mode='nearest'
            ).squeeze(1)
            for group_idx in range(groups):
                begin = group_idx * max_objects
                end = begin + target_labels.numel()
                labels[batch_idx, begin:end] = target_labels
                positive_predictions.append(mask_preds[batch_idx, begin:end])
                positive_targets.append(target_masks)

        flat_scores = cls_scores.flatten(0, 1)
        flat_labels = labels.flatten()
        class_weight = getattr(self, 'class_weight', None)
        if class_weight is None:
            average_factor = max(float(flat_labels.numel()), 1.0)
        else:
            class_weight_tensor = flat_scores.new_tensor(class_weight)
            average_factor = class_weight_tensor[flat_labels].sum().clamp_min(1.0)
        loss_cls = self.loss_cls(flat_scores, flat_labels, None, avg_factor=average_factor)

        if not positive_predictions:
            zero = mask_preds.sum() * 0.0
            return dict(loss_cls_mp=loss_cls, loss_mask_mp=zero, loss_dice_mp=zero)

        mask_predictions = torch.cat(positive_predictions, dim=0)
        mask_targets = torch.cat(positive_targets, dim=0)
        num_masks = mask_predictions.shape[0]
        loss_mask = self.loss_mask(
            mask_predictions,
            mask_targets,
            avg_factor=max(num_masks * mask_predictions.shape[-2] * mask_predictions.shape[-1], 1),
        )
        loss_dice = self.loss_dice(mask_predictions, mask_targets, avg_factor=max(num_masks, 1))
        return dict(loss_cls_mp=loss_cls, loss_mask_mp=loss_mask, loss_dice_mp=loss_dice)

    def _mp_losses(self, mp_data: Dict[str, Any]) -> Dict[str, Tensor]:
        losses: Dict[str, Tensor] = {}
        predictions = mp_data['predictions']
        for layer_idx, (cls_scores, mask_preds) in enumerate(predictions):
            layer_losses = self._mp_loss_for_layer(cls_scores, mask_preds, mp_data)
            prefix = '' if layer_idx == len(predictions) - 1 else f'd{layer_idx}.'
            for name, value in layer_losses.items():
                losses[f'{prefix}{name}'] = value * self.mp_loss_weight
        return losses

    def _forward_impl(
        self, x: Sequence[Tensor], mp_targets: Optional[Sequence[Any]] = None
    ) -> Tuple[List[Tensor], List[Tensor], Optional[Dict[str, Any]]]:
        mask_features, memory_maps, decoder_inputs, decoder_positions = self._prepare_memories(x)
        batch_size = x[0].shape[0]
        base_query = self.query_feat.weight.unsqueeze(0).repeat(batch_size, 1, 1)
        base_query_pos = self.query_embed.weight.unsqueeze(0).repeat(batch_size, 1, 1)

        mp_data: Optional[Dict[str, Any]] = None
        if self.use_mpformer and mp_targets is not None:
            mp_data = self._prepare_mp_queries(mp_targets, base_query, base_query_pos)
        if mp_data is None:
            query = base_query
            query_pos = base_query_pos
            self_attention_mask = None
        else:
            query = mp_data['query']
            query_pos = mp_data['query_pos']
            self_attention_mask = mp_data['self_attention_mask']

        all_cls_scores: List[Tensor] = []
        all_mask_preds: List[Tensor] = []
        mp_predictions: List[Tuple[Tensor, Tensor]] = []

        cls_scores, mask_preds, attention_mask = self._forward_head(
            query, mask_features, memory_maps[0].shape[-2:]
        )
        if mp_data is not None and self.mp_apply_initial_pilots:
            attention_mask[:, :mp_data['pad_size']] = self._mp_cross_attention_mask(
                mp_data, memory_maps[0].shape[-2:]
            )
        if mp_data is not None:
            mp_predictions.append((cls_scores[:, :mp_data['pad_size']], mask_preds[:, :mp_data['pad_size']]))
            all_cls_scores.append(cls_scores[:, -self.num_queries:])
            all_mask_preds.append(mask_preds[:, -self.num_queries:])
        else:
            all_cls_scores.append(cls_scores)
            all_mask_preds.append(mask_preds)

        for layer_idx, decoder_layer in enumerate(self.custom_decoder_layers):
            level_idx = layer_idx % self.num_transformer_feat_level
            attention_mask = self._clear_fully_masked(attention_mask)
            if self.use_pem:
                memory = memory_maps[level_idx]
            else:
                memory = decoder_inputs[level_idx]
            query = decoder_layer(
                query=query,
                memory=memory,
                memory_pos=decoder_positions[level_idx],
                query_pos=query_pos,
                cross_attention_mask=attention_mask,
                self_attention_mask=self_attention_mask,
            )
            next_level = (layer_idx + 1) % self.num_transformer_feat_level
            cls_scores, mask_preds, attention_mask = self._forward_head(
                query, mask_features, memory_maps[next_level].shape[-2:]
            )
            if mp_data is not None:
                in_pilot_range = (
                    layer_idx >= self.mp_pilot_start_layer
                    and (self.mp_pilot_end_layer < 0 or layer_idx <= self.mp_pilot_end_layer)
                )
                apply_pilots = in_pilot_range and (
                    self.mp_all_layers or layer_idx < 3
                )
                if apply_pilots:
                    attention_mask[:, :mp_data['pad_size']] = self._mp_cross_attention_mask(
                        mp_data, memory_maps[next_level].shape[-2:]
                    )
                mp_predictions.append((cls_scores[:, :mp_data['pad_size']], mask_preds[:, :mp_data['pad_size']]))
                all_cls_scores.append(cls_scores[:, -self.num_queries:])
                all_mask_preds.append(mask_preds[:, -self.num_queries:])
            else:
                all_cls_scores.append(cls_scores)
                all_mask_preds.append(mask_preds)

        if mp_data is not None:
            mp_data['predictions'] = mp_predictions
        return all_cls_scores, all_mask_preds, mp_data

    def forward(
        self,
        x: Sequence[Tensor],
        batch_data_samples: Optional[Sequence[Any]] = None,
        mp_targets: Optional[Sequence[Any]] = None,
    ) -> Any:
        all_cls_scores, all_mask_preds, mp_data = self._forward_impl(x, mp_targets=mp_targets)
        if mp_targets is not None:
            return all_cls_scores, all_mask_preds, mp_data
        return all_cls_scores, all_mask_preds

    def loss(self, x: Sequence[Tensor], batch_data_samples: Sequence[Any], train_cfg: Any) -> Dict[str, Tensor]:
        if not self.use_mpformer:
            return super().loss(x, batch_data_samples, train_cfg)
        batch_gt_instances, batch_img_metas = self._seg_data_to_instance_data(batch_data_samples)
        all_cls_scores, all_mask_preds, mp_data = self.forward(
            x, batch_data_samples, mp_targets=batch_gt_instances
        )
        losses = self.loss_by_feat(
            all_cls_scores, all_mask_preds, batch_gt_instances, batch_img_metas
        )
        if mp_data is not None:
            losses.update(self._mp_losses(mp_data))
        return losses


@MODELS.register_module()
class PEMMask2FormerHead(_PEMMPFormerBase):
    """Mask2Former head using PEM's decoder architecture."""

    use_pem = True
    use_mpformer = False


@MODELS.register_module()
class MPFormerMask2FormerHead(_PEMMPFormerBase):
    """Mask2Former head with MP-Former mask-piloted training."""

    use_pem = False
    use_mpformer = True


@MODELS.register_module()
class PEMMPFormerMask2FormerHead(_PEMMPFormerBase):
    """PEM architecture trained with MP-Former mask-piloted supervision."""

    use_pem = True
    use_mpformer = True
