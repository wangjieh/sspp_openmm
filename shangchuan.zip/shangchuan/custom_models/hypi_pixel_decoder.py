"""HyPiDecoder pixel decoder for Mask2Former-style segmentation heads.

This module implements the ``3d3s`` HyPiDecoder variant described in
"HyPiDecoder: Hybrid Pixel Decoder for Efficient Segmentation and
Detection" (ICCV 2025): three Multi-Scale Deformable Attention layers are
followed by three convolutional CSP-FPN layers using separable convolutions.

It preserves the interface of MMDetection's ``MSDeformAttnPixelDecoder`` so
it can replace only ``pixel_decoder`` in an existing ``Mask2FormerHead``.
"""

from __future__ import annotations

import copy
from typing import List, Sequence, Tuple, Union

import torch
import torch.nn.functional as F
from mmcv.cnn import Conv2d, ConvModule, DepthwiseSeparableConvModule
from mmengine.config import ConfigDict
from mmengine.model import BaseModule, ModuleList
from torch import Tensor, nn

try:
    from mmdet.models.layers import MSDeformAttnPixelDecoder
except ImportError:
    from mmdet.models.layers.msdeformattn_pixel_decoder import \
        MSDeformAttnPixelDecoder
from mmdet.registry import MODELS


class _CSPSeparableBottleneck(BaseModule):
    """One CSP bottleneck with a depthwise-separable 3x3 convolution."""

    def __init__(
        self,
        channels: int,
        norm_cfg: dict,
        act_cfg: dict,
        init_cfg=None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        self.conv1 = ConvModule(
            channels,
            channels,
            kernel_size=1,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
        )
        self.conv2 = DepthwiseSeparableConvModule(
            channels,
            channels,
            kernel_size=3,
            stride=1,
            padding=1,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
        )

    def forward(self, x: Tensor) -> Tensor:
        return x + self.conv2(self.conv1(x))


class _CSPSepLayer(BaseModule):
    """CSP fusion layer whose residual branch uses separable convolutions.

    This is the ``s`` block in the paper's ``3d3s`` notation.  It follows the
    CSP split-transform-concatenate pattern and applies three separable
    bottlenecks by default, matching the CSP block depth shown in the paper.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        num_blocks: int,
        expand_ratio: float,
        norm_cfg: dict,
        act_cfg: dict,
        init_cfg=None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        hidden_channels = max(1, int(out_channels * expand_ratio))
        self.main_conv = ConvModule(
            in_channels,
            hidden_channels,
            kernel_size=1,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
        )
        self.short_conv = ConvModule(
            in_channels,
            hidden_channels,
            kernel_size=1,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
        )
        self.blocks = nn.Sequential(*[
            _CSPSeparableBottleneck(
                hidden_channels, norm_cfg=norm_cfg, act_cfg=act_cfg)
            for _ in range(num_blocks)
        ])
        self.final_conv = ConvModule(
            hidden_channels * 2,
            out_channels,
            kernel_size=1,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
        )

    def forward(self, x: Tensor) -> Tensor:
        main = self.blocks(self.main_conv(x))
        shortcut = self.short_conv(x)
        return self.final_conv(torch.cat((main, shortcut), dim=1))


class _CSPSepPAFPNLayer(BaseModule):
    """One bidirectional CSP-FPN layer over four feature levels.

    The high-resolution-to-low-resolution path uses stride-2 convolutions;
    the reverse path uses bilinear upsampling.  Both paths concatenate the
    incoming features before CSP fusion, as specified for HyPiDecoder.
    """

    def __init__(
        self,
        channels: int,
        num_levels: int,
        csp_num_blocks: int,
        csp_expand_ratio: float,
        norm_cfg: dict,
        act_cfg: dict,
        init_cfg=None,
    ) -> None:
        super().__init__(init_cfg=init_cfg)
        if num_levels < 2:
            raise ValueError(f'num_levels must be at least 2, got {num_levels}.')

        self.num_levels = num_levels
        self.downsample_convs = ModuleList([
            ConvModule(
                channels,
                channels,
                kernel_size=3,
                stride=2,
                padding=1,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
            ) for _ in range(num_levels - 1)
        ])
        self.down_fusions = ModuleList([
            _CSPSepLayer(
                channels * 2,
                channels,
                num_blocks=csp_num_blocks,
                expand_ratio=csp_expand_ratio,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
            ) for _ in range(num_levels - 1)
        ])
        self.up_fusions = ModuleList([
            _CSPSepLayer(
                channels * 2,
                channels,
                num_blocks=csp_num_blocks,
                expand_ratio=csp_expand_ratio,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
            ) for _ in range(num_levels - 1)
        ])

    def forward(self, features: Sequence[Tensor]) -> Tuple[Tensor, ...]:
        if len(features) != self.num_levels:
            raise ValueError(
                f'Expected {self.num_levels} feature levels, got {len(features)}.')

        # P2 -> P5: downsample the higher-resolution feature, concatenate it
        # with the next lower-resolution feature, then apply CSP fusion.
        down_features = [features[0]]
        for level in range(self.num_levels - 1):
            downsampled = self.downsample_convs[level](down_features[-1])
            target = features[level + 1]
            if downsampled.shape[-2:] != target.shape[-2:]:
                raise ValueError(
                    'HyPiDecoder requires adjacent feature levels whose '
                    'spatial sizes differ by exactly two. Got '
                    f'{tuple(down_features[-1].shape[-2:])} and '
                    f'{tuple(target.shape[-2:])}.')
            down_features.append(
                self.down_fusions[level](torch.cat((downsampled, target), dim=1)))

        # P5 -> P2: upsample the lower-resolution result, concatenate it with
        # the current-scale feature, then apply another CSP fusion.
        outputs: List[Tensor] = [None] * self.num_levels  # type: ignore[list-item]
        outputs[-1] = down_features[-1]
        for level in range(self.num_levels - 2, -1, -1):
            upsampled = F.interpolate(
                outputs[level + 1],
                size=down_features[level].shape[-2:],
                mode='bilinear',
                align_corners=False,
            )
            outputs[level] = self.up_fusions[level](
                torch.cat((down_features[level], upsampled), dim=1))
        return tuple(outputs)


@MODELS.register_module()
class HyPiPixelDecoder(MSDeformAttnPixelDecoder):
    """Hybrid Pixel Decoder using the paper's ``3d3s`` arrangement.

    The first stage retains a three-layer MSDeformAttn encoder for global,
    cross-scale reasoning.  It is followed by three CSPSep PAFPN layers for
    local multi-scale fusion.  The return values are intentionally identical
    to ``MSDeformAttnPixelDecoder``:

    - ``mask_feature``: stride-4 feature used to form query masks;
    - ``multi_scale_features``: low-to-high resolution features supplied to
      the Mask2Former transformer decoder.
    """

    def __init__(
        self,
        in_channels: Union[List[int], Tuple[int, ...]],
        strides: Union[List[int], Tuple[int, ...]],
        feat_channels: int = 256,
        out_channels: int = 256,
        num_outs: int = 3,
        norm_cfg: dict = dict(type='GN', num_groups=32),
        act_cfg: dict = dict(type='ReLU'),
        encoder: dict = None,
        positional_encoding: dict = dict(num_feats=128, normalize=True),
        attn_num_layers: int = 3,
        hybrid_num_layers: int = 3,
        csp_num_blocks: int = 3,
        csp_expand_ratio: float = 0.5,
        init_cfg=None,
    ) -> None:
        if len(in_channels) != 4:
            raise ValueError(
                'HyPiPixelDecoder currently implements the four-level P2-P5 '
                f'architecture from the paper, got {len(in_channels)} levels.')
        if encoder is None:
            raise ValueError('encoder configuration must be provided.')
        if attn_num_layers < 1 or hybrid_num_layers < 1:
            raise ValueError('attn_num_layers and hybrid_num_layers must be positive.')
        if csp_num_blocks < 1:
            raise ValueError('csp_num_blocks must be positive.')

        encoder_cfg = ConfigDict(copy.deepcopy(encoder))
        encoder_cfg['num_layers'] = attn_num_layers
        super().__init__(
            in_channels=in_channels,
            strides=strides,
            feat_channels=feat_channels,
            out_channels=out_channels,
            num_outs=num_outs,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
            encoder=encoder_cfg,
            positional_encoding=positional_encoding,
            init_cfg=init_cfg,
        )

        if self.num_encoder_levels != 3:
            raise ValueError(
                'HyPiPixelDecoder 3d3s expects three MSDeformAttn input '
                f'levels, got {self.num_encoder_levels}.')
        if num_outs > len(in_channels) - 1:
            raise ValueError(
                'num_outs cannot exceed the three decoder features used by '
                f'Mask2Former, got {num_outs}.')

        self.hybrid_fpn_layers = ModuleList([
            _CSPSepPAFPNLayer(
                channels=feat_channels,
                num_levels=len(in_channels),
                csp_num_blocks=csp_num_blocks,
                csp_expand_ratio=csp_expand_ratio,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
            ) for _ in range(hybrid_num_layers)
        ])

    def _forward_attention_features(self, feats: Sequence[Tensor]) -> List[Tensor]:
        """Run the retained MSDeformAttn stage and return P5, P4, P3."""
        batch_size = feats[0].shape[0]
        encoder_input_list = []
        padding_mask_list = []
        level_positional_encoding_list = []
        spatial_shapes = []
        reference_points_list = []

        # This follows MMDetection's MSDeformAttnPixelDecoder implementation.
        for index in range(self.num_encoder_levels):
            level_index = self.num_input_levels - index - 1
            feature = feats[level_index]
            projected = self.input_convs[index](feature)
            feature_hw = torch._shape_as_tensor(feature)[2:].to(feature.device)

            padding_mask = feature.new_zeros(
                (batch_size,) + feature.shape[-2:], dtype=torch.bool)
            positional = self.postional_encoding(padding_mask)
            level_positional = (
                self.level_encoding.weight[index].view(1, -1, 1, 1) + positional)
            reference_points = self.point_generator.single_level_grid_priors(
                feature.shape[-2:], level_index, device=feature.device)
            feature_wh = feature_hw.unsqueeze(0).flip(dims=[0, 1])
            reference_points = reference_points / (feature_wh * self.strides[level_index])

            encoder_input_list.append(projected.flatten(2).permute(0, 2, 1))
            padding_mask_list.append(padding_mask.flatten(1))
            level_positional_encoding_list.append(
                level_positional.flatten(2).permute(0, 2, 1))
            spatial_shapes.append(feature_hw)
            reference_points_list.append(reference_points)

        padding_masks = torch.cat(padding_mask_list, dim=1)
        encoder_inputs = torch.cat(encoder_input_list, dim=1)
        level_positional_encodings = torch.cat(
            level_positional_encoding_list, dim=1)
        num_queries_per_level = [shape[0] * shape[1] for shape in spatial_shapes]
        spatial_shapes_tensor = torch.cat(spatial_shapes).view(-1, 2)
        level_start_index = torch.cat((
            spatial_shapes_tensor.new_zeros((1,)),
            spatial_shapes_tensor.prod(1).cumsum(0)[:-1],
        ))
        reference_points = torch.cat(reference_points_list, dim=0)
        reference_points = reference_points[None, :, None].repeat(
            batch_size, 1, self.num_encoder_levels, 1)
        valid_ratios = reference_points.new_ones(
            (batch_size, self.num_encoder_levels, 2))

        memory = self.encoder(
            query=encoder_inputs,
            query_pos=level_positional_encodings,
            key_padding_mask=padding_masks,
            spatial_shapes=spatial_shapes_tensor,
            reference_points=reference_points,
            level_start_index=level_start_index,
            valid_ratios=valid_ratios,
        ).permute(0, 2, 1)
        split_memory = torch.split(memory, num_queries_per_level, dim=-1)
        return [
            value.reshape(batch_size, -1, spatial_shapes_tensor[index][0],
                          spatial_shapes_tensor[index][1])
            for index, value in enumerate(split_memory)
        ]

    def forward(self, feats: Sequence[Tensor]) -> Tuple[Tensor, List[Tensor]]:
        if len(feats) != self.num_input_levels:
            raise ValueError(
                f'Expected {self.num_input_levels} backbone features, got {len(feats)}.')

        # The retained attention encoder returns P5, P4 and P3.  P2 is
        # projected independently before all four levels enter the convolution
        # CSP-FPN stages.  This keeps Mask2Former's three-scale transformer
        # decoder interface unchanged from tune42.
        attention_features = self._forward_attention_features(feats)
        p2 = self.output_convs[0](self.lateral_convs[0](feats[0]))
        features: Tuple[Tensor, ...] = (p2, *reversed(attention_features))

        for fpn_layer in self.hybrid_fpn_layers:
            features = fpn_layer(features)

        mask_feature = self.mask_feature(features[0])
        multi_scale_features = list(reversed(features))[:self.num_outs]
        return mask_feature, multi_scale_features
